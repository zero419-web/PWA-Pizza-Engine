/**
 * ============================================================================
 * 🛡️ PANZER SDK v0.1 BETA
 * 
 * SERVICE WORKER CORE ENGINE & NETWORK ORCHESTRATOR
 * ============================================================================
 * @file       sw.js
 * @description Engine ultra-resiliente per la gestione delle PWA della Pubblica
 *              Amministrazione. Implementa strategie polimorfe di caching,
 *              integrità crittografica (SHA-256), telemetria via BroadcastChannel,
 *              fallback offline isolati e bonifica transazionale della RAM.
 * @author     Valentino Aglianò
 * @license    EUPL-1.2
 * ============================================================================
 */

'use strict';

/* ============================================================================
 * 1. ⚙️ CONFIGURAZIONE DI STATO, ROTTE & STIVA CACHE
 * ============================================================================ */
const PANZER_SW_CONFIG = Object.freeze({
    ENGINE_VERSION: '0.1-MUNICIPAL',
    CACHE_KEYS: Object.freeze({
        CORE: 'panzer-core-v7+',
        DATA: 'panzer-data-v7+',
        DYNAMIC: 'panzer-dynamic-v7+',
        OFFLINE: 'panzer-offline-v7+'
    }),
    TELEMETRY_CHANNEL: 'PANZER_TELEMETRY_BUS',
    TIMEOUT_MS: 5000, // Timeout di sicurezza per richieste critiche
    MAX_RETRIES: 3,   // Tentativi di retry per chiamate fallite su reti instabili
    
    // Assets primari indispensabili per l'operatività minima (App Shell)
    CORE_APP_SHELL: Object.freeze([
        '/',
        '/index.html',
        '/js/app.js',
        '/js/panzer-sdk.js',
        '/PWA.webmanifest',
        '/assets-manifest.json'
    ]),

    // Pagina/Risorsa Fallback isolata per navigazione Offline
    OFFLINE_FALLBACK_PAGE: './index.html'
});

// Istanziazione protetta del canale di telemetria condiviso con il Main Thread
const telemetryBus = new BroadcastChannel(PANZER_SW_CONFIG.TELEMETRY_CHANNEL);

/* ============================================================================
 * 2. 🧰 UTILITIES AVANZATE: TELEMETRIA, RETRY & CRITTOGRAFIA SHA-256
 * ============================================================================ */

/**
 * Trasmette un pacchetto di telemetria strutturato sul BroadcastChannel condiviso
 * @param {string} type - Identificativo evento (es. 'SYNC_PROGRESS', 'CORE_UPDATE_RELOAD')
 * @param {Object} payload - Dati di dettaglio associati all'evento
 */
function sendSWTelemetry(type, payload = {}) {
    const message = {
        type: type,
        timestamp: Date.now(),
        source: 'SW_ENGINE',
        version: PANZER_SW_CONFIG.ENGINE_VERSION,
        ...payload
    };
    
    try {
        telemetryBus.postMessage(message);
    } catch (err) {
        console.error('🚨 [SW] Errore nell\'invio della telemetria via BroadcastChannel:', err);
    }
    
    // Logging strutturato in console
    console.log(`⚙️ [SW v${PANZER_SW_CONFIG.ENGINE_VERSION}] 📡 Broadcast [${type}]:`, payload);
}

/**
 * Esegue un fetch resiliente con meccanismo di Retry e Timeout controllato
 * @param {Request|string} request - Request da eseguire
 * @param {number} retries - Tentativi rimasti
 * @param {number} delayMs - Delay progressivo per il retry
 * @returns {Promise<Response>}
 */
async function fetchWithRetry(request, retries = PANZER_SW_CONFIG.MAX_RETRIES, delayMs = 1000) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), PANZER_SW_CONFIG.TIMEOUT_MS);

    try {
        const response = await fetch(request, { signal: controller.signal });
        clearTimeout(timeoutId);
        
        if (!response.ok && response.status >= 500 && retries > 0) {
            throw new Error(`Server Error HTTP ${response.status}`);
        }
        return response;
    } catch (err) {
        clearTimeout(timeoutId);
        if (retries > 0) {
            console.warn(`📡 [SW] Fetch fallita per: ${typeof request === 'string' ? request : request.url}. Tentativi rimasti: ${retries}. Retry tra ${delayMs}ms...`);
            await new Promise(resolve => setTimeout(resolve, delayMs));
            return fetchWithRetry(request, retries - 1, delayMs * 1.5);
        }
        throw err;
    }
}

/**
 * Calcola l'hash SHA-256 in esadecimale di un ArrayBuffer per verificare l'integrità del dato
 * @param {ArrayBuffer} buffer 
 * @returns {Promise<string>}
 */
async function computeSha256Hex(buffer) {
    const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

/* ============================================================================
 * 3. 🔄 CICLO DI VITA: INSTALLAZIONE GRANULARE (`install`)
 * ============================================================================ */
self.addEventListener('install', (event) => {
    console.log(`⚡ [SW] Inizializzazione installazione Service Worker Ente Comunale (v${PANZER_SW_CONFIG.ENGINE_VERSION})...`);
    
    // Forzatura dell'attivazione immediata senza attesa del riavvio dei client
    self.skipWaiting();

    event.waitUntil(
        (async () => {
            try {
                sendSWTelemetry('SYNC_START', { detail: 'Inizio pre-caching ed elaborazione App Shell Core' });

                const cache = await caches.open(PANZER_SW_CONFIG.CACHE_KEYS.CORE);
                let loaded = 0;
                let failed = 0;
                const total = PANZER_SW_CONFIG.CORE_APP_SHELL.length;

                // Caching atomico e granulare con monitoraggio telemetrico integrato
                for (const url of PANZER_SW_CONFIG.CORE_APP_SHELL) {
                    try {
                        const response = await fetchWithRetry(url, 2, 500);
                        if (response.status === 200) {
                            await cache.put(url, response);
                            loaded++;
                        } else {
                            failed++;
                            console.warn(`⚠️ [SW] Risposta non idonea per il pre-caching: ${url} (HTTP ${response.status})`);
                        }
                    } catch (assetErr) {
                        failed++;
                        console.error(`🚨 [SW] Impossibile memorizzare la risorsa Core: ${url}`, assetErr);
                    }

                    sendSWTelemetry('SYNC_PROGRESS', {
                        current: loaded,
                        total: total,
                        percent: Math.floor((loaded / total) * 100),
                        failed_assets: failed,
                        request_failed: failed
                    });
                }

                sendSWTelemetry('SYNC_END', {
                    hasChanged: true,
                    serverVersion: PANZER_SW_CONFIG.ENGINE_VERSION,
                    successCount: loaded,
                    failureCount: failed
                });

                console.log(`✅ [SW] App Shell memorizzata. Risorse caricate: ${loaded}/${total} (Fallite: ${failed}).`);
            } catch (err) {
                console.error('💥 [SW] Errore critico durante la fase di installazione:', err);
                sendSWTelemetry('SYNC_ERROR', { error: err.message });
            }
        })()
    );
});

/* ============================================================================
 * 4. 🧹 CICLO DI VITA: ATTIVAZIONE, CLAIM & BONIFICA CACHE (`activate`)
 * ============================================================================ */
self.addEventListener('activate', (event) => {
    console.log('📦 [SW] Attivazione Service Worker Engine e bonifica vecchie stive...');

    event.waitUntil(
        (async () => {
            // Reclamazione immediata del controllo su tutti i client attivi
            await self.clients.claim();

            // Pulizia selettiva e transazionale delle vecchie stive di cache obsolete
            const cacheNames = await caches.keys();
            const validCacheSet = new Set(Object.values(PANZER_SW_CONFIG.CACHE_KEYS));

            const purgePromises = cacheNames.map(async (cacheName) => {
                if (!validCacheSet.has(cacheName)) {
                    console.log(`🗑️ [SW] Purga stiva obsoleta o non riconosciuta: ${cacheName}`);
                    return caches.delete(cacheName);
                }
            });

            await Promise.all(purgePromises);
            
            sendSWTelemetry('CORE_UPDATE_RELOAD', { 
                status: 'ACTIVATED',
                version: PANZER_SW_CONFIG.ENGINE_VERSION 
            });

            console.log('✅ [SW] Bonifica stiva completata. Service Worker operativo al 100%.');
        })()
    );
});

/* ============================================================================
 * 5. 🌐 INTERCETTAZIONE RETE & STRATEGIE ELASTICHE MULTI-ROUTING (`fetch`)
 * ============================================================================ */
self.addEventListener('fetch', (event) => {
    const request = event.request;
    const url = new URL(request.url);

    // Ignora richieste non-GET o protocolli non HTTP/HTTPS (es. estensioni Browser)
    if (request.method !== 'GET' || !url.protocol.startsWith('http')) {
        return;
    }

    event.respondWith(
        (async () => {
            // A. ROUTING PER ASSETS CORE/STATIC: Cache-First con Network Fallback
            const isCoreAsset = PANZER_SW_CONFIG.CORE_APP_SHELL.some(asset => request.url.includes(asset.replace('./', '')));

            if (isCoreAsset) {
                const cachedCoreResponse = await caches.match(request);
                if (cachedCoreResponse) {
                    return cachedCoreResponse;
                }
            }

            // B. ROUTING PER API / DATI DINAMICI / ASSET MANIFEST: Network-First con Fallback
const isApiOrData = url.pathname.includes('/api/') || 
                    url.pathname.endsWith('.json') ||
                    url.pathname.includes('/resource/') || url.pathname.includes('/api') || 
                    url.pathname.endsWith('.json') ||
            url.pathname.includes('/resource');

                    
            if (isApiOrData) {
                try {
                    const networkResponse = await fetchWithRetry(request, 1, 300);
                    if (networkResponse && networkResponse.status === 200) {
                        const dataCache = await caches.open(PANZER_SW_CONFIG.CACHE_KEYS.DATA);
                        dataCache.put(request, networkResponse.clone());
                    }
                    return networkResponse;
                } catch (networkErr) {
                    console.warn(`📡 [SW] Fallback su Cache Data per API/Dati: ${request.url}`);
                    const cachedData = await caches.match(request);
                    if (cachedData) {
                        return cachedData;
                    }
                }
            }

            // C. STRATEGIA STANDARD DYNAMIC: Stale-While-Revalidate per risorse generiche
            const cachedResponse = await caches.match(request);
            
            const fetchPromise = fetchWithRetry(request, 1, 500)
                .then(async (networkResponse) => {
                    // Caching solo per risposte valide di tipo basic/cors (HTTP 200)
                    if (networkResponse && networkResponse.status === 200 && (networkResponse.type === 'basic' || networkResponse.type === 'cors')) {
                        const dynamicCache = await caches.open(PANZER_SW_CONFIG.CACHE_KEYS.DYNAMIC);
                        dynamicCache.put(request, networkResponse.clone());
                    }
                    return networkResponse;
                })
                .catch(async (error) => {
                    console.warn(`📡 [SW] Dispositivo Offline o errore rete per: ${request.url}`);

                    // Fallback offline per richieste di navigazione HTML
                    if (request.headers.get('accept')?.includes('text/html') || request.mode === 'navigate') {
                        const fallbackResponse = await caches.match(PANZER_SW_CONFIG.OFFLINE_FALLBACK_PAGE);
                        if (fallbackResponse) {
                            return fallbackResponse;
                        }
                    }

                    // Se presente in cache locale, restituisce la copia memorizzata
                    if (cachedResponse) {
                        return cachedResponse;
                    }

                    // Risposta JSON di errore di rete gestito
                    return new Response(
                        JSON.stringify({ 
                            error: 'OFFLINE_MODE', 
                            message: '⚠️ Dispositivo attualmente offline. Risorsa non accessibile in locale.',
                            target: request.url
                        }), 
                        { 
                            status: 503, 
                            headers: { 'Content-Type': 'application/json; charset=utf-8' } 
                        }
                    );
                });

            // Se la risorsa è già presente in cache la restituisce subito, aggiornando in background
            return cachedResponse || fetchPromise;
        })()
    );
});

/* ============================================================================
 * 6. ✉️ MESSAGGI DI COMANDO DIRETTO DA CLIENT & VERIFICA INTEGRITÀ (`message`)
 * ============================================================================ */
self.addEventListener('message', (event) => {
    if (!event.data || !event.data.action) return;

    console.log(`📩 [SW] Ricevuto comando diretto da client: ${event.data.action}`);

    switch (event.data.action) {
        case 'FORCE_PURGE_CACHE':
            event.waitUntil(
                (async () => {
                    const keys = await caches.keys();
                    await Promise.all(keys.map(k => caches.delete(k)));
                    console.log('🗑️ [SW] Purga totale delle stive eseguita su comando client.');
                    sendSWTelemetry('CORE_UPDATE_RELOAD', { reason: 'MANUAL_PURGE' });
                })()
            );
            break;

        case 'LIST_STORAGE_RESOURCES':
            // Raccoglie l'elenco completo di tutte le risorse memorizzate nelle stive di cache
            event.waitUntil(
                (async () => {
                    try {
                        const cacheKeys = await caches.keys();
                        const items = [];

                        for (const cacheName of cacheKeys) {
                            const cache = await caches.open(cacheName);
                            const requests = await cache.keys();

                            for (const req of requests) {
                                const response = await cache.match(req);
                                const contentLength = response ? response.headers.get('content-length') : null;
                                const contentType = response ? response.headers.get('content-type') : null;

                                items.push({
                                    url: req.url,
                                    cacheName: cacheName,
                                    sizeBytes: contentLength ? parseInt(contentLength, 10) : 0,
                                    contentType: contentType || 'unknown'
                                });
                            }
                        }

                        if (event.ports && event.ports[0]) {
                            event.ports[0].postMessage({ success: true, items: items });
                        }
                    } catch (err) {
                        if (event.ports && event.ports[0]) {
                            event.ports[0].postMessage({ success: false, error: err.message });
                        }
                    }
                })()
            );
            break;

        case 'VERIFY_INTEGRITY':
            // Esegue il controllo d'integrità Hash SHA-256 su una risorsa specificata dal client
            event.waitUntil(
                (async () => {
                    const targetUrl = event.data.url || PANZER_SW_CONFIG.OFFLINE_FALLBACK_PAGE;
                    try {
                        const cache = await caches.open(PANZER_SW_CONFIG.CACHE_KEYS.CORE);
                        const response = await cache.match(targetUrl);
                        
                        if (!response) {
                            throw new Error(`Risorsa non trovata in cache: ${targetUrl}`);
                        }

                        const buffer = await response.arrayBuffer();
                        const hashHex = await computeSha256Hex(buffer);

                        if (event.ports && event.ports[0]) {
                            event.ports[0].postMessage({
                                success: true,
                                url: targetUrl,
                                sha256: hashHex,
                                sizeBytes: buffer.byteLength
                            });
                        }
                    } catch (err) {
                        if (event.ports && event.ports[0]) {
                            event.ports[0].postMessage({ success: false, error: err.message });
                        }
                    }
                })()
            );
            break;

        case 'GET_VERSION':
            if (event.ports && event.ports[0]) {
                event.ports[0].postMessage({ 
                    version: PANZER_SW_CONFIG.ENGINE_VERSION,
                    cacheKeys: PANZER_SW_CONFIG.CACHE_KEYS
                });
            }
            break;

        default:
            console.warn(`⚠️ [SW] Azione non riconosciuta: ${event.data.action}`);
            break;
    }
});