/**
 * ============================================================================
 * 🛡️ PANZER SDK v0.37 BETA
 * 
 * SERVICE WORKER CORE ENGINE & NETWORK ORCHESTRATOR
 * ============================================================================
 * @file       sw.js
 * @description Engine ultra-resiliente per la gestione delle PWA della Pubblica
 *              Amministrazione con supporto Zeroization e CSP Ultra-Restrittiva.
 * @author     Valentino Aglianò
 * @license    EUPL-1.2
 * ============================================================================
 */

'use strict';

/* ============================================================================
 * 1. ⚙️ CONFIGURAZIONE DI STATO, ROTTE & STIVA CACHE
 * ============================================================================ */
const PANZER_SW_CONFIG = Object.freeze({
    ENGINE_VERSION: 'Panzer_7.6+',
    CACHE_PREFIX: 'Generico_Comune_01',
    CACHE_KEYS: Object.freeze({
        CORE: 'Generico_Comune_01-core',
        DATA: 'Generico_Comune_01-data',
        DYNAMIC: 'Generico_Comune_01-dynamic',
        OFFLINE: 'Generico_Comune_01-offline'
    }),
    TELEMETRY_CHANNEL: 'PA_TELEMETRY_BUS',
    TIMEOUT_MS: 5000,
    MAX_RETRIES: 3,
    
    CORE_APP_SHELL: Object.freeze([
        './',
        './index.html',
        './js/app.js',
        './js/panzer-sdk.js',
        './PWA.webmanifest',
        './assets-manifest.json'
    ]),

    CORE_APP_RES: Object.freeze('/resource/'),
    OFFLINE_FALLBACK_PAGE: './index.html'
});

const telemetryBus = new BroadcastChannel(PANZER_SW_CONFIG.TELEMETRY_CHANNEL);

/* ============================================================================
 * 2. 🧰 UTILITIES AVANZATE: NORMALIZZAZIONE URL, RETRY & CSP
 * ============================================================================ */

function normalizeUrl(urlStr) {
    try {
        const u = new URL(urlStr, self.location.origin);
        return u.origin + u.pathname;
    } catch (e) {
        return urlStr;
    }
}

function extractAssetUrlsFromManifest(manifestData) {
    const urls = new Set();
    if (!manifestData) return [];

    const rawList = Array.isArray(manifestData) 
        ? manifestData 
        : (manifestData.assets || manifestData.files || manifestData.data || []);

    const coreSet = new Set(
        PANZER_SW_CONFIG.CORE_APP_SHELL.map(u => normalizeUrl(u))
    );

    rawList.forEach(entry => {
        if (typeof entry === 'string') {
            let cleanUrl = entry.trim().replace(/^\/+/, '');
            if (!cleanUrl.startsWith('./')) cleanUrl = `./${cleanUrl}`;
            const normalized = normalizeUrl(cleanUrl);
            if (!coreSet.has(normalized)) {
                urls.add(cleanUrl);
            }
        } else if (typeof entry === 'object' && entry !== null) {
            let dir = (entry.dir || entry.directory || entry.path || '').trim();
            const files = Array.isArray(entry.files) ? entry.files : (entry.file ? [entry.file] : []);

            files.forEach(fileName => {
                if (typeof fileName === 'string') {
                    let fullPath = `${dir}/${fileName}`.replace(/\/+/g, '/').replace(/^\/+/, '');
                    if (!fullPath.startsWith('./')) fullPath = `./${fullPath}`;
                    const normalized = normalizeUrl(fullPath);
                    if (!coreSet.has(normalized)) {
                        urls.add(fullPath);
                    }
                }
            });
        }
    });

    return Array.from(urls);
}

function sendSWTelemetry(type, payload = {}) {
    const message = {
        type: type,
        timestamp: Date.now(),
        source: 'SW_ENGINE',
        version: PANZER_SW_CONFIG.ENGINE_VERSION,
        details: payload,
        ...payload
    };
    
    try {
        telemetryBus.postMessage(message);
    } catch (err) {
        console.error('🚨 [SW] Errore invio telemetria:', err);
    }
}

async function fetchWithRetry(request, retries = PANZER_SW_CONFIG.MAX_RETRIES, delayMs = 1000) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), PANZER_SW_CONFIG.TIMEOUT_MS);

    try {
        const response = await fetch(request, { signal: controller.signal });
        clearTimeout(timeoutId);
        
        if (!response.ok && response.status >= 500 && retries > 0) {
            throw new Error(`Server Error HTTP ${response.status}`);
        }
        return response;
    } catch (err) {
        clearTimeout(timeoutId);
        if (retries > 0) {
            await new Promise(resolve => setTimeout(resolve, delayMs));
            return fetchWithRetry(request, retries - 1, delayMs * 1.5);
        }
        throw err;
    }
}

function applySecurityHeaders(response, isSandboxedAsset = false) {
    if (!response) return response;

    const newHeaders = new Headers(response.headers);
    if (isSandboxedAsset) {
        newHeaders.set('Content-Security-Policy', "default-src 'none'; img-src 'self' data: blob:; style-src 'unsafe-inline'; script-src 'none'; object-src 'none'; form-action 'none'; frame-ancestors 'none'; base-uri 'none';");
    } else {
        newHeaders.set('X-Content-Type-Options', 'nosniff');
        newHeaders.set('X-Frame-Options', 'SAMEORIGIN');
        newHeaders.set('Cross-Origin-Resource-Policy', 'same-origin');
    }

    return new Response(response.body, {
        status: response.status,
        statusText: response.statusText,
        headers: newHeaders
    });
}

/* ============================================================================
 * 3. 🔄 CICLO DI VITA: INSTALLAZIONE GRANULARE (`install`)
 * ============================================================================ */
self.addEventListener('install', (event) => {
    console.log(`⚡ [SW] Inizializzazione Service Worker Engine (v${PANZER_SW_CONFIG.ENGINE_VERSION})...`);
    self.skipWaiting();

    event.waitUntil(
        (async () => {
            try {
                const cacheCore = await caches.open(PANZER_SW_CONFIG.CACHE_KEYS.CORE);
                let loaded = 0;

                for (const url of PANZER_SW_CONFIG.CORE_APP_SHELL) {
                    try {
                        const response = await fetchWithRetry(url, 2, 500);
                        if (response.status === 200) {
                            await cacheCore.put(normalizeUrl(url), response);
                            loaded++;
                        }
                    } catch (assetErr) {
                        console.warn(`⚠️ [SW] Fallito caching iniziale per ${url}`);
                    }
                }
                console.log(`✅ [SW] App Shell memorizzata. Risorse pronte: ${loaded}.`);
            } catch (err) {
                console.error('💥 [SW] Errore installazione:', err);
            }
        })()
    );
});

/* ============================================================================
 * 4. 🧹 CICLO DI VITA: ATTIVAZIONE & PURGA STIVE (`activate`)
 * ============================================================================ */
self.addEventListener('activate', (event) => {
    event.waitUntil(
        (async () => {
            await self.clients.claim();
            const cacheNames = await caches.keys();
            const validCacheSet = new Set(Object.values(PANZER_SW_CONFIG.CACHE_KEYS));

            await Promise.all(
                cacheNames.map(cacheName => {
                    if (!validCacheSet.has(cacheName)) {
                        console.log(`🗑️ [SW] Purga cache obsoleta: ${cacheName}`);
                        return caches.delete(cacheName);
                    }
                })
            );
        })()
    );
});

/* ============================================================================
 * 5. 🌐 INTERCETTAZIONE RETE & ROUTING (`fetch`)
 * ============================================================================ */
self.addEventListener('fetch', (event) => {
    const request = event.request;
    const url = new URL(request.url);

    if (request.method !== 'GET' || !url.protocol.startsWith('http')) return;

    event.respondWith(
        (async () => {
            const normalizedReqUrl = normalizeUrl(request.url);

            const matchInAnyCache = async (normUrl) => {
                const cacheKeys = Object.values(PANZER_SW_CONFIG.CACHE_KEYS);
                for (const key of cacheKeys) {
                    const cache = await caches.open(key);
                    const match = await cache.match(normUrl);
                    if (match) return match;
                }
                return null;
            };

            const cleanPath = url.pathname.replace(/^\/+/, '');
            const isCoreAsset = PANZER_SW_CONFIG.CORE_APP_SHELL.some(asset => {
                const cleanAsset = asset.replace(/^\.\//, '').replace(/^\/+/, '');
                return cleanAsset !== '' && (cleanPath === cleanAsset || cleanPath.endsWith('/' + cleanAsset));
            });

            const isResourceAsset = url.pathname.includes(PANZER_SW_CONFIG.CORE_APP_RES) || /\.(pdf|jpg|jpeg|png|webp|svg|gif|woff2?|ttf)$/i.test(url.pathname);

            // 1. Cerca prima nella stiva localmente memorizzata
            const cachedResponse = await matchInAnyCache(normalizedReqUrl);
            if (cachedResponse) {
                return applySecurityHeaders(cachedResponse, isResourceAsset);
            }

            // 2. Se non presente in cache, effettua il fetch di rete senza duplicare in DYNAMIC
            try {
                const networkResponse = await fetchWithRetry(request, 1, 500);
                return applySecurityHeaders(networkResponse, isResourceAsset && !isCoreAsset);
            } catch (err) {
                if (request.headers.get('accept')?.includes('text/html') || request.mode === 'navigate') {
                    const fallbackResponse = await matchInAnyCache(normalizeUrl(PANZER_SW_CONFIG.OFFLINE_FALLBACK_PAGE));
                    if (fallbackResponse) return applySecurityHeaders(fallbackResponse, false);
                }

                return new Response(
                    JSON.stringify({ error: 'OFFLINE_MODE', message: '⚠️ Dispositivo offline e risorsa non presente in stiva.' }), 
                    { status: 503, headers: { 'Content-Type': 'application/json; charset=utf-8' } }
                );
            }
        })()
    );
});

/* ============================================================================
 * 6. ✉️ COMANDI DIRETTI DA CLIENT (`message`): PURGA & ZEROIZATION
 * ============================================================================ */
self.addEventListener('message', (event) => {
    if (!event.data || !event.data.action) return;

    switch (event.data.action) {
        case 'FORCE_ZEROIZATION':
        case 'FORCE_PURGE_CACHE':
            event.waitUntil(
                (async () => {
                    const keys = await caches.keys();
                    await Promise.all(keys.map(k => caches.delete(k)));
                    sendSWTelemetry('ZEROIZATION_COMPLETE', { 
                        action: event.data.action,
                        status: 'SUCCESS',
                        timestamp: Date.now() 
                    });
                    console.log(`🧹 [SW] Protocollo Zeroization completato. Tutte le stive cache eliminate.`);
                })()
            );
            break;

        case 'GET_VERSION':
            if (event.ports && event.ports[0]) {
                event.ports[0].postMessage({ 
                    version: PANZER_SW_CONFIG.ENGINE_VERSION,
                    cacheKeys: PANZER_SW_CONFIG.CACHE_KEYS
                });
            }
            break;
    }
});