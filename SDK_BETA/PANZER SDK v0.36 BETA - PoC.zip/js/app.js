/**
 * 🛡️ PANZER SDK - BETA v0.3
 *
 * Modulo di controllo integrato per download pacchetti, telemetria in tempo reale,
 * ispezione stiva, crittografia/stoccaggio offline, protocollo di Zeroization avanzato
 * e Viewer Sandboxed con CSP ultra-restrittiva (Sola Lettura) + Apertura diretta per test.
 */

let PanzerSDKModule = null;
try {
    const imported = await import('./panzer-sdk.js');
    PanzerSDKModule = imported.PanzerSDK || imported.default;
} catch (e) {
    console.warn("⚠️ [ SDK Panzer ] 'panzer-sdk.js' in modalità fallback/mock.");
}

(() => {
    'use strict';

    /* ========================================================================
     * 1. CONFIGURAZIONE GLOBALE ED ELEMENTI DOM
     * ======================================================================== */
    const CONFIG = Object.freeze({
        SDK_CHANNEL_NAME: 'PA_TELEMETRY_BUS',
        SW_SCRIPT_PATH: './sw.js',
        DB_FETCH_ENDPOINT: './assets-manifest.json',
        CACHE_PREFIX: 'Generico_Comune_01',
        CACHE_KEYS: Object.freeze({
            CORE: 'Generico_Comune_01-core',
            DATA: 'Generico_Comune_01-data',
            DYNAMIC: 'Generico_Comune_01-dynamic',
            OFFLINE: 'Generico_Comune_01-offline'
        }),
        
        CORE_APP_SHELL: Object.freeze([
            './',
            './index.html',
            './js/app.js',
            './js/panzer-sdk.js',
            './PWA.webmanifest',
            './assets-manifest.json'
        ]),
        
        CORE_APP_RES: Object.freeze('/resource/'),

        DOM_IDS: Object.freeze({
            STATUS_BADGE: 'PA-status-badge',
            PROGRESS_BAR: 'PA-progress-bar',
            PROGRESS_TEXT: 'panzer-progress-text',
            METRIC_COMPLETED: 'metric-completed',
            METRIC_TOTAL: 'metric-total',
            METRIC_FAILED: 'metric-failed',
            METRIC_RETRIES: 'metric-retries',
            TERMINAL_OUTPUT: 'PA-terminal-output',
            SYNC_BTN: 'PA-btn-sync',
            PURGE_BTN: 'PA-btn-purge',
            CLEAR_LOG_BTN: 'panzer-btn-clear-log',
            REFRESH_STORAGE_BTN: 'PA-btn-refresh-storage',
            STORAGE_SEARCH_INPUT: 'PA-storage-search',
            STORAGE_TBODY: 'PA-storage-tbody'
        })
    });

    const state = {
        sdkInstance: null,
        isSyncing: false,
        telemetryBus: null,
        storageItems: [],
        metrics: {
            completed: 0,
            total: 0,
            failed: 0,
            retries: 0
        }
    };

    const dom = {};

    /* ========================================================================
     * 2. HELPER URL & RETE CON RETRY AUTOMATICI E TIMEOUT
     * ======================================================================== */

    function normalizeUrl(urlStr) {
        try {
            const u = new URL(urlStr, window.location.origin);
            return u.origin + u.pathname;
        } catch (e) {
            return urlStr;
        }
    }

    async function checkInAnyCache(normalizedUrl) {
        const keys = Object.values(CONFIG.CACHE_KEYS);
        for (const key of keys) {
            const cache = await caches.open(key);
            const match = await cache.match(normalizedUrl);
            if (match) return match;
        }
        return null;
    }

    async function fetchWithRetry(url, retries = 3, delayMs = 500, timeoutMs = 5000) {
        for (let attempt = 1; attempt <= retries; attempt++) {
            try {
                const controller = new AbortController();
                const timer = setTimeout(() => controller.abort(), timeoutMs);
                
                const response = await fetch(url, { signal: controller.signal });
                clearTimeout(timer);

                if (response.ok) return response;

                if (attempt < retries) {
                    state.metrics.retries++;
                    processTelemetryEvent({ type: 'SYNC_RETRY', details: { url, attempt, status: response.status } });
                    await new Promise(r => setTimeout(r, delayMs * attempt));
                } else {
                    throw new Error(`HTTP ${response.status}`);
                }
            } catch (err) {
                if (attempt < retries) {
                    state.metrics.retries++;
                    processTelemetryEvent({ type: 'SYNC_RETRY', details: { url, attempt, error: err.message } });
                    await new Promise(r => setTimeout(r, delayMs * attempt));
                } else {
                    throw err;
                }
            }
        }
    }

    /* ========================================================================
     * 3. LOGGING, ESTRAZIONE URL E INTERFACCIA UTENTE
     * ======================================================================== */

    function extractAssetUrlsFromManifest(manifestData) {
        const urls = new Set();
        if (!manifestData) return [];

        const rawList = Array.isArray(manifestData) 
            ? manifestData 
            : (manifestData.assets || manifestData.files || manifestData.data || []);

        const coreSet = new Set(
            CONFIG.CORE_APP_SHELL.map(u => normalizeUrl(u))
        );

        rawList.forEach(entry => {
            if (typeof entry === 'string') {
                let cleanUrl = entry.trim().replace(/^\/+/, '');
                if (!cleanUrl.startsWith('./')) cleanUrl = `./${cleanUrl}`;
                const norm = normalizeUrl(cleanUrl);
                if (!coreSet.has(norm)) {
                    urls.add(cleanUrl);
                }
            } else if (typeof entry === 'object' && entry !== null) {
                let dir = (entry.dir || entry.directory || entry.path || '').trim();
                const files = Array.isArray(entry.files) ? entry.files : (entry.file ? [entry.file] : []);

                files.forEach(fileName => {
                    if (typeof fileName === 'string') {
                        let fullPath = `${dir}/${fileName}`.replace(/\/+/g, '/').replace(/^\/+/, '');
                        if (!fullPath.startsWith('./')) fullPath = `./${fullPath}`;
                        const norm = normalizeUrl(fullPath);
                        if (!coreSet.has(norm)) {
                            urls.add(fullPath);
                        }
                    }
                });
            }
        });

        return Array.from(urls);
    }
    
    function logToTerminal(level, message, payload = null) {
        const time = new Date().toLocaleTimeString('it-IT', { hour12: false });
        let icon = 'ℹ️';
        let cssClass = 'log-info';

        switch (level) {
            case 'SUCCESS':  icon = '✅'; cssClass = 'log-success'; break;
            case 'WARN':     icon = '⚠️'; cssClass = 'log-warn'; break;
            case 'ERROR':    icon = '🚨'; cssClass = 'log-error'; break;
            case 'SYNC':     icon = '🔄'; cssClass = 'log-sync'; break;
            case 'VAULT':    icon = '🔐'; cssClass = 'log-vault'; break;
            case 'INIT':     icon = '⚡'; cssClass = 'log-info'; break;
            case 'ZEROIZE':  icon = '🧹'; cssClass = 'log-warn'; break;
        }

        const logText = `[${time}] ${icon} [${level}] ${message}`;

        if (level === 'ERROR') console.error(logText, payload || '');
        else if (level === 'WARN') console.warn(logText, payload || '');
        else console.log(logText, payload || '');

        if (dom.TERMINAL_OUTPUT) {
            const line = document.createElement('div');
            line.className = `terminal-line ${cssClass}`;
            line.textContent = logText + (payload ? ` | Det: ${JSON.stringify(payload)}` : '');
            dom.TERMINAL_OUTPUT.appendChild(line);
            
            requestAnimationFrame(() => {
                dom.TERMINAL_OUTPUT.scrollTop = dom.TERMINAL_OUTPUT.scrollHeight;
            });
        }
    }

    function cacheDOMReferences() {
        Object.keys(CONFIG.DOM_IDS).forEach(key => {
            dom[key] = document.getElementById(CONFIG.DOM_IDS[key]);
        });
    }

    function updateBadge(text, typeClass) {
        if (!dom.STATUS_BADGE) return;
        dom.STATUS_BADGE.textContent = text;
        dom.STATUS_BADGE.className = `badge-status ${typeClass}`;
    }

    /* ========================================================================
     * 4. TELEMETRIA BROADCAST CHANNEL
     * ======================================================================== */

    function setupTelemetryBus() {
        try {
            state.telemetryBus = new BroadcastChannel(CONFIG.SDK_CHANNEL_NAME);
            state.telemetryBus.onmessage = (event) => {
                if (event.data) processTelemetryEvent(event.data);
            };
            logToTerminal('INIT', `Canale di telemetria agganciato: '${CONFIG.SDK_CHANNEL_NAME}'`);
        } catch (err) {
            logToTerminal('WARN', 'BroadcastChannel non supportato, canale fallback attivo.', err.message);
        }
    }

    function processTelemetryEvent(evt) {
        if (!evt || !evt.type) return;

        const det = evt.details || evt.detail || evt;

        switch (evt.type) {
            case 'SYNC_START':
                state.isSyncing = true;
                updateBadge('🔄 Sincronizzazione in corso', 'badge-sync');
                logToTerminal('SYNC', 'Avvio procedura di sincronizzazione multi-step...');
                resetMetrics();
                break;

            case 'SYNC_PROGRESS':
                state.metrics.completed = det.current || state.metrics.completed;
                state.metrics.total = det.total || state.metrics.total;
                state.metrics.failed = det.failed_assets || state.metrics.failed;
                updateMetricsUI(det.percent || 0);
                break;

            case 'SYNC_RETRY':
                logToTerminal('WARN', 'Retry di rete per risorsa instabile...', det);
                break;

            case 'VAULT_STORE_SUCCESS':
                logToTerminal('VAULT', `Pacchetto archiviato: ${evt.assetPath || det.assetPath || 'Asset'}`);
                break;

            case 'SYNC_ERROR':
                state.isSyncing = false;
                updateBadge('🚨 Errore Sincronizzazione', 'badge-error');
                logToTerminal('ERROR', 'Errore durante lo scaricamento stiva:', det);
                break;

            case 'SYNC_END':
                state.isSyncing = false;
                updateMetricsUI(100);
                updateBadge('🟢 Stiva Aggiornata & Criptata', 'badge-ready');
                logToTerminal('SUCCESS', `Sincronizzazione completata! Modificato: ${det.hasChanged ? 'SÌ 🔄' : 'NO 🔒'}`, {
                    versioneServer: det.serverVersion || '7.6.0',
                    totaleElaborati: state.metrics.total,
                    falliti: state.metrics.failed
                });
                refreshStorageVaultInspector();
                break;

            default:
                break;
        }
    }

    function updateMetricsUI(percent) {
        const pct = Math.min(100, Math.max(0, Math.floor(percent)));

        if (dom.PROGRESS_BAR) dom.PROGRESS_BAR.value = pct;
        if (dom.PROGRESS_TEXT) dom.PROGRESS_TEXT.textContent = `${pct}% (${state.metrics.completed}/${state.metrics.total})`;

        if (dom.METRIC_COMPLETED) dom.METRIC_COMPLETED.textContent = state.metrics.completed;
        if (dom.METRIC_TOTAL) dom.METRIC_TOTAL.textContent = state.metrics.total;
        if (dom.METRIC_FAILED) dom.METRIC_FAILED.textContent = state.metrics.failed;
        if (dom.METRIC_RETRIES) dom.METRIC_RETRIES.textContent = state.metrics.retries;
    }

    function resetMetrics() {
        state.metrics = { completed: 0, total: 0, failed: 0, retries: 0 };
        updateMetricsUI(0);
    }

    /* ========================================================================
     * 5. ESECUZIONE SINCRONIZZAZIONE RESILIENTE DEDUPLICATA
     * ======================================================================== */

    async function executeBunkerSync() {
        if (state.isSyncing) {
            logToTerminal('WARN', 'Sincronizzazione già in corso...');
            return;
        }

        state.isSyncing = true;
        processTelemetryEvent({ type: 'SYNC_START' });

        try {
            logToTerminal('SYNC', '▶️ FASE 1/3: Sincronizzazione resiliente Core App Shell...');
            const coreCache = await caches.open(CONFIG.CACHE_KEYS.CORE);
            const coreAssets = CONFIG.CORE_APP_SHELL;
            let currentProcessed = 0;

            for (const assetUrl of coreAssets) {
                const normUrl = normalizeUrl(assetUrl);
                try {
                    const alreadyCached = await checkInAnyCache(normUrl);
                    if (!alreadyCached) {
                        const res = await fetchWithRetry(assetUrl, 3, 500);
                        await coreCache.put(normUrl, res.clone());
                        logToTerminal('VAULT', `Core Asset salvato: ${assetUrl}`);
                    } else {
                        logToTerminal('VAULT', `Core Asset già presente in stiva (Skipped): ${assetUrl}`);
                    }
                    state.metrics.completed++;
                } catch (coreErr) {
                    state.metrics.failed++;
                    logToTerminal('WARN', `Fallito scaricamento Core Asset (${assetUrl}): ${coreErr.message}`);
                }

                currentProcessed++;
                const phasePct = Math.round((currentProcessed / coreAssets.length) * 30);
                processTelemetryEvent({
                    type: 'SYNC_PROGRESS',
                    details: { current: state.metrics.completed, total: coreAssets.length, failed_assets: state.metrics.failed, percent: phasePct }
                });
            }

            logToTerminal('SYNC', '▶️ FASE 2/3: Lettura e validazione del manifesto risorse...');
            let dbContent = null;
            try {
                const response = await fetchWithRetry(CONFIG.DB_FETCH_ENDPOINT, 3, 500);
                dbContent = await response.json();
            } catch (e) {
                logToTerminal('WARN', `'${CONFIG.DB_FETCH_ENDPOINT}' non raggiungibile via rete. Tentativo di recupero dalla Cache...`);
                try {
                    const cachedManifest = await checkInAnyCache(normalizeUrl(CONFIG.DB_FETCH_ENDPOINT));
                    if (cachedManifest) {
                        dbContent = await cachedManifest.json();
                        logToTerminal('VAULT', 'Manifesto risorse recuperato con successo dalla Cache locale.');
                    }
                } catch (cacheErr) {
                    logToTerminal('WARN', 'Impossibile recuperare il manifesto anche dalla Cache.');
                }
            }

            logToTerminal('SYNC', '▶️ FASE 3/3: Scaricamento e archiviazione risorse dal manifesto...');
            const assetList = extractAssetUrlsFromManifest(dbContent);
            const dataCache = await caches.open(CONFIG.CACHE_KEYS.DATA);

            const grandTotal = coreAssets.length + assetList.length;
            state.metrics.total = grandTotal;

            for (let i = 0; i < assetList.length; i++) {
                const assetUrl = assetList[i];
                const normUrl = normalizeUrl(assetUrl);
                try {
                    const alreadyCached = await checkInAnyCache(normUrl);
                    if (!alreadyCached) {
                        const res = await fetchWithRetry(assetUrl, 3, 500);
                        await dataCache.put(normUrl, res.clone());
                        processTelemetryEvent({ type: 'VAULT_STORE_SUCCESS', assetPath: assetUrl });
                    } else {
                        logToTerminal('VAULT', `Risorsa già in stiva (Skipped): ${assetUrl}`);
                    }
                    state.metrics.completed++;
                } catch (fetchErr) {
                    state.metrics.failed++;
                    logToTerminal('WARN', `Fallito scaricamento Data Asset (${assetUrl}): ${fetchErr.message}`);
                }

                currentProcessed++;
                const globalPct = Math.round((currentProcessed / grandTotal) * 100);
                processTelemetryEvent({
                    type: 'SYNC_PROGRESS',
                    details: { current: state.metrics.completed, total: grandTotal, failed_assets: state.metrics.failed, percent: globalPct }
                });
            }

            processTelemetryEvent({
                type: 'SYNC_END',
                details: { hasChanged: true, serverVersion: dbContent?.version || '7.6.0' }
            });

        } catch (err) {
            logToTerminal('ERROR', 'Fallimento critico durante il flusso di sincronizzazione:', err.message);
            updateBadge('🚨 Errore Sincronizzazione', 'badge-error');
        } finally {
            state.isSyncing = false;
        }
    }

    /* ========================================================================
     * 6. PROTOCOLLO DI ZEROIZATION INTEGRALE
     * ======================================================================== */

    async function zeroizeBunkerState() {
        logToTerminal('ZEROIZE', '🧹 Avvio Protocollo di Zeroization Integrale...');

        if (state.sdkInstance) {
            try {
                if (typeof state.sdkInstance.zeroize === 'function') {
                    state.sdkInstance.zeroize();
                } else if (typeof state.sdkInstance.destroy === 'function') {
                    state.sdkInstance.destroy();
                }
                logToTerminal('ZEROIZE', '🔒 SDK Panzer: Buffer di memoria azzerati.');
            } catch (sdkErr) {
                logToTerminal('WARN', 'Errore durante la Zeroization dell\'SDK:', sdkErr.message);
            }
        }

        if (Array.isArray(state.storageItems)) {
            state.storageItems.fill(null);
            state.storageItems.length = 0;
        }
        resetMetrics();
        state.isSyncing = false;

        if (navigator.serviceWorker?.controller) {
            navigator.serviceWorker.controller.postMessage({ action: 'FORCE_ZEROIZATION' });
            logToTerminal('ZEROIZE', '📡 Dispatched FORCE_ZEROIZATION to Service Worker.');
        }

        try {
            const cacheKeys = await caches.keys();
            await Promise.all(cacheKeys.map(key => caches.delete(key)));
            logToTerminal('ZEROIZE', '🗑️ Cache Storage: Tutte le stive eliminate con successo.');
        } catch (cacheErr) {
            logToTerminal('ERROR', 'Fallimento purga Cache Storage:', cacheErr.message);
        }

        if (dom.STORAGE_TBODY) {
            dom.STORAGE_TBODY.innerHTML = `
                <tr>
                    <td colspan="5" style="text-align: center; color: #da3633; padding: 15px; font-weight: bold;">
                        🧹 SISTEMA AZZERATO - NESSUN DATO IN MEMORIA O CACHE
                    </td>
                </tr>`;
        }

        if (dom.STORAGE_SEARCH_INPUT) dom.STORAGE_SEARCH_INPUT.value = '';
        updateBadge('🔴 Azzerato (Zeroized)', 'badge-error');

        logToTerminal('SUCCESS', '✅ Zeroization completata. Nessun residuo presente in memoria.');
    }

    /* ========================================================================
     * 7. VIEWER SANDBOXED PROTETTO & APERTURA DIRETTA TEST (SENZA CSP)
     * ======================================================================== */

    async function openSecureSandboxedViewer(assetUrl, contentType) {
        logToTerminal('VAULT', `Inizializzazione Container Sandboxed per: ${assetUrl}`);

        try {
            const normUrl = normalizeUrl(assetUrl);
            let response = await checkInAnyCache(normUrl);

            if (!response) {
                response = await fetch(assetUrl);
            }

            const blob = await response.blob();
            const blobUrl = URL.createObjectURL(blob);

            let modal = document.getElementById('panzer-sandbox-modal');
            if (!modal) {
                modal = document.createElement('div');
                modal.id = 'panzer-sandbox-modal';
                modal.style.cssText = 'position:fixed;top:0;left:0;width:100vw;height:100vh;background:rgba(0,0,0,0.85);z-index:99999;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:20px;box-sizing:border-box;backdrop-filter:blur(5px);';
                document.body.appendChild(modal);
            }

            modal.innerHTML = `
                <div style="width:100%;max-width:1100px;height:90vh;background:#0d1117;border:1px solid #30363d;border-radius:8px;display:flex;flex-direction:column;overflow:hidden;box-shadow:0 10px 30px rgba(0,0,0,0.9);">
                    <div style="padding:12px 16px;background:#161b22;border-bottom:1px solid #30363d;display:flex;justify-content:space-between;align-items:center;">
                        <span style="color:#58a6ff;font-weight:bold;font-family:monospace;font-size:0.85rem;">🔒 VIEWER SANDBOXED (SOLO LETTURA / CSP RESTRITTIVA) | ${contentType}</span>
                        <button id="panzer-close-modal-btn" style="background:#da3633;color:#fff;border:none;padding:6px 14px;border-radius:4px;cursor:pointer;font-weight:bold;font-size:0.85rem;">❌ Chiudi Safe Viewer</button>
                    </div>
                    <div style="flex:1;position:relative;background:#010409;">
                        <iframe id="panzer-sandbox-frame" sandbox="allow-same-origin" style="width:100%;height:100%;border:none;" src="${blobUrl}"></iframe>
                    </div>
                </div>
            `;

            modal.style.display = 'flex';

            const closeBtn = document.getElementById('panzer-close-modal-btn');
            const closeHandler = () => {
                const iframe = document.getElementById('panzer-sandbox-frame');
                if (iframe) iframe.src = 'about:blank';
                URL.revokeObjectURL(blobUrl);
                modal.style.display = 'none';
                modal.innerHTML = '';
                logToTerminal('VAULT', 'Viewer Sandboxed chiuso. Blob URL bonificato ed eliminato dalla RAM.');
            };

            closeBtn.addEventListener('click', closeHandler, { once: true });
        } catch (err) {
            logToTerminal('ERROR', 'Impossibile accedere alla risorsa nel viewer protetto:', err.message);
        }
    }

    async function openUnsafeDirectViewer(assetUrl) {
        logToTerminal('VAULT', `🧪 TEST: Apertura diretta senza restrizioni CSP per: ${assetUrl}`);
        try {
            const normUrl = normalizeUrl(assetUrl);
            let response = await checkInAnyCache(normUrl);

            if (!response) {
                response = await fetch(assetUrl);
            }

            const blob = await response.blob();
            const blobUrl = URL.createObjectURL(blob);
            window.open(blobUrl, '_blank');
            logToTerminal('SUCCESS', `🧪 Scheda di test senza CSP aperta con successo per ${assetUrl}`);
        } catch (err) {
            logToTerminal('ERROR', 'Impossibile aprire la risorsa in modalità diretta:', err.message);
        }
    }

    /* ========================================================================
     * 8. ISPETTORE CACHE / STIVA LOCALE
     * ======================================================================== */

    async function refreshStorageVaultInspector() {
        if (!dom.STORAGE_TBODY) return;

        try {
            const cacheKeys = await caches.keys();
            const foundAssetsMap = new Map();

            for (const cacheName of cacheKeys) {
                const cache = await caches.open(cacheName);
                const requests = await cache.keys();

                for (const req of requests) {
                    const normReqUrl = normalizeUrl(req.url);
                    if (!foundAssetsMap.has(normReqUrl)) {
                        const res = await cache.match(req);
                        if (res) {
                            let size = 0;
                            try {
                                const blob = await res.clone().blob();
                                size = blob.size;
                            } catch (e) {
                                size = parseInt(res.headers.get('content-length') || '0', 10);
                            }

                            foundAssetsMap.set(normReqUrl, {
                                url: req.url,
                                normalizedUrl: normReqUrl,
                                cacheName: cacheName,
                                contentType: res.headers.get('Content-Type') || 'application/octet-stream',
                                sizeBytes: size
                            });
                        }
                    }
                }
            }

            const foundAssets = Array.from(foundAssetsMap.values());
            state.storageItems = foundAssets;
            renderStorageTable(foundAssets);
            logToTerminal('VAULT', `Ispezione stiva (Deduplicata): Trovate ${foundAssets.length} risorse univoche memorizzate.`);
        } catch (err) {
            logToTerminal('ERROR', 'Errore scansione Cache Storage:', err.message);
        }
    }

    function renderStorageTable(items) {
        if (!dom.STORAGE_TBODY) return;

        const query = (dom.STORAGE_SEARCH_INPUT?.value || '').toLowerCase().trim();
        const filtered = items.filter(item => 
            item.url.toLowerCase().includes(query) ||
            item.contentType.toLowerCase().includes(query) ||
            item.cacheName.toLowerCase().includes(query)
        );

        if (filtered.length === 0) {
            dom.STORAGE_TBODY.innerHTML = `
                <tr>
                    <td colspan="5" style="text-align: center; color: #8b949e; padding: 15px;">
                        ${query ? 'Nessun risultato corrisponde alla ricerca.' : 'Stiva locale vuota.'}
                    </td>
                </tr>`;
            return;
        }

        dom.STORAGE_TBODY.innerHTML = filtered.map(item => {
            const urlObj = new URL(item.url, window.location.href);
            const filename = urlObj.pathname.split('/').pop() || urlObj.pathname;
            const sizeKb = (item.sizeBytes / 1024).toFixed(1);
            const isPdf = filename.toLowerCase().endsWith('.pdf');

            return `
                <tr>
                    <td style="font-weight: 600; color: #c9d1d9;" title="${item.url}">
                        ${isPdf ? '📄' : '📦'} ${filename}
                    </td>
                    <td style="color: #8b949e; font-size: 0.8rem;">${item.contentType}</td>
                    <td style="font-family: monospace; font-size: 0.8rem;">${sizeKb} KB</td>
                    <td style="color: #a371f7; font-size: 0.8rem;">${item.cacheName}</td>
                    <td>
                        <div style="display: flex; gap: 6px;">
                            <button type="button" class="btn btn-sm btn-view-sandbox" data-url="${encodeURIComponent(item.url)}" data-type="${item.contentType}" style="cursor:pointer;padding:4px 8px;">
                                🔒 Con CSP
                            </button>
                            <button type="button" class="btn btn-sm btn-view-direct" data-url="${encodeURIComponent(item.url)}" style="cursor:pointer;padding:4px 8px;background:#1f6beb;color:#fff;border-color:#388bfd;">
                                🔓 Senza CSP
                            </button>
                        </div>
                    </td>
                </tr>`;
        }).join('');

        const viewBtns = dom.STORAGE_TBODY.querySelectorAll('.btn-view-sandbox');
        viewBtns.forEach(btn => {
            btn.addEventListener('click', (e) => {
                const targetUrl = decodeURIComponent(e.currentTarget.getAttribute('data-url'));
                const targetType = e.currentTarget.getAttribute('data-type');
                openSecureSandboxedViewer(targetUrl, targetType);
            });
        });

        const directBtns = dom.STORAGE_TBODY.querySelectorAll('.btn-view-direct');
        directBtns.forEach(btn => {
            btn.addEventListener('click', (e) => {
                const targetUrl = decodeURIComponent(e.currentTarget.getAttribute('data-url'));
                openUnsafeDirectViewer(targetUrl);
            });
        });
    }

    /* ========================================================================
     * 9. REGISTRAZIONE SERVICE WORKER ED INIZIALIZZAZIONE
     * ======================================================================== */

    async function registerServiceWorker() {
        if (!('serviceWorker' in navigator)) return;
        try {
            const reg = await navigator.serviceWorker.register(CONFIG.SW_SCRIPT_PATH, { scope: './' });
            logToTerminal('INIT', `Service Worker attivo (${CONFIG.SW_SCRIPT_PATH}). Scope: ${reg.scope}`);
        } catch (err) {
            logToTerminal('WARN', 'Service Worker non registrato (ambiente di dev locale o assenza HTTPS).');
        }
    }

    async function initApp() {
        cacheDOMReferences();
        logToTerminal('INIT', 'Inizializzazione Bunker Console v7.6...');

        setupTelemetryBus();
        await registerServiceWorker();

        if (PanzerSDKModule) {
            try {
                state.sdkInstance = new PanzerSDKModule();
                logToTerminal('SUCCESS', 'PanzerSDK caricato e agganciato.');
            } catch (e) {
                logToTerminal('WARN', 'Istanza SDK fallita, attivo modulo integrato.');
            }
        } else {
            logToTerminal('WARN', 'Esecuzione in modalità Standalone Engine.');
        }

        if (dom.SYNC_BTN) dom.SYNC_BTN.addEventListener('click', executeBunkerSync);

        if (dom.PURGE_BTN) {
            dom.PURGE_BTN.addEventListener('click', async () => {
                if (confirm('CONFERMA ZEROIZATION: Vuoi azzerare completamente la stiva e i buffer in memoria RAM?')) {
                    await zeroizeBunkerState();
                }
            });
        }

        if (dom.CLEAR_LOG_BTN && dom.TERMINAL_OUTPUT) {
            dom.CLEAR_LOG_BTN.addEventListener('click', () => dom.TERMINAL_OUTPUT.innerHTML = '');
        }

        if (dom.REFRESH_STORAGE_BTN) {
            dom.REFRESH_STORAGE_BTN.addEventListener('click', refreshStorageVaultInspector);
        }

        if (dom.STORAGE_SEARCH_INPUT) {
            dom.STORAGE_SEARCH_INPUT.addEventListener('input', () => renderStorageTable(state.storageItems));
        }

        updateBadge('🟢 Pronto - Sistema Operativo', 'badge-ready');
        refreshStorageVaultInspector();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initApp);
    } else {
        initApp();
    }
})();