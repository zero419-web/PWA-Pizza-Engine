/**
 * 🛡️🚀 PANZER SDK v7.6+ Military Edition - Enterprise Client-Side Monolith
 * File: SDK.js / panzer-sdk.js
 * 
 * [PARTE 1 DI 5]
 * - Core Framework Orchestrator & Initialization Engine
 * - Custom Async Event Emitter & Event Bus System
 * - Advanced Web Crypto Engine (AES-GCM 256-bit, PBKDF2 Key Derivation, HMAC-SHA256)
 * - Cryptographic Key Rotation & Vault Memory Sanitizer
 * - Service Worker Lifecycle & IPC Channel Handshake
 */

class PanzerSDK {
    // State Private Flags & Registries
    #swRegistration = null;
    #isInitialized = false;
    #eventListeners = new Map();
    #messageQueue = [];
    #telemetryQueue = [];
    #cryptoKeyCache = new Map();
    
    // Configuration Registry
    #config = {
        swPath: '/SW.js',
        swScope: '/',
        vaultDbName: 'PWA_Vault',
        vaultStoreName: 'keys',
        vaultKeyName: 'master_key',
        cryptoSaltStoreName: 'crypto_salts',
        pbkdf2Iterations: 100000,
        autoSync: true,
        maxTelemetryBatch: 25,
        telemetryFlushInterval: 30000,
        circuitBreakerThreshold: 5,
        circuitBreakerTimeout: 60000,
        enableDebugLogs: true
    };

    constructor() {
        this.#initNetworkListeners();
        this.#initUnhandledErrorInterceptors();
    }

    /* ========================================================================= */
    /* 1. CORE ORCHESTRATOR & INITIALIZATION ENGINE                              */
    /* ========================================================================= */

    /**
     * 🏁 Inizializzazione globale dell'SDK Panzer e handshake con Service Worker.
     * @param {Object} [options={}] - Override delle impostazioni predefinite.
     * @returns {Promise<ServiceWorkerRegistration|null>}
     */
    async init(options = {}) {
        if (this.#isInitialized) {
            this.#log('WARN', 'Core', 'PanzerSDK è già stato inizializzato nel contesto corrente.');
            return this.#swRegistration;
        }

        Object.assign(this.#config, options);
        this.#log('INFO', 'Core', 'Inizio sequenza di boot per PANZER SDK v7.6+ Enterprise...');

        if (!('serviceWorker' in navigator)) {
            const errorMsg = 'Service Worker API non supportata da questo browser environment.';
            this.#log('ERROR', 'Core', errorMsg);
            this.#emit('error', { type: 'SW_UNSUPPORTED', message: errorMsg });
            return null;
        }

        try {
            // 1. Inizializzazione della struttura di sicurezza IndexedDB Vault
            await this.ensureVaultReady();

            // 2. Registrazione e collegamento Service Worker
            this.#swRegistration = await navigator.serviceWorker.register(
                this.#config.swPath,
                { scope: this.#config.swScope }
            );
            this.#log('INFO', 'Core', `Service Worker registrato con successo. Scope: ${this.#swRegistration.scope}`);

            // 3. Configurazione bus di comunicazione IPC bidirezionale
            this.#initIPCListener();

            // 4. Configurazione monitoraggio ciclo di vita Service Worker
            this.#initLifecycleListeners();

            // 5. Avvio del timer automatico di flush della telemetria
            this.#startTelemetryTimer();

            this.#isInitialized = true;

            // Svuota i messaggi IPC accumulati in coda prima che il SW fosse pronto
            this.#flushMessageQueue();

            this.#emit('ready', {
                registration: this.#swRegistration,
                timestamp: Date.now(),
                status: this.getStatus()
            });

            return this.#swRegistration;

        } catch (err) {
            this.#log('ERROR', 'Core', 'Inizializzazione fallita.', { error: err.message, stack: err.stack });
            this.#emit('error', { type: 'INIT_FAILURE', cause: err });
            throw err;
        }
    }

    /**
     * 🔑 Assicura la presenza e l'integrità di IndexedDB "PWA_Vault" e relativi ObjectStore.
     * @returns {Promise<boolean>}
     */
    async ensureVaultReady() {
        return new Promise((resolve, reject) => {
            const request = indexedDB.open(this.#config.vaultDbName, 2);

            request.onupgradeneeded = (e) => {
                const db = e.target.result;
                if (!db.objectStoreNames.contains(this.#config.vaultStoreName)) {
                    db.createObjectStore(this.#config.vaultStoreName);
                    this.#log('INFO', 'Vault', `Created object store '${this.#config.vaultStoreName}'.`);
                }
                if (!db.objectStoreNames.contains(this.#config.cryptoSaltStoreName)) {
                    db.createObjectStore(this.#config.cryptoSaltStoreName);
                    this.#log('INFO', 'Vault', `Created object store '${this.#config.cryptoSaltStoreName}'.`);
                }
            };

            request.onsuccess = (e) => {
                const db = e.target.result;
                try {
                    const tx = db.transaction([this.#config.vaultStoreName], 'readonly');
                    const store = tx.objectStore(this.#config.vaultStoreName);
                    const getReq = store.get(this.#config.vaultKeyName);

                    getReq.onsuccess = () => {
                        db.close();
                        if (getReq.result) {
                            this.#log('INFO', 'Vault', 'Master Key identificata e verificata nel Vault.');
                        } else {
                            this.#log('INFO', 'Vault', 'Vault inizializzato. Generazione Master Key affidata al SW/Crypto Engine.');
                        }
                        resolve(true);
                    };

                    getReq.onerror = (err) => {
                        db.close();
                        this.#log('WARN', 'Vault', 'Errore durante l\'ispezione della Master Key.', err);
                        resolve(false);
                    };
                } catch (err) {
                    db.close();
                    reject(err);
                }
            };

            request.onerror = (err) => {
                this.#log('ERROR', 'Vault', 'Apertura IndexedDB Vault fallita.', err);
                reject(err);
            };
        });
    }

    /* ========================================================================= */
    /* 2. ADVANCED WEB CRYPTO ENGINE (AES-GCM, PBKDF2, HMAC-SHA256)              */
    /* ========================================================================= */

    /**
     * 🔑 Deriva una CryptoKey AES-GCM da una password/passphrase usando PBKDF2.
     * @param {string} passphrase - Passphrase dell'utente o master secret.
     * @param {Uint8Array} salt - Salt di cifratura di almeno 16 byte.
     * @returns {Promise<CryptoKey>}
     */
    async deriveKeyFromPassphrase(passphrase, salt) {
        const encoder = new TextEncoder();
        const passphraseBuffer = encoder.encode(passphrase);

        const baseKey = await crypto.subtle.importKey(
            "raw",
            passphraseBuffer,
            "PBKDF2",
            false,
            ["deriveKey"]
        );

        return await crypto.subtle.deriveKey(
            {
                name: "PBKDF2",
                salt: salt,
                iterations: this.#config.pbkdf2Iterations,
                hash: "SHA-256"
            },
            baseKey,
            { name: "AES-GCM", length: 256 },
            false,
            ["encrypt", "decrypt"]
        );
    }

    /**
     * 🔐 Cifra qualsiasi stringa, ArrayBuffer o Blob con AES-GCM 256-bit.
     * @param {string|ArrayBuffer|Blob} dataInput - Contenuto da cifrare.
     * @param {CryptoKey} [customKey=null] - Chiave opzionale (se omessa usa la Master Key del Vault).
     * @returns {Promise<{ciphertext: ArrayBuffer, iv: Uint8Array, tag: ArrayBuffer}>}
     */
    async encryptData(dataInput, customKey = null) {
        const key = customKey || await this.getVaultMasterKey();
        if (!key) {
            throw new Error("ENCRYPTION_FAILED: Nessuna chiave di cifratura valida disponibile.");
        }

        let buffer;
        if (typeof dataInput === 'string') {
            buffer = new TextEncoder().encode(dataInput).buffer;
        } else if (dataInput instanceof Blob) {
            buffer = await dataInput.arrayBuffer();
        } else {
            buffer = dataInput;
        }

        const iv = crypto.getRandomValues(new Uint8Array(12));
        const encryptedBuffer = await crypto.subtle.encrypt(
            { name: "AES-GCM", iv: iv },
            key,
            buffer
        );

        return {
            ciphertext: encryptedBuffer,
            iv: iv,
            timestamp: Date.now()
        };
    }

    /**
     * 🔓 Decifra un buffer AES-GCM 256-bit fornendo ciphertext e IV.
     * @param {ArrayBuffer} ciphertext - Buffer cifrato.
     * @param {Uint8Array} iv - Vettore di inizializzazione a 12 byte.
     * @param {CryptoKey} [customKey=null] - Chiave opzionale per decrittazione.
     * @returns {Promise<ArrayBuffer>} Plaintext decifrato.
     */
    async decryptData(ciphertext, iv, customKey = null) {
        const key = customKey || await this.getVaultMasterKey();
        if (!key) {
            throw new Error("DECRYPTION_FAILED: Chiave di decrittazione non trovata.");
        }

        return await crypto.subtle.decrypt(
            { name: "AES-GCM", iv: iv },
            key,
            ciphertext
        );
    }

    /**
     * 🔏 Genera una firma HMAC-SHA256 per garantire l'integrità dei messaggi/payload.
     * @param {string|ArrayBuffer} data - Dati da firmare.
     * @param {CryptoKey} hmacKey - Chiave HMAC generata/importata.
     * @returns {Promise<ArrayBuffer>} Firma digitale.
     */
    async generateHMAC(data, hmacKey) {
        const buffer = typeof data === 'string' ? new TextEncoder().encode(data) : data;
        return await crypto.subtle.sign("HMAC", hmacKey, buffer);
    }

    /**
     * 🔍 Verifica una firma HMAC-SHA256.
     * @param {string|ArrayBuffer} data - Dati originali.
     * @param {ArrayBuffer} signature - Firma da verificare.
     * @param {CryptoKey} hmacKey - Chiave HMAC.
     * @returns {Promise<boolean>}
     */
    async verifyHMAC(data, signature, hmacKey) {
        const buffer = typeof data === 'string' ? new TextEncoder().encode(data) : data;
        return await crypto.subtle.verify("HMAC", hmacKey, signature, buffer);
    }

    /**
     * 🔑 Estrae la Master Key dal Vault IndexedDB o dal campo protetto in memoria.
     * @returns {Promise<CryptoKey|null>}
     */
    async getVaultMasterKey() {
        if (this.#cryptoKeyCache.has('master_key')) {
            return this.#cryptoKeyCache.get('master_key');
        }

        return new Promise((resolve) => {
            const request = indexedDB.open(this.#config.vaultDbName, 2);
            request.onsuccess = (e) => {
                const db = e.target.result;
                try {
                    const tx = db.transaction([this.#config.vaultStoreName], 'readonly');
                    const store = tx.objectStore(this.#config.vaultStoreName);
                    const getReq = store.get(this.#config.vaultKeyName);

                    getReq.onsuccess = () => {
                        db.close();
                        const key = getReq.result || null;
                        if (key) {
                            this.#cryptoKeyCache.set('master_key', key);
                        }
                        resolve(key);
                    };
                    getReq.onerror = () => {
                        db.close();
                        resolve(null);
                    };
                } catch (err) {
                    db.close();
                    resolve(null);
                }
            };
            request.onerror = () => resolve(null);
        });
    }

    /**
     * 🧹 Purga le chiavi crittografiche memorizzate in RAM per mitigare attacchi di ispezione memoria.
     */
    sanitizeCryptoMemory() {
        this.#cryptoKeyCache.clear();
        this.#log('INFO', 'Crypto', 'Cache chiavi in memoria RAM bonificata con successo.');
    }

    /* ========================================================================= */
    /* 3. LOCAL INDEXEDDB ORM & STORAGE ENGINE                                  */
    /* ========================================================================= */

    #dbPool = new Map();
    #memoryFallbackStore = new Map();

    /**
     * 🗄️ Apre o recupera una connessione gestita verso un database IndexedDB.
     * @param {string} dbName - Nome del database target.
     * @param {number} version - Versione dello schema.
     * @param {Function} [upgradeFn=null] - Callback di migrazione dello schema.
     * @returns {Promise<IDBDatabase>}
     */
    async openDatabase(dbName, version = 1, upgradeFn = null) {
        if (this.#dbPool.has(dbName)) {
            const cachedDb = this.#dbPool.get(dbName);
            if (cachedDb.objectStoreNames) return cachedDb;
        }

        return new Promise((resolve, reject) => {
            const request = indexedDB.open(dbName, version);

            request.onupgradeneeded = (event) => {
                const db = event.target.result;
                const transaction = event.target.transaction;
                this.#log('INFO', 'ORM', `Esecuzione upgrade schema DB '${dbName}' v${version}...`);
                if (typeof upgradeFn === 'function') {
                    upgradeFn(db, transaction, event.oldVersion, event.newVersion);
                }
            };

            request.onsuccess = (event) => {
                const db = event.target.result;
                db.onversionchange = () => {
                    db.close();
                    this.#dbPool.delete(dbName);
                    this.#log('WARN', 'ORM', `Connessione DB '${dbName}' chiusa per cambio versione imminente.`);
                };
                this.#dbPool.set(dbName, db);
                resolve(db);
            };

            request.onerror = (event) => {
                this.#log('ERROR', 'ORM', `Fallimento apertura DB '${dbName}'. Attivazione Fallback Adapter.`, event.target.error);
                reject(event.target.error);
            };
        });
    }

    /**
     * ⚡ Esegue una transazione generica atomica con supporto a rollback automatico.
     * @param {string} dbName - Database di destinazione.
     * @param {string|string[]} storeNames - Nomi degli store coinvolti.
     * @param {IDBTransactionMode} mode - 'readonly' | 'readwrite'
     * @param {Function} callback - Async callback con argomenti (stores, transaction).
     * @returns {Promise<any>}
     */
    async executeTransaction(dbName, storeNames, mode, callback) {
        try {
            const db = await this.openDatabase(dbName);
            const storesArray = Array.isArray(storeNames) ? storeNames : [storeNames];
            
            return new Promise((resolve, reject) => {
                const tx = db.transaction(storesArray, mode);
                const storeMap = {};
                storesArray.forEach(name => {
                    storeMap[name] = tx.objectStore(name);
                });

                let result;
                tx.oncomplete = () => resolve(result);
                tx.onerror = (e) => reject(e.target.error);
                tx.onabort = (e) => reject(new Error(`TRANSACTION_ABORTED: ${e.target.error}`));

                Promise.resolve(callback(storeMap, tx))
                    .then(res => { result = res; })
                    .catch(err => {
                        tx.abort();
                        reject(err);
                    });
            });
        } catch (err) {
            this.#log('WARN', 'ORM', `Transazione fallita su IndexedDB. Reindirizzamento a Fallback Store.`, err);
            return this.#executeFallbackTransaction(storeNames, mode, callback);
        }
    }

    /**
     * 📝 Inserisce o aggiorna un record singolo (PUT) in un ObjectStore.
     * @param {string} dbName - Nome DB
     * @param {string} storeName - Store target
     * @param {Object} value - Documento da salvare
     * @param {IDBValidKey} [key=null] - Chiave univoca (se lo store non usa autoIncrement)
     * @returns {Promise<IDBValidKey>}
     */
    async dbPut(dbName, storeName, value, key = null) {
        return this.executeTransaction(dbName, storeName, 'readwrite', (stores) => {
            return new Promise((resolve, reject) => {
                const req = key ? stores[storeName].put(value, key) : stores[storeName].put(value);
                req.onsuccess = () => resolve(req.result);
                req.onerror = () => reject(req.error);
            });
        });
    }

    /**
     * 📖 Recupera un record tramite chiave primaria.
     * @param {string} dbName - Nome DB
     * @param {string} storeName - Store target
     * @param {IDBValidKey} key - Chiave univoca
     * @returns {Promise<any>}
     */
    async dbGet(dbName, storeName, key) {
        return this.executeTransaction(dbName, storeName, 'readonly', (stores) => {
            return new Promise((resolve, reject) => {
                const req = stores[storeName].get(key);
                req.onsuccess = () => resolve(req.result || null);
                req.onerror = () => reject(req.error);
            });
        });
    }

    /**
     * 🔍 Elimina un record specifico tramite la sua chiave primaria.
     * @param {string} dbName - Nome DB
     * @param {string} storeName - Store target
     * @param {IDBValidKey} key - Chiave univoca da rimuovere
     * @returns {Promise<boolean>}
     */
    async dbDelete(dbName, storeName, key) {
        return this.executeTransaction(dbName, storeName, 'readwrite', (stores) => {
            return new Promise((resolve, reject) => {
                const req = stores[storeName].delete(key);
                req.onsuccess = () => resolve(true);
                req.onerror = () => reject(req.error);
            });
        });
    }

    /**
     * 🚀 Inserimento/Aggiornamento massivo (Bulk Put) ad elevate prestazioni.
     * @param {string} dbName - Nome DB
     * @param {string} storeName - Store target
     * @param {Array<Object>} items - Lista di oggetti da inserire
     * @returns {Promise<number>} Conteggio elementi scritti con successo
     */
    async dbBulkPut(dbName, storeName, items) {
        if (!Array.isArray(items) || items.length === 0) return 0;

        return this.executeTransaction(dbName, storeName, 'readwrite', (stores) => {
            return new Promise((resolve, reject) => {
                const store = stores[storeName];
                let count = 0;
                let hasError = false;

                items.forEach(item => {
                    if (hasError) return;
                    const req = store.put(item);
                    req.onsuccess = () => {
                        count++;
                        if (count === items.length) resolve(count);
                    };
                    req.onerror = (err) => {
                        hasError = true;
                        reject(err.target.error);
                    };
                });
            });
        });
    }

    /**
     * 🔍 Query su Indici secondari con supporto a KeyRange.
     * @param {string} dbName - Nome DB
     * @param {string} storeName - Store target
     * @param {string} indexName - Nome dell'indice
     * @param {IDBKeyRange|IDBValidKey} range - Intervallo o valore cercato
     * @param {number} [limit=100] - Limite massimo di record restituiti
     * @returns {Promise<Array<any>>}
     */
    async dbQueryByIndex(dbName, storeName, indexName, range, limit = 100) {
        return this.executeTransaction(dbName, storeName, 'readonly', (stores) => {
            return new Promise((resolve, reject) => {
                const store = stores[storeName];
                const index = store.index(indexName);
                const results = [];
                const req = index.openCursor(range);

                req.onsuccess = (e) => {
                    const cursor = e.target.result;
                    if (cursor && results.length < limit) {
                        results.push(cursor.value);
                        cursor.continue();
                    } else {
                        resolve(results);
                    }
                };
                req.onerror = () => reject(req.error);
            });
        });
    }

    /**
     * 🌊 Cursor Stream in batch per elaborare moli ingenti di dati senza saturare la RAM.
     * @param {string} dbName - Nome DB
     * @param {string} storeName - Store target
     * @param {number} batchSize - Dimensione di ciascun blocco
     * @param {Function} onBatchCallback - Async callback eseguito ad ogni batch elaborato
     * @returns {Promise<number>} Conteggio totale elementi processati
     */
    async dbStreamCursor(dbName, storeName, batchSize = 50, onBatchCallback) {
        let totalProcessed = 0;
        let batch = [];

        await this.executeTransaction(dbName, storeName, 'readonly', (stores) => {
            return new Promise((resolve, reject) => {
                const store = stores[storeName];
                const req = store.openCursor();

                req.onsuccess = async (e) => {
                    const cursor = e.target.result;
                    if (cursor) {
                        batch.push(cursor.value);
                        totalProcessed++;

                        if (batch.length >= batchSize) {
                            const currentBatch = [...batch];
                            batch = [];
                            try {
                                await onBatchCallback(currentBatch);
                            } catch (err) {
                                return reject(err);
                            }
                        }
                        cursor.continue();
                    } else {
                        if (batch.length > 0) {
                            try {
                                await onBatchCallback(batch);
                            } catch (err) {
                                return reject(err);
                            }
                        }
                        resolve(totalProcessed);
                    }
                };
                req.onerror = () => reject(req.error);
            });
        });

        return totalProcessed;
    }

    /**
     * 🛡️ FALLBACK ADAPTER: Gestione memoria RAM in caso di blocchi/restrizioni su IndexedDB (Private Browsing / Quota Errors).
     */
    #executeFallbackTransaction(storeNames, mode, callback) {
        this.#log('WARN', 'FallbackStore', 'Esecuzione operazione in-memory fallback.');
        const storeMap = {};
        const storesArray = Array.isArray(storeNames) ? storeNames : [storeNames];

        storesArray.forEach(name => {
            if (!this.#memoryFallbackStore.has(name)) {
                this.#memoryFallbackStore.set(name, new Map());
            }
            const memMap = this.#memoryFallbackStore.get(name);

            storeMap[name] = {
                put: (val, key) => {
                    const k = key || val.id || Date.now() + Math.random();
                    memMap.set(k, val);
                    return { onsuccess: null, result: k };
                },
                get: (key) => {
                    const res = memMap.get(key);
                    return { onsuccess: null, result: res };
                },
                delete: (key) => {
                    memMap.delete(key);
                    return { onsuccess: null, result: true };
                }
            };
        });

        return Promise.resolve(callback(storeMap, null));
    }

    /* ========================================================================= */
    /* 4. DELTA SYNC ENGINE & OFFLINE MUTATION QUEUE                            */
    /* ========================================================================= */

    #mutationQueue = [];
    #isSyncing = false;
    #vectorClock = new Map(); // Store ID -> Logical Timestamp

    /**
     * 📥 Registra una mutazione locale da sincronizzare con il backend quando la rete è attiva.
     * @param {string} storeName - Tabella/Store oggetto della modifica
     * @param {'CREATE'|'UPDATE'|'DELETE'} operation - Tipo di operazione CRUD
     * @param {Object} payload - Dati da sincronizzare
     * @param {string} recordId - Identificativo univoco del record
     * @returns {Promise<string>} Mutation UUID
     */
    async enqueueMutation(storeName, operation, payload, recordId) {
        const mutationId = `mut_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        
        // Incrementa il Vector Clock locale per questo store
        const currentClock = (this.#vectorClock.get(storeName) || 0) + 1;
        this.#vectorClock.set(storeName, currentClock);

        const mutation = {
            id: mutationId,
            storeName: storeName,
            operation: operation,
            recordId: recordId,
            payload: payload,
            timestamp: Date.now(),
            vectorClock: currentClock,
            retryCount: 0,
            status: 'PENDING' // 'PENDING' | 'PROCESSING' | 'FAILED'
        };

        this.#mutationQueue.push(mutation);
        
        // Salva la mutazione nel DB Vault per sopravvivere ai riavvii della pagina
        await this.dbPut(this.#config.vaultDbName, 'keys', mutation, `mutation_${mutationId}`);
        
        this.#log('INFO', 'Sync', `Mutazione '${operation}' accodata per record ${recordId}. Coda attuale: ${this.#mutationQueue.length}`);
        this.#emit('sync:mutation_queued', mutation);

        // Tenta il flush immediato se siamo online
        if (navigator.onLine && !this.#isSyncing) {
            this.processMutationQueue();
        }

        return mutationId;
    }

    /**
     * 🔄 Elabora la coda delle mutazioni offline inviandole al server o al Service Worker.
     */
    async processMutationQueue() {
        if (this.#isSyncing || this.#mutationQueue.length === 0) return;
        if (!navigator.onLine) {
            this.#log('WARN', 'Sync', 'Elaborazione coda sospesa: Dispositivo offline.');
            return;
        }

        this.#isSyncing = true;
        this.#emit('sync:start', { queueLength: this.#mutationQueue.length });
        this.#log('INFO', 'Sync', `Avvio sincronizzazione delta per ${this.#mutationQueue.length} mutazioni...`);

        const pendingMutations = [...this.#mutationQueue];

        for (const mutation of pendingMutations) {
            try {
                mutation.status = 'PROCESSING';
                
                // Invio al Service Worker o esecuzione diretta tramite Circuit Breaker
                const success = await this.executeWithCircuitBreaker(async () => {
                    return await this.#sendMutationToServer(mutation);
                });

                if (success) {
                    // Rimuovi dalla coda e dallo storage locale del Vault
                    this.#mutationQueue = this.#mutationQueue.filter(m => m.id !== mutation.id);
                    await this.dbDelete(this.#config.vaultDbName, 'keys', `mutation_${mutation.id}`);
                    this.#emit('sync:mutation_success', { id: mutation.id, recordId: mutation.recordId });
                } else {
                    throw new Error("SERVER_REJECTED_MUTATION");
                }
            } catch (err) {
                mutation.retryCount++;
                mutation.status = 'FAILED';
                this.#log('WARN', 'Sync', `Mutazione ${mutation.id} fallita (tentativo ${mutation.retryCount}).`, err);

                if (mutation.retryCount >= 5) {
                    this.#log('ERROR', 'Sync', `Mutazione ${mutation.id} scartata dopo max tentativi. Spostamento in Dead Letter Queue.`);
                    this.#mutationQueue = this.#mutationQueue.filter(m => m.id !== mutation.id);
                    await this.dbDelete(this.#config.vaultDbName, 'keys', `mutation_${mutation.id}`);
                    this.#emit('sync:mutation_dead_letter', mutation);
                } else {
                    // Exponential Backoff: attesa crescente prima di riprovare
                    const backoffMs = Math.pow(2, mutation.retryCount) * 1000;
                    await new Promise(res => setTimeout(res, backoffMs));
                    break; // Interrompe il ciclo per non bloccare le successive mutazioni
                }
            }
        }

        this.#isSyncing = false;
        this.#emit('sync:end', { remainingInQueue: this.#mutationQueue.length });
    }

    /**
     * 🔀 Risoluzione automatica dei conflitti basata su Vector Clock & Last-Write-Wins (LWW).
     * @param {Object} localRecord - Record salvato in IndexedDB locale
     * @param {Object} remoteRecord - Record ricevuto dal server remoto
     * @returns {Object} Record risolto vincente
     */
    resolveConflict(localRecord, remoteRecord) {
        if (!localRecord) return remoteRecord;
        if (!remoteRecord) return localRecord;

        const localClock = localRecord._vectorClock || 0;
        const remoteClock = remoteRecord._vectorClock || 0;

        if (remoteClock > localClock) {
            this.#log('INFO', 'SyncConflict', `Vince il record Remoto (VectorClock Remoto ${remoteClock} > Locale ${localClock}).`);
            return remoteRecord;
        } else if (localClock > remoteClock) {
            this.#log('INFO', 'SyncConflict', `Vince il record Locale (VectorClock Locale ${localClock} > Remoto ${remoteClock}).`);
            return localRecord;
        }

        // Se i Vector Clock equivalgono, applica strategia Last-Write-Wins basata su timestamp
        const localTs = localRecord._updatedAt || 0;
        const remoteTs = remoteRecord._updatedAt || 0;

        if (remoteTs >= localTs) {
            this.#log('INFO', 'SyncConflict', 'Pareggio Vector Clock: Vince Remoto per strategia LWW.');
            return remoteRecord;
        } else {
            this.#log('INFO', 'SyncConflict', 'Pareggio Vector Clock: Vince Locale per strategia LWW.');
            return localRecord;
        }
    }

    /**
     * 📤 Invia una singola mutazione verso il canale IPC del SW o endpoint di backend.
     */
    async #sendMutationToServer(mutation) {
        return new Promise((resolve) => {
            const sent = this.postMessageToSW({
                type: 'EXECUTE_MUTATION',
                mutation: mutation,
                timestamp: Date.now()
            });

            if (!sent) {
                return resolve(false);
            }

            // Attende la conferma di avvenuta sincronizzazione dal SW tramite event listener temporaneo
            const handler = (data) => {
                if (data.mutationId === mutation.id) {
                    this.off('sw:mutation_ack', handler);
                    resolve(data.success === true);
                }
            };

            this.on('sw:mutation_ack', handler);

            // Timeout di sicurezza se il SW non risponde entro 10 secondi
            setTimeout(() => {
                this.off('sw:mutation_ack', handler);
                resolve(false);
            }, 10000);
        });
    }


    /* ========================================================================= */
    /* 5. NETWORK, CIRCUIT BREAKER & HEARTBEAT MANAGER                           */
    /* ========================================================================= */

    #circuitState = 'CLOSED'; // 'CLOSED' (Normale) | 'OPEN' (Bloccato) | 'HALF_OPEN' (Test)
    #failureCount = 0;
    #lastStateChange = Date.now();
    #rttHistory = [];

    /**
     * 🛡️ Esegue un'operazione asincrona protetta da un modello Circuit Breaker.
     * @param {Function} asyncFn - Operazione di rete o I/O da eseguire
     * @param {Function} [fallbackFn=null] - Azione di riserva se il circuito è aperto
     * @returns {Promise<any>}
     */
    async executeWithCircuitBreaker(asyncFn, fallbackFn = null) {
        if (this.#circuitState === 'OPEN') {
            if (Date.now() - this.#lastStateChange > this.#config.circuitBreakerTimeout) {
                this.#circuitState = 'HALF_OPEN';
                this.#log('WARN', 'CircuitBreaker', 'Circuito passato in stato HALF_OPEN. Esecuzione test...');
            } else {
                this.#log('WARN', 'CircuitBreaker', 'Circuito APERTO: Chiamata bloccata preventivamente.');
                if (typeof fallbackFn === 'function') return fallbackFn();
                throw new Error("CIRCUIT_BREAKER_OPEN");
            }
        }

        try {
            const result = await asyncFn();
            
            if (this.#circuitState === 'HALF_OPEN') {
                this.#circuitState = 'CLOSED';
                this.#failureCount = 0;
                this.#lastStateChange = Date.now();
                this.#log('INFO', 'CircuitBreaker', 'Circuito RIPRISTINATO (CLOSED).');
            }
            return result;
        } catch (err) {
            this.#failureCount++;
            this.#log('WARN', 'CircuitBreaker', `Fallimento registrato (${this.#failureCount}/${this.#config.circuitBreakerThreshold}).`, err);

            if (this.#failureCount >= this.#config.circuitBreakerThreshold) {
                this.#circuitState = 'OPEN';
                this.#lastStateChange = Date.now();
                this.#log('ERROR', 'CircuitBreaker', 'Soglia fallimenti superata! Circuito commutato in APERTO (OPEN).');
                this.#emit('circuit:opened', { timeout: this.#config.circuitBreakerTimeout });
            }

            if (typeof fallbackFn === 'function') return fallbackFn();
            throw err;
        }
    }

    /**
     * 🏓 Rileva la latenza di rete effettiva (RTT - Round Trip Time) misurando un ping.
     * @param {string} pingUrl - URL dell'endpoint di heartbeat
     * @returns {Promise<number>} Latenza espressa in millisecondi
     */
    async measureRTT(pingUrl = '/ping') {
        const start = performance.now();
        try {
            const response = await fetch(pingUrl, { method: 'HEAD', cache: 'no-store' });
            if (response.ok) {
                const duration = Math.round(performance.now() - start);
                this.#rttHistory.push(duration);
                if (this.#rttHistory.length > 10) this.#rttHistory.shift();
                
                this.#log('INFO', 'Network', `Ping RTT: ${duration}ms`);
                return duration;
            }
            return -1;
        } catch (err) {
            this.#log('WARN', 'Network', 'Ping RTT fallito.', err);
            return -1;
        }
    }

    /**
     * 📊 Calcola la media mobile della latenza di rete (RTT) aggiornata.
     * @returns {number} Latenza media in ms
     */
    getAverageRTT() {
        if (this.#rttHistory.length === 0) return 0;
        const sum = this.#rttHistory.reduce((acc, val) => acc + val, 0);
        return Math.round(sum / this.#rttHistory.length);
    }

    /* ========================================================================= */
    /* 6. CACHE STRATEGY & STORAGE QUOTA MANAGER                                */
    /* ========================================================================= */

    /**
     * 📊 Calcola l'occupazione della memoria di archiviazione locale (Storage Estimate API).
     * @returns {Promise<{usage: number, quota: number, percentUsed: number, usageInMB: string, quotaInMB: string}>}
     */
    async getStorageQuotaInfo() {
        if (navigator.storage && navigator.storage.estimate) {
            try {
                const estimate = await navigator.storage.estimate();
                const usage = estimate.usage || 0;
                const quota = estimate.quota || 1;
                const percentUsed = parseFloat(((usage / quota) * 100).toFixed(2));

                return {
                    usage: usage,
                    quota: quota,
                    percentUsed: percentUsed,
                    usageInMB: (usage / (1024 * 1024)).toFixed(2),
                    quotaInMB: (quota / (1024 * 1024)).toFixed(2)
                };
            } catch (err) {
                this.#log('WARN', 'StorageQuota', 'Errore durante la lettura delle quote di storage.', err);
            }
        }
        return { usage: 0, quota: 0, percentUsed: 0, usageInMB: '0', quotaInMB: '0' };
    }

    /**
     * 🧹 Invalida e rimuove voci di cache obsolete da CacheStorage in base al nome o alla vetustà.
     * @param {number} maxAgeMs - Età massima consentita in millisecondi per gli elementi memorizzati
     * @returns {Promise<number>} Numero di entry di cache eliminate
     */
    async cleanExpiredCaches(maxAgeMs = 86400000 * 7) { // Default: 7 giorni
        if (!('caches' in window)) return 0;

        let purgedCount = 0;
        const cacheNames = await caches.keys();
        const now = Date.now();

        for (const cacheName of cacheNames) {
            const cache = await caches.open(cacheName);
            const requests = await cache.keys();

            for (const request of requests) {
                const response = await cache.match(request);
                if (response) {
                    const dateHeader = response.headers.get('date');
                    if (dateHeader) {
                        const fetchedTime = new Date(dateHeader).getTime();
                        if (now - fetchedTime > maxAgeMs) {
                            await cache.delete(request);
                            purgedCount++;
                        }
                    }
                }
            }
        }

        this.#log('INFO', 'CacheManager', `Epurazione completata: ${purgedCount} elementi scaduti rimossi.`);
        return purgedCount;
    }

    /**
     * 📥 Pre-carica ed archivia manualmente una risorsa nell'API CacheStorage del browser.
     * @param {string} cacheName - Nome della cache target
     * @param {string|Request} url - Risorsa/URL da recuperare e memorizzare
     * @returns {Promise<boolean>}
     */
    async cacheResource(cacheName, url) {
        if (!('caches' in window)) return false;
        try {
            const cache = await caches.open(cacheName);
            await cache.add(url);
            this.#log('INFO', 'CacheManager', `Risorsa '${url}' aggiunta manualmente alla cache '${cacheName}'.`);
            return true;
        } catch (err) {
            this.#log('ERROR', 'CacheManager', `Impossibile archiviare la risorsa '${url}'.`, err);
            return false;
        }
    }

    /**
     * 💣 Svuota radicalmente tutte le istanze CacheStorage registrate nel dominio.
     * @returns {Promise<boolean>}
     */
    async purgeAllCaches() {
        if (!('caches' in window)) return false;
        const keys = await caches.keys();
        await Promise.all(keys.map(key => caches.delete(key)));
        this.#log('WARN', 'CacheManager', 'Tutte le Cache Storage del dominio sono state completamente eliminate.');
        return true;
    }


    /* ========================================================================= */
    /* 7. TELEMETRY, PERFORMANCE PROFILER & CRASH ANALYTICS                      */
    /* ========================================================================= */

    /**
     * 📊 Registra una metrica di performance personalizzata per profilazione UX.
     * @param {string} metricName - Nome della metrica (es: 'db_query_time', 'render_delay')
     * @param {number} durationMs - Durata espressa in millisecondi
     * @param {Object} [meta={}] - Dati e tag di contesto opzionali
     */
    logPerformanceMetric(metricName, durationMs, meta = {}) {
        const payload = {
            metric: metricName,
            durationMs: Math.round(durationMs),
            timestamp: Date.now(),
            meta: meta
        };

        this.logTelemetry('INFO', 'PerformanceProfiler', `Metrica [${metricName}]: ${durationMs}ms`, payload);
    }

    /**
     * ⏱️ Estrae le metriche di caricamento pagina e risorse tramite Navigation Timing API v2.
     * @returns {Object} Report sintetico dei tempi di boot
     */
    captureNavigationTiming() {
        if (!window.performance || !window.performance.getEntriesByType) return null;

        const navEntries = performance.getEntriesByType('navigation');
        if (navEntries.length === 0) return null;

        const nav = navEntries[0];
        const report = {
            dnsLookup: Math.round(nav.domainLookupEnd - nav.domainLookupStart),
            tcpConnection: Math.round(nav.connectEnd - nav.connectStart),
            tlsHandshake: nav.secureConnectionStart ? Math.round(nav.connectEnd - nav.secureConnectionStart) : 0,
            timeToFirstByte: Math.round(nav.responseStart - nav.requestStart),
            domInteractive: Math.round(nav.domInteractive),
            domContentLoaded: Math.round(nav.domContentLoadedEventEnd - nav.startTime),
            pageLoadComplete: Math.round(nav.loadEventEnd - nav.startTime)
        };

        this.#log('INFO', 'Profiler', 'Analisi Navigation Timing acquisita.', report);
        return report;
    }

    /**
     * 📝 Inserisce un evento di telemetria o errore nella coda locale.
     * @param {'INFO'|'WARN'|'ERROR'} level - Livello di severità
     * @param {string} tag - Modulo o ambito sorgente
     * @param {string} message - Dettaglio dell'evento
     * @param {Object} [details={}] - Payload di contesto opzionale
     */
    logTelemetry(level, tag, message, details = {}) {
        const entry = {
            id: `log_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
            timestamp: Date.now(),
            level: level.toUpperCase(),
            tag: tag,
            message: message,
            details: details,
            userAgent: navigator.userAgent
        };

        this.#telemetryQueue.push(entry);

        if (this.#config.enableDebugLogs) {
            const style = level === 'ERROR' ? 'color: red; font-weight: bold;' : (level === 'WARN' ? 'color: orange;' : 'color: #00bcd4;');
            console.log(`%c[PanzerSDK ${level}][${tag}] ${message}`, style, details);
        }

        if (this.#telemetryQueue.length >= this.#config.maxTelemetryBatch) {
            this.flushTelemetry();
        }
    }

    /**
     * 📤 Trasmette la coda dei log e della telemetria accumulata verso il Service Worker o backend.
     */
    flushTelemetry() {
        if (this.#telemetryQueue.length === 0) return;

        const batch = [...this.#telemetryQueue];
        this.#telemetryQueue = [];

        this.postMessageToSW({
            type: 'TELEMETRY_BATCH',
            logs: batch,
            timestamp: Date.now()
        });

        this.#log('INFO', 'Telemetry', `Flush di ${batch.length} record di telemetria inviato al Service Worker.`);
    }

    /**
     * ⏱️ Avvia il timer di flush periodico per i dati diagnostici accumulati.
     */
    #startTelemetryTimer() {
        setInterval(() => {
            this.flushTelemetry();
        }, this.#config.telemetryFlushInterval);
    }

    /**
     * 💥 Configura intercettori globali per catturare eccezioni non gestite e rejection di Promise.
     */
    #initUnhandledErrorInterceptors() {
        window.addEventListener('error', (event) => {
            this.logTelemetry('ERROR', 'UnhandledException', event.message, {
                filename: event.filename,
                lineno: event.lineno,
                colno: event.colno,
                errorStack: event.error ? event.error.stack : null
            });
        });

        window.addEventListener('unhandledrejection', (event) => {
            this.logTelemetry('ERROR', 'UnhandledRejection', 'Promise non gestita rifiutata.', {
                reason: event.reason instanceof Error ? event.reason.message : event.reason,
                stack: event.reason instanceof Error ? event.reason.stack : null
            });
        });
    }

    /**
     * 📝 Helper privato interno di registrazione log.
     */
    #log(level, tag, message, details = {}) {
        this.logTelemetry(level, tag, message, details);
    }

    /* ========================================================================= */
    /* 8. WEB PUSH NOTIFICATIONS & BACKGROUND FETCH/SYNC                         */
    /* ========================================================================= */

    /**
     * 🔔 Richiede i permessi per le Notifiche Push nel browser.
     * @returns {Promise<NotificationPermission>}
     */
    async requestNotificationPermission() {
        if (!('Notification' in window)) {
            this.#log('WARN', 'Push', 'Le notifiche desktop non sono supportate da questo browser.');
            return 'denied';
        }

        const permission = await Notification.requestPermission();
        this.#log('INFO', 'Push', `Stato permesso notifiche: ${permission}`);
        this.#emit('push:permission', { permission });
        return permission;
    }

    /**
     * 📲 Registra una sottoscrizione Push tramite VAPID Key.
     * @param {string} vapidPublicKey - Chiave pubblica VAPID in formato URL-safe Base64
     * @returns {Promise<PushSubscription|null>}
     */
    async subscribePush(vapidPublicKey) {
        if (!this.#swRegistration) {
            this.#log('ERROR', 'Push', 'Impossibile sottoscrivere Push: Service Worker non inizializzato.');
            return null;
        }

        try {
            const existingSub = await this.#swRegistration.pushManager.getSubscription();
            if (existingSub) {
                this.#log('INFO', 'Push', 'Sottoscrizione Push esistente recuperata con successo.');
                return existingSub;
            }

            const convertedKey = this.#urlBase64ToUint8Array(vapidPublicKey);
            const newSub = await this.#swRegistration.pushManager.subscribe({
                userVisibleOnly: true,
                applicationServerKey: convertedKey
            });

            this.#log('INFO', 'Push', 'Nuova sottoscrizione Push creata con successo.');
            this.#emit('push:subscribed', newSub);
            return newSub;

        } catch (err) {
            this.#log('ERROR', 'Push', 'Errore durante la sottoscrizione ai servizi Push.', err);
            return null;
        }
    }

    /**
     * 🔄 Registra un task di Background Sync guidato dal Service Worker.
     * @param {string} syncTag - Identificativo del job di sincronizzazione
     * @returns {Promise<boolean>}
     */
    async registerBackgroundSync(syncTag) {
        if (!this.#swRegistration || !('sync' in this.#swRegistration)) {
            this.#log('WARN', 'Sync', 'Background Sync API non supportata dal browser.');
            return false;
        }

        try {
            await this.#swRegistration.sync.register(syncTag);
            this.#log('INFO', 'Sync', `Background Sync registrato per il tag '${syncTag}'.`);
            return true;
        } catch (err) {
            this.#log('ERROR', 'Sync', `Registrazione Background Sync fallita per '${syncTag}'.`, err);
            return false;
        }
    }

    /**
     * 📥 Registra un download massivo in Background Fetch.
     * @param {string} id - ID del task
     * @param {string|string[]} requests - URL o risorse da scaricare
     * @param {Object} [options={}] - Titolo e icone per la notifica di avanzamento
     * @returns {Promise<BackgroundFetchRegistration|null>}
     */
    async registerBackgroundFetch(id, requests, options = {}) {
        if (!this.#swRegistration || !('backgroundFetch' in this.#swRegistration)) {
            this.#log('WARN', 'BgFetch', 'Background Fetch API non supportata.');
            return null;
        }

        try {
            const reqArray = Array.isArray(requests) ? requests : [requests];
            const bgFetch = await this.#swRegistration.backgroundFetch.fetch(id, reqArray, options);
            this.#log('INFO', 'BgFetch', `Background Fetch '${id}' avviato.`);
            return bgFetch;
        } catch (err) {
            this.#log('ERROR', 'BgFetch', `Errore durante l'avvio del Background Fetch '${id}'.`, err);
            return null;
        }
    }

    /**
     * 🛠️ Convertitore Helper da Base64 URL-safe a Uint8Array per chiavi VAPID.
     */
    #urlBase64ToUint8Array(base64String) {
        const padding = '='.repeat((4 - base64String.length % 4) % 4);
        const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
        const rawData = window.atob(base64);
        const outputArray = new Uint8Array(rawData.length);
        for (let i = 0; i < rawData.length; ++i) {
            outputArray[i] = rawData.charCodeAt(i);
        }
        return outputArray;
    }


    /* ========================================================================= */
    /* 9. REACTIVE STATE STORE                                                  */
    /* ========================================================================= */

    #state = {};
    #stateSubscribers = new Set();

    /**
     * 🧠 Aggiorna lo stato reattivo dell'SDK notificando tutti i sottoscrittori.
     * @param {Object} partialState - Oggetto contenente le proprietà da aggiornare
     */
    setState(partialState) {
        this.#state = { ...this.#state, ...partialState };
        this.#log('INFO', 'StateStore', 'Stato reattivo aggiornato.', this.#state);

        this.#stateSubscribers.forEach(callback => {
            try {
                callback(this.#state);
            } catch (err) {
                this.#log('ERROR', 'StateStore', 'Errore durante l\'esecuzione di uno subscriber dello stato.', err);
            }
        });
    }

    /**
     * 📖 Legge lo stato reattivo corrente o una sua singola proprietà.
     * @param {string} [key=null] - Proprietà opzionale da estrarre
     * @returns {any}
     */
    getState(key = null) {
        if (key) return this.#state[key];
        return { ...this.#state };
    }

    /**
     * 🎧 Registra una callback di ascolto per i cambiamenti dello stato reattivo.
     * @param {Function} callback - Riceve lo stato aggiornato
     * @returns {Function} Funzione di un-subscribe
     */
    subscribeState(callback) {
        if (typeof callback === 'function') {
            this.#stateSubscribers.add(callback);
            callback(this.#state); // Notifica iniziale immediata
        }
        return () => this.#stateSubscribers.delete(callback);
    }


    /* ========================================================================= */
    /* 10. PWA UI HELPERS & HARDWARE / THERMAL SHIELD                           */
    /* ========================================================================= */

    #deferredInstallPrompt = null;

    /**
     * 📱 Inizializza l'intercettore per il banner d'installazione PWA.
     */
    setupInstallPrompt() {
        window.addEventListener('beforeinstallprompt', (e) => {
            e.preventDefault();
            this.#deferredInstallPrompt = e;
            this.#log('INFO', 'PWAUI', 'Evento beforeinstallprompt catturato e memorizzato.');
            this.#emit('pwa:installable', { ready: true });
        });

        window.addEventListener('appinstalled', () => {
            this.#deferredInstallPrompt = null;
            this.#log('INFO', 'PWAUI', 'Applicazione PWA installata con successo.');
            this.#emit('pwa:installed', { timestamp: Date.now() });
        });
    }

    /**
     * 🚀 Mostra il prompt nativo di installazione PWA all'utente.
     * @returns {Promise<boolean>} 'true' se l'utente ha accettato l'installazione
     */
    async promptInstall() {
        if (!this.#deferredInstallPrompt) {
            this.#log('WARN', 'PWAUI', 'Nessun prompt d\'installazione disponibile o PWA già installata.');
            return false;
        }

        this.#deferredInstallPrompt.prompt();
        const { outcome } = await this.#deferredInstallPrompt.userChoice;
        this.#log('INFO', 'PWAUI', `Esito installazione utente: ${outcome}`);
        this.#deferredInstallPrompt = null;
        return outcome === 'accepted';
    }

    /**
     * 🔋 Monitora la batteria del dispositivo per prevenire il surriscaldamento o ridurre il throttling di calcolo.
     */
    async monitorBatteryThermal() {
        if (!('getBattery' in navigator)) return null;

        try {
            const battery = await navigator.getBattery();
            const updateBatteryStatus = () => {
                const info = {
                    level: Math.round(battery.level * 100),
                    charging: battery.charging,
                    chargingTime: battery.chargingTime,
                    dischargingTime: battery.dischargingTime
                };

                this.setState({ batteryInfo: info });
                this.#emit('hardware:battery', info);

                // Shield termico: se la batteria è sotto il 15% e non in carica, riduce la telemetria
                if (info.level <= 15 && !info.charging) {
                    this.#config.telemetryFlushInterval = 60000;
                    this.#log('WARN', 'ThermalShield', 'Modalità risparmio energetico attivata.');
                }
            };

            battery.addEventListener('levelchange', updateBatteryStatus);
            battery.addEventListener('chargingchange', updateBatteryStatus);
            updateBatteryStatus();

            return battery;
        } catch (err) {
            this.#log('WARN', 'HardwareShield', 'Impossibile accedere alla Battery Status API.', err);
            return null;
        }
    }


    /* ========================================================================= */
    /* 11. IPC COMMUNICATION & PRIVATE EVENT BUS SYSTEM                         */
    /* ========================================================================= */

    /**
     * ✉️ Invia un messaggio IPC verso il Service Worker attivo.
     * @param {Object} message - Payload del messaggio
     * @returns {boolean}
     */
    postMessageToSW(message) {
        if (!navigator.serviceWorker.controller) {
            this.#messageQueue.push(message);
            this.#log('WARN', 'IPC', 'Service Worker non ancora controller. Messaggio memorizzato in coda IPC.');
            return false;
        }

        navigator.serviceWorker.controller.postMessage(message);
        return true;
    }

    /**
     * 📤 Invia i messaggi IPC accumulati in coda prima dell'attivazione del controller SW.
     */
    #flushMessageQueue() {
        if (this.#messageQueue.length === 0 || !navigator.serviceWorker.controller) return;

        this.#log('INFO', 'IPC', `Svuotamento di ${this.#messageQueue.length} messaggi in coda IPC verso il SW.`);
        while (this.#messageQueue.length > 0) {
            const msg = this.#messageQueue.shift();
            navigator.serviceWorker.controller.postMessage(msg);
        }
    }

    /**
     * 🎧 Ascolta i messaggi IPC in arrivo dal Service Worker.
     */
    #initIPCListener() {
        navigator.serviceWorker.addEventListener('message', (event) => {
            const { data } = event;
            if (!data || !data.type) return;

            this.#log('INFO', 'IPC', `Messaggio IPC ricevuto dal Service Worker: ${data.type}`, data);
            
            // Emette l'evento IPC con prefisso sw:
            this.#emit(`sw:${data.type.toLowerCase()}`, data);
            this.#emit('ipc:message', data);
        });
    }

    /**
     * 🔄 Registra gli ascoltatori sul ciclo di vita del Service Worker.
     */
    #initLifecycleListeners() {
        if (!this.#swRegistration) return;

        this.#swRegistration.addEventListener('updatefound', () => {
            const installingWorker = this.#swRegistration.installing;
            this.#log('INFO', 'Lifecycle', 'Trovato aggiornamento per il Service Worker...');

            if (installingWorker) {
                installingWorker.addEventListener('statechange', () => {
                    this.#log('INFO', 'Lifecycle', `Stato Service Worker cambiato in: ${installingWorker.state}`);
                    if (installingWorker.state === 'installed' && navigator.serviceWorker.controller) {
                        this.#emit('sw:update_available', { registration: this.#swRegistration });
                    }
                });
            }
        });
    }

    /**
     * 🌐 Inizializza i gestori degli eventi di rete Online/Offline.
     */
    #initNetworkListeners() {
        window.addEventListener('online', () => {
            this.#log('INFO', 'Network', 'Connettività ripristinata (ONLINE).');
            this.#emit('network:online', { timestamp: Date.now() });
            this.processMutationQueue();
        });

        window.addEventListener('offline', () => {
            this.#log('WARN', 'Network', 'Connettività persa (OFFLINE).');
            this.#emit('network:offline', { timestamp: Date.now() });
        });
    }

    /**
     * 🎧 Aggiunge un ascoltatore per gli eventi dell'SDK (Event Emitter).
     * @param {string} event - Nome evento
     * @param {Function} callback - Handler
     */
    on(event, callback) {
        if (!this.#eventListeners.has(event)) {
            this.#eventListeners.set(event, new Set());
        }
        this.#eventListeners.get(event).add(callback);
    }

    /**
     * 🔇 Rimuove un ascoltatore di eventi.
     * @param {string} event - Nome evento
     * @param {Function} callback - Handler da rimuovere
     */
    off(event, callback) {
        if (this.#eventListeners.has(event)) {
            this.#eventListeners.get(event).delete(callback);
        }
    }

    /**
     * 📢 Emette internamente un evento distribuendolo ai callback registrati.
     */
    #emit(event, data) {
        if (this.#eventListeners.has(event)) {
            this.#eventListeners.get(event).forEach(cb => {
                try {
                    cb(data);
                } catch (err) {
                    console.error(`[PanzerSDK EventError][${event}]`, err);
                }
            });
        }
    }

    /**
     * 📊 Restituisce lo stato diagnostico e sintetico dell'SDK.
     * @returns {Object}
     */
    getStatus() {
        return {
            isInitialized: this.#isInitialized,
            isOnline: navigator.onLine,
            swActive: !!(this.#swRegistration && this.#swRegistration.active),
            pendingMutations: this.#mutationQueue.length,
            circuitState: this.#circuitState,
            averageRTT: this.getAverageRTT(),
            telemetryQueueLength: this.#telemetryQueue.length,
            config: { ...this.#config }
        };
    }
}


/* ========================================================================= */
/* 12. SINGLETON INSTANTIATION & DUAL EXPORT BINDING                        */
/* ========================================================================= */

// Genera un'istanza Singleton globale pre-configurata
const panzerSDK = new PanzerSDK();

// Esportazione per ambiente Browser (window)
if (typeof window !== 'undefined') {
    window.PanzerSDK = PanzerSDK;
    window.panzerSDK = panzerSDK;
}

// Esportazione per moduli ES6 / CommonJS / Bundler
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { PanzerSDK, panzerSDK };
}