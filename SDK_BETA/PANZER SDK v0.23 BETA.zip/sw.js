/**
 * ============================================================================
 * 🛡️ PANZER SDK v0.2 BETA
 * 
 * SERVICE WORKER CORE ENGINE & NETWORK ORCHESTRATOR
 * ============================================================================
 * @file       sw.js
 * @description Engine ultra-resiliente per la gestione delle PWA della Pubblica
 *              Amministrazione.
 * @author     Valentino Aglianò
 * @license    EUPL-1.2
 * ============================================================================
 */

'use strict';

/* ============================================================================
 * 1. ⚙️ CONFIGURAZIONE DI STATO, ROTTE & STIVA CACHE
 * ============================================================================ */
const PANZER_SW_CONFIG = Object.freeze({
    ENGINE_VERSION: '7.6.0-BETA',
    CACHE_KEYS: Object.freeze({
        CORE: 'panzer-bunker-v7.6-core',
        DATA: 'panzer-bunker-v7.6-data',
        DYNAMIC: 'panzer-bunker-v7.6-dynamic',
        OFFLINE: 'panzer-bunker-v7.6-offline'
    }),
    TELEMETRY_CHANNEL: 'PANZER_TELEMETRY_BUS',
    TIMEOUT_MS: 5000,
    MAX_RETRIES: 3,
    
    // Assets primari con percorsi relativi per prevenire problemi su sotto-percorsi/GitHub Pages
    CORE_APP_SHELL: Object.freeze([
        './',
        './index.html',
        './js/app.js',
        './js/panzer-sdk.js',
        './PWA.webmanifest',
        './assets-manifest.json'
    ]),

    OFFLINE_FALLBACK_PAGE: './index.html'
});

const telemetryBus = new BroadcastChannel(PANZER_SW_CONFIG.TELEMETRY_CHANNEL);

/* ============================================================================
 * 2. 🧰 UTILITIES AVANZATE: TELEMETRIA, RETRY & CRITTOGRAFIA SHA-256
 * ============================================================================ */

function sendSWTelemetry(type, payload = {}) {
    const message = {
        type: type,
        timestamp: Date.now(),
        source: 'SW_ENGINE',
        version: PANZER_SW_CONFIG.ENGINE_VERSION,
        details: payload, // Mappatura univoca per il client
        ...payload
    };
    
    try {
        telemetryBus.postMessage(message);
    } catch (err) {
        console.error('🚨 [SW] Errore invio telemetria:', err);
    }
    
    console.log(`⚙️ [SW v${PANZER_SW_CONFIG.ENGINE_VERSION}] 📡 Broadcast [${type}]:`, payload);
}

async function fetchWithRetry(request, retries = PANZER_SW_CONFIG.MAX_RETRIES, delayMs = 1000) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), PANZER_SW_CONFIG.TIMEOUT_MS);

    try {
        const response = await fetch(request, { signal: controller.signal });
        clearTimeout(timeoutId);
        
        if (!response.ok && response.status >= 500 && retries > 0) {
            throw new Error(`Server Error HTTP ${response.status}`);
        }
        return response;
    } catch (err) {
        clearTimeout(timeoutId);
        if (retries > 0) {
            console.warn(`📡 [SW] Fetch fallita per: ${typeof request === 'string' ? request : request.url}. Retry tra ${delayMs}ms...`);
            await new Promise(resolve => setTimeout(resolve, delayMs));
            return fetchWithRetry(request, retries - 1, delayMs * 1.5);
        }
        throw err;
    }
}

async function computeSha256Hex(buffer) {
    const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

/* ============================================================================
 * 3. 🔄 CICLO DI VITA: INSTALLAZIONE GRANULARE (`install`)
 * ============================================================================ */
self.addEventListener('install', (event) => {
    console.log(`⚡ [SW] Inizializzazione Service Worker Engine (v${PANZER_SW_CONFIG.ENGINE_VERSION})...`);
    self.skipWaiting();

    event.waitUntil(
        (async () => {
            try {
                sendSWTelemetry('SYNC_START', { detail: 'Inizio pre-caching App Shell e Manifest Assets' });

                const cache = await caches.open(PANZER_SW_CONFIG.CACHE_KEYS.CORE);
                let loaded = 0;
                let failed = 0;

                // Caching App Shell statico
                for (const url of PANZER_SW_CONFIG.CORE_APP_SHELL) {
                    try {
                        const response = await fetchWithRetry(url, 2, 500);
                        if (response.status === 200) {
                            await cache.put(url, response);
                            loaded++;
                        } else {
                            failed++;
                        }
                    } catch (assetErr) {
                        failed++;
                    }
                }

                // Parsing assets-manifest.json
                try {
                    const manifestResponse = await cache.match('./assets-manifest.json') || await fetchWithRetry('./assets-manifest.json', 2, 500);
                    if (manifestResponse && manifestResponse.ok) {
                        const manifestData = await manifestResponse.clone().json();
                        const manifestAssets = Array.isArray(manifestData) 
                            ? manifestData 
                            : (manifestData.files || manifestData.assets || []);

                        const total = manifestAssets.length + loaded;

                        for (const assetUrl of manifestAssets) {
                            if (PANZER_SW_CONFIG.CORE_APP_SHELL.includes(assetUrl)) continue;

                            try {
                                const response = await fetchWithRetry(assetUrl, 2, 500);
                                if (response.status === 200) {
                                    await cache.put(assetUrl, response);
                                    loaded++;
                                } else {
                                    failed++;
                                }
                            } catch (mErr) {
                                failed++;
                            }

                            sendSWTelemetry('SYNC_PROGRESS', {
                                current: loaded,
                                total: total,
                                percent: Math.round((loaded / total) * 100),
                                detail: `Scaricato da Manifest: ${assetUrl}`,
                                failed_assets: failed
                            });
                        }
                    }
                } catch (manifestErr) {
                    console.error('🚨 [SW] Errore parsing Manifest:', manifestErr);
                }

                sendSWTelemetry('SYNC_END', {
                    hasChanged: true,
                    serverVersion: PANZER_SW_CONFIG.ENGINE_VERSION,
                    successCount: loaded,
                    failureCount: failed
                });

                console.log(`✅ [SW] App Shell memorizzato. Totale: ${loaded} (Falliti: ${failed}).`);
            } catch (err) {
                console.error('💥 [SW] Errore installazione:', err);
                sendSWTelemetry('SYNC_ERROR', { error: err.message });
            }
        })()
    );
});

/* ============================================================================
 * 4. 🧹 CICLO DI VITA: ATTIVAZIONE & PURGA STIVE (`activate`)
 * ============================================================================ */
self.addEventListener('activate', (event) => {
    event.waitUntil(
        (async () => {
            await self.clients.claim();
            const cacheNames = await caches.keys();
            const validCacheSet = new Set(Object.values(PANZER_SW_CONFIG.CACHE_KEYS));

            await Promise.all(
                cacheNames.map(cacheName => {
                    if (!validCacheSet.has(cacheName)) {
                        console.log(`🗑️ [SW] Purga cache obsoleta: ${cacheName}`);
                        return caches.delete(cacheName);
                    }
                })
            );
            
            sendSWTelemetry('CORE_UPDATE_RELOAD', { 
                status: 'ACTIVATED',
                version: PANZER_SW_CONFIG.ENGINE_VERSION 
            });
        })()
    );
});

/* ============================================================================
 * 5. 🌐 INTERCETTAZIONE RETE & ROUTING (`fetch`)
 * ============================================================================ */
self.addEventListener('fetch', (event) => {
    const request = event.request;
    const url = new URL(request.url);

    if (request.method !== 'GET' || !url.protocol.startsWith('http')) return;

    event.respondWith(
        (async () => {
            const matchInAnyCache = async (req) => {
                const directMatch = await caches.match(req);
                if (directMatch) return directMatch;
                return await caches.match(url.pathname);
            };

            const isCoreAsset = PANZER_SW_CONFIG.CORE_APP_SHELL.some(asset => request.url.includes(asset.replace('./', '')));
            const isResourceAsset = url.pathname.includes('/resource/') || /\.(pdf|jpg|jpeg|png|webp|svg|gif|woff2?|ttf)$/i.test(url.pathname);

            if (isCoreAsset || isResourceAsset) {
                const cachedAsset = await matchInAnyCache(request);
                if (cachedAsset) return cachedAsset;
            }

            const isApiCall = url.pathname.includes('/api/');
            if (isApiCall) {
                try {
                    const networkResponse = await fetchWithRetry(request, 1, 300);
                    if (networkResponse && networkResponse.status === 200) {
                        const dataCache = await caches.open(PANZER_SW_CONFIG.CACHE_KEYS.DATA);
                        dataCache.put(request, networkResponse.clone());
                    }
                    return networkResponse;
                } catch (networkErr) {
                    const cachedData = await matchInAnyCache(request);
                    if (cachedData) return cachedData;
                }
            }

            const cachedResponse = await matchInAnyCache(request);
            
            const fetchPromise = fetchWithRetry(request, 1, 500)
                .then(async (networkResponse) => {
                    if (networkResponse && networkResponse.status === 200 && (networkResponse.type === 'basic' || networkResponse.type === 'cors')) {
                        const targetCacheKey = url.pathname.endsWith('.json') 
                            ? PANZER_SW_CONFIG.CACHE_KEYS.DATA 
                            : PANZER_SW_CONFIG.CACHE_KEYS.DYNAMIC;
                            
                        const targetCache = await caches.open(targetCacheKey);
                        targetCache.put(request, networkResponse.clone());
                    }
                    return networkResponse;
                })
                .catch(async () => {
                    if (request.headers.get('accept')?.includes('text/html') || request.mode === 'navigate') {
                        const fallbackResponse = await caches.match(PANZER_SW_CONFIG.OFFLINE_FALLBACK_PAGE);
                        if (fallbackResponse) return fallbackResponse;
                    }

                    if (cachedResponse) return cachedResponse;

                    return new Response(
                        JSON.stringify({ error: 'OFFLINE_MODE', message: '⚠️ Dispositivo offline.' }), 
                        { status: 503, headers: { 'Content-Type': 'application/json; charset=utf-8' } }
                    );
                });

            return cachedResponse || fetchPromise;
        })()
    );
});

/* ============================================================================
 * 6. ✉️ COMANDI DIRETTI DA CLIENT (`message`)
 * ============================================================================ */
self.addEventListener('message', (event) => {
    if (!event.data || !event.data.action) return;

    switch (event.data.action) {
        case 'FORCE_PURGE_CACHE':
            event.waitUntil(
                (async () => {
                    const keys = await caches.keys();
                    await Promise.all(keys.map(k => caches.delete(k)));
                    sendSWTelemetry('CORE_UPDATE_RELOAD', { reason: 'MANUAL_PURGE' });
                })()
            );
            break;

        case 'GET_VERSION':
            if (event.ports && event.ports[0]) {
                event.ports[0].postMessage({ 
                    version: PANZER_SW_CONFIG.ENGINE_VERSION,
                    cacheKeys: PANZER_SW_CONFIG.CACHE_KEYS
                });
            }
            break;
    }
});