/**
 * 🛡️ PANZER SDK - BETA v0.2
 * Modulo di controllo integrato per download pacchetti, telemetria in tempo reale,
 * ispezione stiva e crittografia/stoccaggio offline resiliente multi-step.
 */

let PanzerSDKModule = null;
try {
    const imported = await import('./panzer-sdk.js');
    PanzerSDKModule = imported.PanzerSDK || imported.default;
} catch (e) {
    console.warn("⚠️ [ SDK Panzer ] 'panzer-sdk.js' in modalità fallback/mock.");
}

(() => {
    'use strict';

    /* ========================================================================
     * 1. CONFIGURAZIONE GLOBALE ED ELEMENTI DOM
     * ======================================================================== */
    const CONFIG = Object.freeze({
        SDK_CHANNEL_NAME: 'PANZER_TELEMETRY_BUS',
        SW_SCRIPT_PATH: './sw-generico.js',
        DB_FETCH_ENDPOINT: './assets-manifest.json',
        CACHE_PREFIX: 'panzer-bunker-v7.6',
        
        // Elenco essenziale per la resilienza dell'App Shell Core
        CORE_APP_SHELL: Object.freeze([
            './',
            './index.html',
            './js/app.js',
            './js/panzer-sdk.js',
            './PWA.webmanifest',
            './assets-manifest.json'
        ]),

        DOM_IDS: Object.freeze({
            STATUS_BADGE: 'panzer-status-badge',
            PROGRESS_BAR: 'panzer-progress-bar',
            PROGRESS_TEXT: 'panzer-progress-text',
            METRIC_COMPLETED: 'metric-completed',
            METRIC_TOTAL: 'metric-total',
            METRIC_FAILED: 'metric-failed',
            METRIC_RETRIES: 'metric-retries',
            TERMINAL_OUTPUT: 'panzer-terminal-output',
            SYNC_BTN: 'panzer-btn-sync',
            PURGE_BTN: 'panzer-btn-purge',
            CLEAR_LOG_BTN: 'panzer-btn-clear-log',
            REFRESH_STORAGE_BTN: 'panzer-btn-refresh-storage',
            STORAGE_SEARCH_INPUT: 'panzer-storage-search',
            STORAGE_TBODY: 'panzer-storage-tbody'
        })
    });

    const state = {
        sdkInstance: null,
        isSyncing: false,
        telemetryBus: null,
        storageItems: [],
        metrics: {
            completed: 0,
            total: 0,
            failed: 0,
            retries: 0
        }
    };

    const dom = {};

    /* ========================================================================
     * 2. HELPER DI RETE CON RETRY AUTOMATICI E TIMEOUT (RESILIENZA)
     * ======================================================================== */

    async function fetchWithRetry(url, retries = 3, delayMs = 500, timeoutMs = 5000) {
        for (let attempt = 1; attempt <= retries; attempt++) {
            try {
                const controller = new AbortController();
                const timer = setTimeout(() => controller.abort(), timeoutMs);
                
                const response = await fetch(url, { cache: 'reload', signal: controller.signal });
                clearTimeout(timer);

                if (response.ok) return response;

                if (attempt < retries) {
                    state.metrics.retries++;
                    processTelemetryEvent({ type: 'SYNC_RETRY', details: { url, attempt, status: response.status } });
                    await new Promise(r => setTimeout(r, delayMs * attempt));
                } else {
                    throw new Error(`HTTP ${response.status}`);
                }
            } catch (err) {
                if (attempt < retries) {
                    state.metrics.retries++;
                    processTelemetryEvent({ type: 'SYNC_RETRY', details: { url, attempt, error: err.message } });
                    await new Promise(r => setTimeout(r, delayMs * attempt));
                } else {
                    throw err;
                }
            }
        }
    }

    /* ========================================================================
     * 3. LOGGING, ESTRAZIONE URL E INTERFACCIA UTENTE
     * ======================================================================== */

    function extractAssetUrlsFromManifest(manifestData) {
        const urls = new Set();
        if (!manifestData) return [];

        const rawList = Array.isArray(manifestData) 
            ? manifestData 
            : (manifestData.assets || manifestData.files || manifestData.data || []);

        rawList.forEach(entry => {
            if (typeof entry === 'string') {
                let cleanUrl = entry.trim().replace(/^\/+/, '');
                if (!cleanUrl.startsWith('./')) cleanUrl = `./${cleanUrl}`;
                urls.add(cleanUrl);
            } else if (typeof entry === 'object' && entry !== null) {
                let dir = (entry.dir || entry.directory || entry.path || '').trim();
                const files = Array.isArray(entry.files) ? entry.files : (entry.file ? [entry.file] : []);

                files.forEach(fileName => {
                    if (typeof fileName === 'string') {
                        let fullPath = `${dir}/${fileName}`.replace(/\/+/g, '/').replace(/^\/+/, '');
                        if (!fullPath.startsWith('./')) fullPath = `./${fullPath}`;
                        urls.add(fullPath);
                    }
                });
            }
        });

        return Array.from(urls);
    }
    
    function logToTerminal(level, message, payload = null) {
        const time = new Date().toLocaleTimeString('it-IT', { hour12: false });
        let icon = 'ℹ️';
        let cssClass = 'log-info';

        switch (level) {
            case 'SUCCESS': icon = '✅'; cssClass = 'log-success'; break;
            case 'WARN':    icon = '⚠️'; cssClass = 'log-warn'; break;
            case 'ERROR':   icon = '🚨'; cssClass = 'log-error'; break;
            case 'SYNC':    icon = '🔄'; cssClass = 'log-sync'; break;
            case 'VAULT':   icon = '🔐'; cssClass = 'log-vault'; break;
            case 'INIT':    icon = '⚡'; cssClass = 'log-info'; break;
        }

        const logText = `[${time}] ${icon} [${level}] ${message}`;

        if (level === 'ERROR') console.error(logText, payload || '');
        else if (level === 'WARN') console.warn(logText, payload || '');
        else console.log(logText, payload || '');

        if (dom.TERMINAL_OUTPUT) {
            const line = document.createElement('div');
            line.className = `terminal-line ${cssClass}`;
            line.textContent = logText + (payload ? ` | Det: ${JSON.stringify(payload)}` : '');
            dom.TERMINAL_OUTPUT.appendChild(line);
            
            requestAnimationFrame(() => {
                dom.TERMINAL_OUTPUT.scrollTop = dom.TERMINAL_OUTPUT.scrollHeight;
            });
        }
    }

    function cacheDOMReferences() {
        Object.keys(CONFIG.DOM_IDS).forEach(key => {
            dom[key] = document.getElementById(CONFIG.DOM_IDS[key]);
        });
    }

    function updateBadge(text, typeClass) {
        if (!dom.STATUS_BADGE) return;
        dom.STATUS_BADGE.textContent = text;
        dom.STATUS_BADGE.className = `badge-status ${typeClass}`;
    }

    /* ========================================================================
     * 4. TELEMETRIA BROADCAST CHANNEL
     * ======================================================================== */

    function setupTelemetryBus() {
        try {
            state.telemetryBus = new BroadcastChannel(CONFIG.SDK_CHANNEL_NAME);
            state.telemetryBus.onmessage = (event) => {
                if (event.data) processTelemetryEvent(event.data);
            };
            logToTerminal('INIT', `Canale di telemetria agganciato: '${CONFIG.SDK_CHANNEL_NAME}'`);
        } catch (err) {
            logToTerminal('WARN', 'BroadcastChannel non supportato, canale fallback attivo.', err.message);
        }
    }

    function processTelemetryEvent(evt) {
        if (!evt || !evt.type) return;

        const det = evt.details || evt.detail || evt;

        switch (evt.type) {
            case 'SYNC_START':
                state.isSyncing = true;
                updateBadge('🔄 Sincronizzazione in corso', 'badge-sync');
                logToTerminal('SYNC', 'Avvio procedura di sincronizzazione multi-step...');
                resetMetrics();
                break;

            case 'SYNC_PROGRESS':
                state.metrics.completed = det.current || state.metrics.completed;
                state.metrics.total = det.total || state.metrics.total;
                state.metrics.failed = det.failed_assets || state.metrics.failed;
                updateMetricsUI(det.percent || 0);
                break;

            case 'SYNC_RETRY':
                logToTerminal('WARN', 'Retry di rete per risorsa instabile...', det);
                updateMetricsUI(0);
                break;

            case 'VAULT_STORE_SUCCESS':
                logToTerminal('VAULT', `Pacchetto archiviato: ${evt.assetPath || det.assetPath || 'Asset'}`);
                break;

            case 'SYNC_ERROR':
                state.isSyncing = false;
                updateBadge('🚨 Errore Sincronizzazione', 'badge-error');
                logToTerminal('ERROR', 'Errore durante lo scaricamento stiva:', det);
                break;

            case 'SYNC_END':
                state.isSyncing = false;
                updateMetricsUI(100);
                updateBadge('🟢 Stiva Aggiornata & Criptata', 'badge-ready');
                logToTerminal('SUCCESS', `Sincronizzazione completata! Modificato: ${det.hasChanged ? 'SÌ 🔄' : 'NO 🔒'}`, {
                    versioneServer: det.serverVersion || '7.6.0',
                    totaleElaborati: state.metrics.total,
                    falliti: state.metrics.failed
                });
                refreshStorageVaultInspector();
                break;

            default:
                break;
        }
    }

    function updateMetricsUI(percent) {
        const pct = Math.min(100, Math.max(0, Math.floor(percent)));

        if (dom.PROGRESS_BAR) dom.PROGRESS_BAR.value = pct;
        if (dom.PROGRESS_TEXT) dom.PROGRESS_TEXT.textContent = `${pct}% (${state.metrics.completed}/${state.metrics.total})`;

        if (dom.METRIC_COMPLETED) dom.METRIC_COMPLETED.textContent = state.metrics.completed;
        if (dom.METRIC_TOTAL) dom.METRIC_TOTAL.textContent = state.metrics.total;
        if (dom.METRIC_FAILED) dom.METRIC_FAILED.textContent = state.metrics.failed;
        if (dom.METRIC_RETRIES) dom.METRIC_RETRIES.textContent = state.metrics.retries;
    }

    function resetMetrics() {
        state.metrics = { completed: 0, total: 0, failed: 0, retries: 0 };
        updateMetricsUI(0);
    }

    /* ========================================================================
     * 5. ESECUZIONE SINCRONIZZAZIONE RESILIENTE MULTI-STEP
     * ======================================================================== */

    async function executeBunkerSync() {
        if (state.isSyncing) {
            logToTerminal('WARN', 'Sincronizzazione già in corso...');
            return;
        }

        state.isSyncing = true;
        processTelemetryEvent({ type: 'SYNC_START' });

        try {
            // FASE 1: SINCRONIZZAZIONE CORE APP SHELL
            logToTerminal('SYNC', '▶️ FASE 1/3: Sincronizzazione resiliente Core App Shell...');
            const coreCache = await caches.open(`${CONFIG.CACHE_PREFIX}-core`);
            const coreAssets = CONFIG.CORE_APP_SHELL;
            let currentProcessed = 0;

            for (const assetUrl of coreAssets) {
                try {
                    const res = await fetchWithRetry(assetUrl, 3, 500);
                    await coreCache.put(assetUrl, res.clone());
                    state.metrics.completed++;
                    logToTerminal('VAULT', `Core Asset salvato: ${assetUrl}`);
                } catch (coreErr) {
                    state.metrics.failed++;
                    logToTerminal('WARN', `Fallito scaricamento Core Asset (${assetUrl}): ${coreErr.message}`);
                }

                currentProcessed++;
                const phasePct = Math.round((currentProcessed / coreAssets.length) * 30); // Max 30% per la Fase 1
                processTelemetryEvent({
                    type: 'SYNC_PROGRESS',
                    details: { current: state.metrics.completed, total: coreAssets.length, failed_assets: state.metrics.failed, percent: phasePct }
                });
            }

            // FASE 2: LETTURA E VALIDAZIONE MANIFESTO
            logToTerminal('SYNC', '▶️ FASE 2/3: Lettura e validazione del manifesto risorse...');
            let dbContent = null;
            try {
                const response = await fetchWithRetry(CONFIG.DB_FETCH_ENDPOINT, 3, 500);
                dbContent = await response.json();
            } catch (e) {
                logToTerminal('WARN', `'${CONFIG.DB_FETCH_ENDPOINT}' non raggiungibile o formato non valido.`);
            }

            // FASE 3: SINCRONIZZAZIONE RISORSE DINAMICHE DA MANIFESTO
            logToTerminal('SYNC', '▶️ FASE 3/3: Scaricamento e archiviazione risorse dal manifesto...');
            const assetList = extractAssetUrlsFromManifest(dbContent);
            const dataCache = await caches.open(`${CONFIG.CACHE_PREFIX}-data`);

            const grandTotal = coreAssets.length + assetList.length;
            state.metrics.total = grandTotal;

            for (let i = 0; i < assetList.length; i++) {
                const assetUrl = assetList[i];
                try {
                    const res = await fetchWithRetry(assetUrl, 3, 500);
                    await dataCache.put(assetUrl, res.clone());
                    state.metrics.completed++;
                    processTelemetryEvent({ type: 'VAULT_STORE_SUCCESS', assetPath: assetUrl });
                } catch (fetchErr) {
                    state.metrics.failed++;
                    logToTerminal('WARN', `Fallito scaricamento Data Asset (${assetUrl}): ${fetchErr.message}`);
                }

                currentProcessed++;
                const globalPct = Math.round((currentProcessed / grandTotal) * 100);
                processTelemetryEvent({
                    type: 'SYNC_PROGRESS',
                    details: { current: state.metrics.completed, total: grandTotal, failed_assets: state.metrics.failed, percent: globalPct }
                });
            }

            processTelemetryEvent({
                type: 'SYNC_END',
                details: { hasChanged: true, serverVersion: dbContent?.version || '7.6.0' }
            });

        } catch (err) {
            logToTerminal('ERROR', 'Fallimento critico durante il flusso di sincronizzazione:', err.message);
            updateBadge('🚨 Errore Sincronizzazione', 'badge-error');
        } finally {
            state.isSyncing = false;
        }
    }

    /* ========================================================================
     * 6. ISPETTORE CACHE / STIVA LOCALE
     * ======================================================================== */

    async function refreshStorageVaultInspector() {
        if (!dom.STORAGE_TBODY) return;

        try {
            const cacheKeys = await caches.keys();
            const foundAssets = [];

            for (const cacheName of cacheKeys) {
                const cache = await caches.open(cacheName);
                const requests = await cache.keys();

                for (const req of requests) {
                    const res = await cache.match(req);
                    if (res) {
                        let size = 0;
                        try {
                            const blob = await res.clone().blob();
                            size = blob.size;
                        } catch (e) {
                            size = parseInt(res.headers.get('content-length') || '0', 10);
                        }

                        foundAssets.push({
                            url: req.url,
                            cacheName: cacheName,
                            contentType: res.headers.get('Content-Type') || 'application/octet-stream',
                            sizeBytes: size
                        });
                    }
                }
            }

            state.storageItems = foundAssets;
            renderStorageTable(foundAssets);
            logToTerminal('VAULT', `Ispezione stiva: Trovate ${foundAssets.length} risorse memorizzate.`);
        } catch (err) {
            logToTerminal('ERROR', 'Errore scansione Cache Storage:', err.message);
        }
    }

    function renderStorageTable(items) {
        if (!dom.STORAGE_TBODY) return;

        const query = (dom.STORAGE_SEARCH_INPUT?.value || '').toLowerCase().trim();
        const filtered = items.filter(item => 
            item.url.toLowerCase().includes(query) ||
            item.contentType.toLowerCase().includes(query) ||
            item.cacheName.toLowerCase().includes(query)
        );

        if (filtered.length === 0) {
            dom.STORAGE_TBODY.innerHTML = `
                <tr>
                    <td colspan="5" style="text-align: center; color: #8b949e; padding: 15px;">
                        ${query ? 'Nessun risultato corrisponde alla ricerca.' : 'Stiva locale vuota.'}
                    </td>
                </tr>`;
            return;
        }

        dom.STORAGE_TBODY.innerHTML = filtered.map(item => {
            const urlObj = new URL(item.url, window.location.href);
            const filename = urlObj.pathname.split('/').pop() || urlObj.pathname;
            const sizeKb = (item.sizeBytes / 1024).toFixed(1);
            const isPdf = filename.toLowerCase().endsWith('.pdf');

            return `
                <tr>
                    <td style="font-weight: 600; color: #c9d1d9;" title="${item.url}">
                        ${isPdf ? '📄' : '📦'} ${filename}
                    </td>
                    <td style="color: #8b949e; font-size: 0.8rem;">${item.contentType}</td>
                    <td style="font-family: monospace; font-size: 0.8rem;">${sizeKb} KB</td>
                    <td style="color: #a371f7; font-size: 0.8rem;">${item.cacheName}</td>
                    <td>
                        <a href="${item.url}" target="_blank" rel="noopener noreferrer" class="btn btn-sm">
                            🔗 Apri
                        </a>
                    </td>
                </tr>`;
        }).join('');
    }

    /* ========================================================================
     * 7. REGISTRAZIONE SERVICE WORKER ED INIZIALIZZAZIONE
     * ======================================================================== */

    async function registerServiceWorker() {
        if (!('serviceWorker' in navigator)) return;
        try {
            const reg = await navigator.serviceWorker.register(CONFIG.SW_SCRIPT_PATH, { scope: './' });
            logToTerminal('INIT', `Service Worker attivo (${CONFIG.SW_SCRIPT_PATH}). Scope: ${reg.scope}`);
        } catch (err) {
            logToTerminal('WARN', 'Service Worker non registrato (ambiente di dev locale o assenza HTTPS).');
        }
    }

    async function initApp() {
        cacheDOMReferences();
        logToTerminal('INIT', 'Inizializzazione Bunker Console v7.6...');

        setupTelemetryBus();
        await registerServiceWorker();

        if (PanzerSDKModule) {
            try {
                state.sdkInstance = new PanzerSDKModule();
                logToTerminal('SUCCESS', 'PanzerSDK caricato e agganciato.');
            } catch (e) {
                logToTerminal('WARN', 'Istanza SDK fallita, attivo modulo integrato.');
            }
        } else {
            logToTerminal('WARN', 'Esecuzione in modalità Standalone Engine.');
        }

        if (dom.SYNC_BTN) dom.SYNC_BTN.addEventListener('click', executeBunkerSync);

        if (dom.PURGE_BTN) {
            dom.PURGE_BTN.addEventListener('click', async () => {
                if (confirm('CONFERMA PURGA TOTALE: Vuoi davvero svuotare la stiva locale?')) {
                    logToTerminal('WARN', 'Avvio purga totale della stiva...');
                    if (navigator.serviceWorker.controller) {
                        navigator.serviceWorker.controller.postMessage({ action: 'FORCE_PURGE_CACHE' });
                    }
                    const cacheKeys = await caches.keys();
                    await Promise.all(cacheKeys.map(k => caches.delete(k)));
                    logToTerminal('SUCCESS', 'Purga completata. La stiva locale è vuota.');
                    refreshStorageVaultInspector();
                }
            });
        }

        if (dom.CLEAR_LOG_BTN && dom.TERMINAL_OUTPUT) {
            dom.CLEAR_LOG_BTN.addEventListener('click', () => dom.TERMINAL_OUTPUT.innerHTML = '');
        }

        if (dom.REFRESH_STORAGE_BTN) {
            dom.REFRESH_STORAGE_BTN.addEventListener('click', refreshStorageVaultInspector);
        }

        if (dom.STORAGE_SEARCH_INPUT) {
            dom.STORAGE_SEARCH_INPUT.addEventListener('input', () => renderStorageTable(state.storageItems));
        }

        updateBadge('🟢 Pronto - Sistema Operativo', 'badge-ready');
        refreshStorageVaultInspector();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initApp);
    } else {
        initApp();
    }
})();