/*
 * 🌀 SDK Framework PANZER v7+ 🪖
 *
 * ⚙️ CORE: 🪖 PANZER v7.6+ (SDK VERSION)
 *
 * 🛡️ REQUISITI OPERATIVI DI SISTEMA
 *
 * 1. 🧱🔀 ISOLAMENTO DEI FLUSSI:
 * Profilazione fisica del canale tramite modulo SDK e orchestrazione sicura della memoria volatile.
 *
 * 2. 🔀🎭 INSTRADAMENTO POLIMORFO:
 * Flusso Fluido d'ufficio basato su scansione ciclica 'for...in' e telemetria hardware.
 *
 * 3. 🩻🪨 RESILIENZA STRUTTURALE:
 * Meccanismo Smart Sync con campionamento RTT e interruzione atomica via AbortController.
 *
 * 4. 🔬🧬 SW FORENSICS (DNA CHECK):
 * Ispezione biometrica sequenziale del payload su tre (3) scomparti stagni:
 * - FASE 1 (TESTA 🤯): Validazione Strict dei Magic Numbers contro attacchi di MIME-sniffing.
 * - FASE 2 (CODA 🚓🚓🚓): Verifica dei marcatori strutturali (Footer 👣) contro attacchi di tipo Append.
 * - FASE 3 (CORPO 🪵🧬): Analisi euristica stringente anti-script per l'intercettazione di vettori malevoli nei PDF.
 *
 * 5. 🌡️🛡️ CPU THERMAL SHIELD:
 * Ottimizzatore adattivo del respiro dell'Event Loop via 'waitTillIdle' per la prevenzione del logoramento hardware.
 *
 * ⚙️ NUCLEO: PANZER SDK 🪖 "PANZER V7.5"
 * 🎖 MILITARY EDITION (CRYPTOGRAPHIC VAULT AES-GCM 256-BIT)
 * Licenza di Distribuzione:
 * 🇪🇺📜 EUPL 1.2 (Conforme alle direttive CAD della PA 🏛️)
 *
 * Sviluppo Software e Ingegnerizzazione del Protocollo a cura di:
 * 👩‍💻🇮🇹 Valentino Aglianò - Perito Industriale Informatico (2013)
 * [ Istruttore Informatico - Idoneo Nazionale MaxConcorso ASMEL 2025 ]
 *
 * 🛡️ DIRECTIVE DI SICUREZZA ATTIVA E BONIFICA FORENSE (🔐 ZERO-TRUST POLICY 🚨)
 *
 * [🔑 MASTER KEY]: Istanza crittografica non esportabile (CryptoKey) generata a runtime e isolata in RAM volatile.
 * [🗄️ PWA_VAULT]: Persistenza protetta della chiave opaca in IndexedDB ➿ tramite algoritmo di clonazione strutturata (extractable: false).
 * [🫙 SANDBOX CONTENIMENTO]: Iniezione perentoria di header CSP restrittivi per l'isolamento dei contenuti erogati a schermo.
 * [🦈 WATCHDOG LOOPBACK]: Test atomico di cifratura/decrittazione simmetrica a runtime (🐦 vaultCanaryText) per la validazione della memoria.
 * [🚨🧼 EMERGENCY WIPE]: Tabula rasa immediata, distruzione totale e bonifica delle cache in caso di fallimento strutturale del canarino.
 * [🚧🕵️ ANTI-MEMORY INSPECTION]: Sovrascrittura fisica e azzeramento dei buffer binari di transito (headBuffer, tailBuffer, fullBuffer), tramite metodo nativo 'Uint8Array.prototype.fill(0)' immediatamente post-elaborazione.
 */

export class PanzerSDK {
    constructor(customConfig = {}) {
        this.encryptionKey = null;
        this.isLogicEnabled = false;
        this.syncAbortController = null;
        this.globalAbortController = new AbortController();
        this.lastVaultCheck = 0;
        this.isCanaryLock = false;
        this.CHECK_INTERVAL = 300000;
        this.isNewInstallation = false;
        this.isSyncing = false;
        this.lastReloadCommandTime = 0;
        this.globalPlaceholderBlob = null;

        const getLocationPath = () => {
            try {
                if (typeof window !== 'undefined' && window.location) {
                    return window.location.pathname;
                } else if (typeof self !== 'undefined' && self.location) {
                    return self.location.pathname;
                }
            } catch (e) {}
            return '/';
        };

        const BASE_PATH = getLocationPath().replace(/[^\/]+$/, "").replace(/\/+/g, '/');

        /**
         * 📊 CONFIGURAZIONE GLOBALE (Dizionario dei Vincoli Operativi)
         * Definisce i parametri strutturali per la resilienza di rete, crittografia e tolleranza ai guasti.
         */
        this.CONFIG = {
            ROOT: BASE_PATH,
            cacheName:      'PWA_PIZZA_ENGINE_v7.6',
            userCacheName: 'user_PWA_PIZZA_ENGINE_v7.6',
            vaultCanaryText: 'KANARY_OK_PANZER_KEY',
            userCacheTTL: 7,
            networkResilient: {
                maxRetries: 5,
                timeWaitSec: 3,
                profiles: {
                    'Ultrafast': { limit: 12, timeout: 15 },
                    'Fast':      { limit: 8,  timeout: 20 },
                    'Medium':    { limit: 4,  timeout: 45 },
                    'Low':       { limit: 2,  timeout: 90 },
                    'Verylow':   { limit: 1,  timeout: 120 }
                }
            },
            minSizeMap: {
                'image': {
                   'webp': 500,
                   'jpeg': 5000,
                   'jpg': 5000,
                   'png': 500,
                   'avif': 500,
                   'svg': 100,
                   'magicNumbers': {
                       'header': [
                           '52494646', // WEBP/RIFF
                           'FFD8FF',   // JPEG
                           '89504E47', // PNG
                           '3C737667'  // SVG
                        ],
                       'footer': [
                           '49454E44AE426082', // PNG (IEND)
                           'FFD9',             // JPEG (EOI)
                           '3B',               // GIF (Terminator)
                           '3C2F7376673E'      // SVG (</svg>)
                        ]
                   },
                   'useHeadProbe': true,
                   'tolerance': 0.30,
                   'defaultMin': 500
                },
                'pdf': {
                   'firmato': 5000,
                   'default': 10000,
                   'magicNumbers': {
                       'header': ['25504446'], // %PDF (Rilevazione universale)
                       'footer': ['2525454F46']  // %%EOF (Rilevazione strutturale di coda)
                   },
                   'pdfMaliciousPatterns': [
                       '/JavaScript',
                       '/JS',
                       '/Launch',
                       '/OpenAction'
                   ],
                   'useHeadProbe': false,
                   'tolerance': 0.30,
                   'defaultMin': 1000
                },
                'code': {
                    'html': 100,
                    'css': 100,
                    'js': 100,
                    'json': 10,
                    'magicNumbers': {
                        'header': [],
                        'footer': []
                    },
                    'useHeadProbe': true,
                    'tolerance': 0.20,
                    'defaultMin': 100
                },
                'universal': {
                    'tolerance': 0.05,
                    'minAbsoluteByte': 64,
                    'fallbackToGet': true
                }
            },
            coreAssets: [
                BASE_PATH,
                `${BASE_PATH}index.html`,
                `${BASE_PATH}style.css`,
                `${BASE_PATH}script.js`,
                `${BASE_PATH}db.json`,
                `${BASE_PATH}PWA.webmanifest`,
                `${BASE_PATH}sw/assets-manifest.json`,
                `${BASE_PATH}sw/icon/hicon.png`,
                `${BASE_PATH}sw/icon/menu96.png`,
                `${BASE_PATH}sw/icon/menu512.png`
            ],
            manifestPath: `${BASE_PATH}sw/assets-manifest.json`,
            mappingLogic: {
                idKeys: [ 'id' ],
                contexts: {
                    'docs_it': { path: 'dir_img/pdf/ita/', ext: '.pdf' },
                    'docs_en': { path: 'dir_img/pdf/eng/', ext: '.pdf' },
                    'base':    { path: 'dir_img/',          ext: '.webp' }
                },
                parentSpecials: {
                    'pizze':   { prefix: 'pz_', ext: '.webp' },
                    'piatti':  { prefix: 'pi_', ext: '.webp' },
                    'gallery': { prefix: '',    ext: '.jpg', isSequential: true }
                }
            },
            defPlaceHolderLogo: `${BASE_PATH}sw/icon/hicon.png`,
            defaultExt: '.webp',
            extensions: [
                'jpg', 'jpeg', 'png', 'webp',
                'pdf'
            ],
            extExlPHr: [
                'pdf', 'zip', 'doc', 'docx'
            ],
            get syncRegex() {
                return new RegExp(`\\.(${this.extensions.join('|')})$`, 'i');
            },
            get allVariants() {
                const variants = [];
                this.extensions.forEach(ext => {
                    variants.push('.' + ext.toLowerCase(), '.' + ext.toUpperCase());
                });
                return [...new Set(variants)];
            },
            ...customConfig
        };

        const BROKEN_IMAGE_SVG_STRING = `<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 24 24" fill="none" stroke="#444" stroke-width="1" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><line x1="3" y1="21" x2="21" y2="3"/><path d="M9 11a2 2 0 1 0 0-4 2 2 0 0 0 0 4z"/><path d="M21 15l-5-5L5 21"/></svg>`;
        this.GLOBAL_BROKEN_BLOB = new Blob([BROKEN_IMAGE_SVG_STRING], { type: 'image/svg+xml' });
        Object.freeze(this.GLOBAL_BROKEN_BLOB);

        this.CORE_ASSETS_SET = new Set(
            (this.CONFIG.coreAssets || []).map(asset => this.normalize(asset))
        );

        /*
         * 🚧 SBARRAMENTO LOGICO IN CASCATA 🚧
         * ❄️ DEEP FREEZE: Ciclo ricorsivo di congelamento profondo.
         */
        this.deepFreeze(this.CONFIG);
    }

    deepFreeze(obj) {
        if (obj && typeof obj === 'object') {
            Object.freeze(obj);
            for (const key of Object.getOwnPropertyNames(obj)) {
                const prop = obj[key];
                if (prop !== null && typeof prop === 'object' && !Object.isFrozen(prop)) {
                    this.deepFreeze(prop);
                }
            }
        }
    }

    /**
     * 🛡⏱️ SHIELD TEMPORALE (ANTI-TIMING ATTACK)
     */
    async injectTimingNoise(startTime, targetBaselineMs = 45) {
        try {
            const elapsed = performance.now() - startTime;
            if (elapsed < targetBaselineMs) {
                const padding = targetBaselineMs - elapsed;
                const jitter = Math.random() * (25 - 5) + 5;
                const totalShieldTime = Math.ceil(padding + jitter);
                await this.sleep(totalShieldTime);
            } else {
                const microJitter = Math.random() * (5 - 1) + 1;
                await this.sleep(Math.ceil(microJitter));
            }
        } catch (e) {}
    }

    /**
     * ⏳ Generatore di ritardo temporizzato isolato.
     */
    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    /**
     * ⏳💤 Ottimizzatore adattivo del respiro della CPU per Service Worker / SDK.
     */
    waitTillIdle(minPauseMs = 200, timeoutMs = 8000) {
        return new Promise((resolve) => {
            const pausaBaseMinima = Math.max(200, minPauseMs);
            const inizioTest = performance.now();
            const ATTESA_TEST_MS = 20;
            setTimeout(() => {
                const fineTest = performance.now();
                const tempoEffettivo = fineTest - inizioTest;
                const driftEventLoop = Math.max(0, tempoEffettivo - ATTESA_TEST_MS);
                const coefficienteSensibilita = 25;
                let tempoRespiroCalcolato = pausaBaseMinima + (driftEventLoop * coefficienteSensibilita);
                tempoRespiroCalcolato = Math.min(tempoRespiroCalcolato, timeoutMs);
                console.log(`⏳ SDK Drift: ${driftEventLoop.toFixed(1)}ms -> Pausa applicata: ${Math.round(tempoRespiroCalcolato)}ms`);
                setTimeout(resolve, tempoRespiroCalcolato);
            }, ATTESA_TEST_MS);
        });
    }

    /**
     * 🔍🧬 SW Forensics & DNA Check.
     */
    async isValidBlob(input, contentType, expectedSize = 0, isEncrypted = false, signals = null) {
        const startForensicTime = performance.now();
        let signal = signals || null;
        let blob;
        let encoding = null;
        let finalContentType = contentType;
        let result = { valid: false, blob: null };

        if (input instanceof Response) {
            if (signal?.aborted) return result;
            encoding = input.headers.get('Content-Encoding');
            finalContentType = contentType || input.headers.get('Content-Type') || '';
            try {
                blob = await input.blob();
            } catch (e) {
                await this.injectTimingNoise(startForensicTime, 50);
                return result;
            }
        } else {
            blob = input;
        }

        if (!blob || !(blob instanceof Blob)) {
            await this.injectTimingNoise(startForensicTime, 50);
            return result;
        }

        const mainType = finalContentType.split('/')[0];
        const subType = finalContentType.split('/')[1]?.split(';')[0] || '';
        const section = this.CONFIG.minSizeMap[mainType] || this.CONFIG.minSizeMap['code'] || null;

        const isTransformed = encoding !== null && encoding !== 'identity';
        let minSize = this.CONFIG.minSizeMap.universal.minAbsoluteByte;
        if (section) {
            Object.freeze(section);
            const tolerance = section.tolerance || this.CONFIG.minSizeMap.universal.tolerance;
            const baseMin = section[subType] || section.defaultMin || section.default || 0;
            minSize = (expectedSize > 0) ? (expectedSize * (1 - tolerance)) : baseMin;
        }

        if (isEncrypted || isTransformed) minSize = this.CONFIG.minSizeMap.universal.minAbsoluteByte;
        if (blob.size < minSize) {
            await this.injectTimingNoise(startForensicTime, 50);
            console.log(`⚠️ SDK Forensics: Asset scartato (${blob.size}b < Min: ${Math.round(minSize)}b) -> ${finalContentType}`);
            return result;
        }

        let headerBuffer = null;
        let tailBuffer = null;
        let fullBuffer = null;

        // --- 🛡️ FASE 1: ANALISI DEI MAGIC NUMBERS DI TESTA (HEADER) ---
        if (!isEncrypted && !isTransformed && section && section.magicNumbers?.header?.length > 0) {
            try {
                if (signal?.aborted) return result;
                headerBuffer = await blob.slice(0, 12).arrayBuffer();
                let headerHex = Array.from(new Uint8Array(headerBuffer))
                    .map(b => b.toString(16).padStart(2, '0'))
                    .join('').toUpperCase();
                const hasValidSig = section.magicNumbers.header.some(sig => headerHex.includes(sig.toUpperCase()));
                if (!hasValidSig) {
                    if (!(subType === 'webp' && headerHex.startsWith('52494646') && headerHex.includes('57454250'))) {
                        await this.injectTimingNoise(startForensicTime, 50);
                        console.log(`🛡️ SDK Security: Firma [ TESTA ] fallita per ${finalContentType}.\nDNA 🧬: ${headerHex}`);
                        if (headerBuffer) new Uint8Array(headerBuffer).fill(0);
                        return result;
                    }
                }
            } catch (e) {
                if (headerBuffer) new Uint8Array(headerBuffer).fill(0);
                await this.injectTimingNoise(startForensicTime, 50);
                return result;
            }
        }

        // --- 🛡️ FASE 2: ANALISI DEI MARCATORI DI CODA (FOOTER) ---
        if (!isEncrypted && !isTransformed && section && section.magicNumbers?.footer?.length > 0) {
            try {
                if (signal?.aborted) {
                    if (headerBuffer) new Uint8Array(headerBuffer).fill(0);
                    return result;
                }
                const fetchSize = Math.min(blob.size, 128);
                tailBuffer = await blob.slice(-fetchSize).arrayBuffer();
                const tailHex = Array.from(new Uint8Array(tailBuffer))
                    .map(b => b.toString(16).padStart(2, '0'))
                    .join('').toUpperCase();

                const hasValidFooter = section.magicNumbers.footer.some(foot => tailHex.includes(foot.toUpperCase()));
                if (!hasValidFooter) {
                    console.log(`🛡️ SDK Security: Firma [ CODA ] fallita o corrotta per ${finalContentType}.\n👣 TAIL DNA 🧬: ${tailHex}`);
                    if (headerBuffer) new Uint8Array(headerBuffer).fill(0);
                    if (tailBuffer) new Uint8Array(tailBuffer).fill(0);
                    return result;
                }
            } catch (e) {
                await this.injectTimingNoise(startForensicTime, 50);
                if (headerBuffer) new Uint8Array(headerBuffer).fill(0);
                if (tailBuffer) new Uint8Array(tailBuffer).fill(0);
                return result;
            }
        }

        // --- 🛡️ FASE 3: ANALISI EURISTICA ANTI-SCRIPT (SPECIFICA PER PDF) ---
        const isPdf = mainType.toLowerCase().includes('pdf');
        if (!isEncrypted && !isTransformed && isPdf && section?.pdfMaliciousPatterns) {
            try {
                if (signal?.aborted) {
                    if (headerBuffer) new Uint8Array(headerBuffer).fill(0);
                    if (tailBuffer) new Uint8Array(tailBuffer).fill(0);
                    return result;
                }

                const localPatterns = [...(section.pdfMaliciousPatterns || [])];
                Object.freeze(localPatterns);

                await this.waitTillIdle(200, 8000);

                fullBuffer = await blob.arrayBuffer();
                const pdfTextContent = new TextDecoder('utf-8').decode(new Uint8Array(fullBuffer));

                for (const pattern of localPatterns) {
                    if (pdfTextContent.includes(pattern)) {
                        await this.injectTimingNoise(startForensicTime, 50);
                        console.log(`🛡️ SDK Security: Blocco [ CORPO ] per ${finalContentType}.\n DNA 🧬: Vettore Malevolo Rilevato -> ${pattern}\n 📄🚨 Il [ PDF ] e Rigettato d'ufficio !`);
                        if (headerBuffer) new Uint8Array(headerBuffer).fill(0);
                        if (tailBuffer) new Uint8Array(tailBuffer).fill(0);
                        if (fullBuffer) new Uint8Array(fullBuffer).fill(0);
                        return result;
                    }
                }
            } catch (e) {
                await this.injectTimingNoise(startForensicTime, 50);
                if (headerBuffer) new Uint8Array(headerBuffer).fill(0);
                if (tailBuffer) new Uint8Array(tailBuffer).fill(0);
                if (fullBuffer) new Uint8Array(fullBuffer).fill(0);
                return result;
            }
        }

        try {
            if (signal?.aborted) {
                if (headerBuffer) new Uint8Array(headerBuffer).fill(0);
                if (tailBuffer) new Uint8Array(tailBuffer).fill(0);
                if (fullBuffer) new Uint8Array(fullBuffer).fill(0);
                return result;
            }
            await blob.slice(-5).arrayBuffer();
        } catch (e) {
            await this.injectTimingNoise(startForensicTime, 50);
            if (headerBuffer) new Uint8Array(headerBuffer).fill(0);
            if (tailBuffer) new Uint8Array(tailBuffer).fill(0);
            if (fullBuffer) new Uint8Array(fullBuffer).fill(0);
            return result;
        }

        // 🧼 BONIFICA DELLA RAM
        if (headerBuffer) new Uint8Array(headerBuffer).fill(0);
        if (tailBuffer) new Uint8Array(tailBuffer).fill(0);
        if (fullBuffer) new Uint8Array(fullBuffer).fill(0);

        result.valid = true;
        result.blob = blob;
        Object.freeze(result);
        return result;
    }

    /**
     * 🧲 SONDA TECNICA HEAD
     */
    async performProbe(url, rules) {
        if (!rules || rules.useHeadProbe === false) {
            return { ok: true, size: 0, type: '' };
        }

        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 2500);
        try {
            const probe = await fetch(url, {
                method: 'HEAD',
                cache: 'no-cache',
                mode: 'cors',
                signal: this.syncAbortController ?
                        AbortSignal.any([this.syncAbortController.signal, controller.signal]) :
                        controller.signal
            });
            clearTimeout(timeoutId);
            if (probe.ok && probe.status === 200) {
                const contentLength = probe.headers.get('Content-Length');
                const contentType = (probe.headers.get('Content-Type') || '').toLowerCase();
                const size = contentLength ? parseInt(contentLength, 10) : -1;
                return { ok: true, size, type: contentType };
            }
        } catch (e) {
            if (e.name === 'AbortError') {
                console.info(`🧲⚠️ SDK: Sonda HEAD in timeout per ${url}. Procedo con download.`);
            } else {
                console.info(`🧲❌ SDK: Sonda HEAD fallita (CORS o Rete) per ${url}.`);
            }
        } finally {
            clearTimeout(timeoutId);
        }

        return {
            ok: this.CONFIG.minSizeMap.universal?.fallbackToGet ?? true,
            size: 0,
            type: ''
        };
    }

    /**
     * 🔗 FLUSSI: Normalizzatore Strict degli URI Telematici.
     */
    normalize(url) {
        if (!url || typeof url !== 'string' || url.startsWith('data:')) return url;
        try {
            const origin = (typeof window !== 'undefined' && window.location.origin) ||
                           (typeof self !== 'undefined' && self.location && self.location.origin) ||
                           'http://localhost';
            const baseSafe = new URL(this.CONFIG.ROOT, origin).href;
            const resolved = new URL(url, baseSafe);
            let cleanPath = resolved.pathname.replace(/\/+/g, '/');
            const rootNormalized = this.CONFIG.ROOT.replace(/\/+/g, '/');
            if (cleanPath === rootNormalized || cleanPath === rootNormalized + '/') {
                const mainEntry = this.CONFIG.coreAssets.find(asset => asset.toLowerCase().includes('.html'));
                cleanPath = this.normalize(mainEntry);
            }
            return cleanPath;
        } catch (e) {
            return url.split('?')[0].replace(/\/+/g, '/');
        }
    }

    /**
     * 📥🚀 Smart Download Differito con Profilazione Dinamica.
     */
    async smartDownload(url, cache, isCore = false, version = '', probeSize = 0) {
        const startNetworkTime = performance.now();
        const cleanKey = this.normalize(url);
        let isEncrypted = false;
        const isVaultReady = await this.verifyVaultIntegrity();
        if (!isVaultReady || !this.encryptionKey) {
            throw new Error("VAULT_LOCKED_NO_KEY");
        }
        const existing = await cache.match(cleanKey);
        if (existing) {
            const cachedVersion = existing.headers.get('X-PWA-Version');
            isEncrypted = existing.headers.get('X-PWA-Encrypted') === 'true';

            if (!isCore) {
                try {
                    const blob = await existing.blob();
                    if (await this.isValidBlob(blob, existing.headers.get('Content-Type'), 0, isEncrypted, this.syncAbortController?.signal)) {
                        return "ALREADY_OK";
                    }
                } catch (e) {
                    await this.injectTimingNoise(startNetworkTime, 50);
                }
            }

            if (isCore) {
                if (version && cachedVersion === version.toString()) {
                    return "ALREADY_OK";
                }
                try {
                    const nav = (typeof navigator !== 'undefined') ? navigator : self.navigator;
                    const profile = this.getNetworkProfile(nav);
                    const dynamicTimeout = (profile.timeout * 1000);
                    const controller = new AbortController();
                    const timeoutId = setTimeout(() => controller.abort(), dynamicTimeout);
                    const fetchSignal = this.syncAbortController
                        ? AbortSignal.any([this.syncAbortController?.signal, controller?.signal])
                        : controller?.signal;
                    const head = await fetch(url, {
                        method: 'HEAD',
                        cache: 'no-store',
                        headers: { 'Cache-Control': 'no-cache' },
                        mode: 'cors',
                        signal: fetchSignal
                    });
                    const serverLastMod = head.headers.get('Last-Modified');
                    const localLastMod = existing.headers.get('X-PWA-LastMod');
                    if (serverLastMod && localLastMod && serverLastMod === localLastMod) {
                        return "ALREADY_OK";
                    }
                } catch (e) {
                    await this.injectTimingNoise(startNetworkTime, 50);
                    return "ALREADY_OK";
                }
            }
            await cache.delete(cleanKey);
        }

        const ext = url.split('.').pop().toLowerCase();
        const rules = this.CONFIG.minSizeMap[ext] ||
                      (this.CONFIG.extensions.includes(ext) ? this.CONFIG.minSizeMap[ext === 'pdf' ? 'pdf' : 'image'] : null) ||
                      this.CONFIG.minSizeMap.universal;
        if (rules) Object.freeze(rules);

        let finalProbeSize = probeSize;
        if (finalProbeSize === 0) {
            const probeResult = await this.performProbe(url, rules);
            if (!probeResult.ok && !rules.fallbackToGet) return false;
            finalProbeSize = probeResult.size;
        }

        const tryDL = async (targetUrl, useRetries = true, currentProbeSize = 0) => {
            const { maxRetries, timeWaitSec } = this.CONFIG.networkResilient;
            const attempts = useRetries ? maxRetries : 0;
            const nav = (typeof navigator !== 'undefined') ? navigator : self.navigator;
            const profile = this.getNetworkProfile(nav);
            for (let attempt = 0; attempt <= attempts; attempt++) {
                if (this.syncAbortController?.signal.aborted) return false;
                const dynamicTimeout = (profile.timeout * 1000);
                const controller = new AbortController();
                const timeoutId = setTimeout(() => controller.abort(), dynamicTimeout);

                const fetchSignal = this.syncAbortController
                    ? AbortSignal.any([this.syncAbortController?.signal, controller?.signal])
                    : controller?.signal;
                try {
                    if (attempt > 0) await this.sleep(timeWaitSec * 1000);
                    const fetchUrl = targetUrl.includes('?') ? `${targetUrl}&cb=${Date.now()}` : `${targetUrl}?cb=${Date.now()}`;

                    const r = await fetch(fetchUrl, {
                        cache: 'no-store',
                        headers: { 'Cache-Control': 'no-cache' },
                        mode: 'cors',
                        signal: fetchSignal
                    });
                    clearTimeout(timeoutId);
                    if (r.ok || r.status === 304) {
                        try {
                            const contentType = r.headers.get('Content-Type') || '';
                            const expectedSize = parseInt(r.headers.get('Content-Length') || (currentProbeSize > 0 ? currentProbeSize : 0), 10);

                            const check = await this.isValidBlob(r, contentType, expectedSize, isEncrypted, fetchSignal);
                            if (!check.valid) {
                                try {
                                    const badBlob = check.blob || (r.clone ? await r.clone().blob() : null);
                                    if (badBlob) {
                                        const badBuffer = await badBlob.arrayBuffer();
                                        new Uint8Array(badBuffer).fill(0);
                                    }
                                } catch (clearErr) {
                                    await this.injectTimingNoise(startNetworkTime, 50);
                                    console.warn("🔬⚠️ SDK Forensic: Errore durante la bonifica d'emergenza 🧼🚨", clearErr);
                                }
                                const cleanError = new Error(`Integrità/DNA Fallito per ${targetUrl}`);
                                Object.defineProperty(cleanError, 'stack', { value: undefined, configurable: false, writable: false });
                                Object.freeze(cleanError);
                                throw cleanError;
                            }

                            let finalBlob = check.blob;
                            const newHeaders = new Headers(r.headers);
                            if (version) newHeaders.set('X-PWA-Version', version.toString());
                            newHeaders.set('X-PWA-Date', Date.now().toString());
                            const lastMod = r.headers.get('Last-Modified');
                            if (lastMod) newHeaders.set('X-PWA-LastMod', lastMod);

                            if (this.encryptionKey) {
                                finalBlob = await this.encryptBlob(finalBlob);
                                newHeaders.set('X-PWA-Encrypted', 'true');
                            }

                            let bufferToClear = (finalBlob instanceof Uint8Array) ? finalBlob : null;

                            try {
                                await cache.put(cleanKey, new Response(finalBlob, { status: 200, headers: newHeaders }));
                                console.info(`📦🛡️ SDK: Risorsa validata e salvata: ${targetUrl}`);
                            } catch (cacheError) {
                                if (await this.QuotaExceeded_User_Assets(cacheError) !== false) {
                                    try {
                                        await cache.put(cleanKey, new Response(finalBlob, { status: 200, headers: newHeaders }));
                                        console.info(`📦🛡️ SDK: Risorsa salvata con successo dopo 🧹 pulizia: ${targetUrl}`);
                                    } catch (retryError) {
                                        await this.injectTimingNoise(startNetworkTime, 50);
                                        const cleanRetryErr = {};
                                        Object.defineProperties(cleanRetryErr, {
                                            name: { value: "FatalCacheStorageError", enumerable: true },
                                            message: { value: "Saturazione persistente o violazione del perimetro di archiviazione", enumerable: true },
                                            stack: { value: undefined, configurable: false, writable: false, enumerable: false }
                                        });
                                        Object.freeze(cleanRetryErr);
                                        console.error("🧹❌ SDK: Fallimento critico anche dopo pulizia:", cleanRetryErr);
                                        throw cleanRetryErr;
                                    }
                                } else {
                                    await this.injectTimingNoise(startNetworkTime, 50);
                                    throw cacheError;
                                }
                            } finally {
                                if (bufferToClear) {
                                    bufferToClear.fill(0);
                                    await this.injectTimingNoise(startNetworkTime, 50);
                                    console.log(`🛡🧹️ SDK: Bonifica RAM eseguita per: ${targetUrl}`);
                                }
                            }

                            const uCache = await caches.open(this.CONFIG.userCacheName);
                            await uCache.delete(cleanKey);

                            return "DOWNLOADED";
                        } catch (e) {
                            await this.injectTimingNoise(startNetworkTime, 50);
                            console.info(`🔍⚠️ SDK: Scarto tecnico su ${targetUrl} -> ${e.message}`);
                            return false;
                        }
                    }
                    if (r.status === 404) break;
                } catch (e) {
                    await this.injectTimingNoise(startNetworkTime, 50);
                    clearTimeout(timeoutId);

                    if (!(await this.checkRealOnline('sync'))) {
                        throw new Error("PWA_Offline");
                    }
                }
            }
            return false;
        };

        Object.freeze(tryDL);

        const res = await tryDL(url, true, finalProbeSize);
        if (res === "DOWNLOADED") return "DOWNLOADED";
        if (res === "ALREADY_OK") return "ALREADY_OK";

        if (res === false) {
            const dotIdx = url.lastIndexOf('.');
            if (dotIdx !== -1) {
                const basePath = url.substring(0, dotIdx);
                for (let variantExt of this.CONFIG.extensions) {
                    if (this.syncAbortController?.signal.aborted) return false;
                    const alt = basePath + '.' + variantExt;
                    if (alt !== url) {
                        const altRes = await tryDL(alt, false, 0);
                        if (altRes === "DOWNLOADED") return "variant_new";
                    }
                }
            }
        }
        return false;
    }

    /**
     * 📡 Calcolo empirico del profilo del canale.
     */
    getNetworkProfile(nav) {
        const navigatorObj = nav || (typeof navigator !== 'undefined' ? navigator : self.navigator);
        const profiles = this.CONFIG.networkResilient.profiles;
        if (!navigatorObj || !navigatorObj.connection) return profiles['Medium'];
        const conn = navigatorObj.connection;
        const downlink = parseFloat(conn.downlink || 0);
        const eff = String(conn.effectiveType || '').toLowerCase();
        let score = 0;
        let status = '';

        if (downlink >= 15)       score += 70;
        else if (downlink >= 5)   score += 50;
        else if (downlink >= 1.5) score += 30;
        else if (downlink >= 0.4) score += 20;
        else if (downlink >= 0.2) score += 10;

        if (eff.includes('4g'))      score += 20;
        else if (eff.includes('3g')) score += 10;
        else if (eff.includes('2g')) score += 5;

        if (score >= 80)      status = 'Ultrafast';
        else if (score >= 55) status = 'Fast';
        else if (score >= 35) status = 'Medium';
        else if (score >= 20) status = 'Low';
        else                  status = 'Verylow';

        if (downlink >= 0.20 && downlink < 0.4) status = 'Low';
        if (downlink > 0 && downlink < 0.20)    status = 'Verylow';
        if (!navigatorObj.onLine) status = 'Verylow';

        return profiles[status] || profiles['Medium'];
    }

    /**
     * 🔀 VERIFICA CONNETTIVITÀ: Controllo di soglia reale (Anti-Lie-Fi).
     */
    async checkRealOnline(mode = 'fetch') {
        const nav = (typeof navigator !== 'undefined') ? navigator : self.navigator;
        const netProfile = this.getNetworkProfile(nav);
        const profiles = this.CONFIG.networkResilient.profiles;
        const profileName = Object.keys(profiles).find(key =>
            profiles[key].limit === netProfile.limit &&
            profiles[key].timeout === netProfile.timeout
        ) || 'Medium';

        let timeoutMs = 3000;
        if (mode === 'sync') {
            if (nav && nav.connection && nav.connection.saveData) return false;
            timeoutMs = Math.min(netProfile.timeout * 1000, 15000);
        } else {
            timeoutMs = (profileName === 'Fast' || profileName === 'Ultrafast') ? 2500 : 5500;
        }

        try {
            const controller = new AbortController();
            const tId = setTimeout(() => controller.abort(), timeoutMs);
            const networkResponse = await fetch(this.CONFIG.ROOT + '?t=' + Date.now(), {
                method: 'HEAD',
                cache: 'no-store',
                mode: 'no-cors',
                signal: this.syncAbortController ?
                        AbortSignal.any([this.syncAbortController?.signal, controller?.signal]) :
                        controller?.signal
            });
            clearTimeout(tId);
            return true;
        } catch (e) {
            console.log(`🌐❌ SDK: Offline in ${mode} (Profilo: ${profileName})`);
            return false;
        }
    }

    /**
     * 📡 REGISTRO DI CANALE / INIZIALIZZAZIONE SINCRONIZZAZIONE (INIT_DB)
     */
    async initDB(eventDataSnapshot, broadcastCallback = () => {}) {
        if (this.isSyncing) {
            if (this.syncAbortController) {
                this.syncAbortController.abort();
                console.info("🚫⚠️ PWA SDK: Abort old Process...");
            }
            this.isSyncing = false;
        }

        const localController = new AbortController();
        const combinedSignal = this.globalAbortController?.signal
            ? AbortSignal.any([this.globalAbortController.signal, localController.signal])
            : localController.signal;
        this.syncAbortController = {
            signal: combinedSignal,
            abort: () => localController.abort()
        };

        this.isSyncing = true;
        const currentVersion = eventDataSnapshot?.version;
        this.isLogicEnabled = true;

        const startNetworkTime = performance.now();
        let hasActuallyChanged = false;
        let realServerVersion = currentVersion;

        const broadcast = broadcastCallback;

        let uniqueList = [];
        let List_File_Download = null;
        let completed = 0;
        let completed_ok = 0;
        let failed = 0;
        let rfailed = 0;
        let variantsFound = 0;

        const nav = (typeof navigator !== 'undefined') ? navigator : self.navigator;
        const netProfile = this.getNetworkProfile(nav);
        const isCriticalLow = (netProfile.limit === this.CONFIG.networkResilient.profiles['Verylow'].limit);

        broadcast({ type: 'SYNC_START' });

        try {
            if ((!await this.checkRealOnline('sync')) || isCriticalLow) {
                console.log("📡❌ SDK: Rete assente al decollo. Abort !");
                if (this.syncAbortController) this.syncAbortController.abort();
                this.isSyncing = false;
                broadcast({ type: 'SYNC_RETRY' });
                return;
            }

            const cache = await caches.open(this.CONFIG.cacheName);
            const cacheKeys = await cache.keys();
            const isCacheEmpty = cacheKeys.length === 0;

            let IsCFUD = false;
            const mainEntry = this.CONFIG.coreAssets.find(a => a.toLowerCase().includes('.html'));
            if (mainEntry && !this.isNewInstallation && !isCacheEmpty) {
                try {
                    const radarRes = await fetch(mainEntry + '?t=' + Date.now(), {
                        cache: 'no-store',
                        signal: this.syncAbortController?.signal
                    });
                    if (radarRes.ok && radarRes.status === 200) {
                        const radarText = await radarRes.text();
                        const match = radarText.match(/ver_site\s*:\s*['"]([^'"]+)['"]/i);
                        const serverV = match ? match[1] : null;
                        if (serverV && serverV !== currentVersion) {
                            const vServer = serverV.split('.');
                            const vLocal = currentVersion.split('.');

                            if (vServer[0] !== vLocal[0] || vServer[1] !== vLocal[1]) {
                                console.info(`💥 SDK Radar: Rilevato Major Update (${currentVersion} -> ${serverV}). Tabula Rasa Core File !`);
                                await this.CoreAssets_Destroy_Caches(serverV, broadcast);
                                return;
                            }

                            console.info(`⚙️🎯 SDK Radar: Patch rilevata (${serverV})`);
                            realServerVersion = serverV;
                            IsCFUD = true;
                            hasActuallyChanged = true;
                        }
                    }
                } catch (e) {
                    const cleanManifestErr = {};
                    Object.defineProperties(cleanManifestErr, {
                        name: { value: "CoreFileError", enumerable: true },
                        message: { value: "Procedura di sincronizzazione degradata a standard", enumerable: true },
                        stack: { value: undefined, configurable: false, writable: false, enumerable: false }
                    });
                    Object.freeze(cleanManifestErr);
                    console.warn("⚠️ SDK: Fallimento..., procedo con Sync standard.", cleanManifestErr);
                }
            }

            console.info(`⚙️📥 SDK: Avvio download file core...`);
            broadcast({ type: 'SYNC_PROGRESS' });
            const coreResults = [];
            let coreLimit = this.getNetworkProfile(nav).limit;
            for (let i = 0; i < this.CONFIG.coreAssets.length; i += coreLimit) {
                if (this.syncAbortController?.signal.aborted) {
                    throw new Error("SYNC_ABORTED_DURING_CORE");
                }
                coreLimit = this.getNetworkProfile(nav).limit;
                const coreChunk = this.CONFIG.coreAssets.slice(i, i + coreLimit);
                const chunkPromises = coreChunk.map(url => this.smartDownload(url, cache, true, realServerVersion));
                let coreAbortListener;
                const coreAbortPromise = new Promise((_, reject) => {
                    if (this.syncAbortController?.signal.aborted) {
                        reject(new Error("SYNC_ABORTED_DURING_CORE"));
                        return;
                    }
                    coreAbortListener = () => reject(new Error("SYNC_ABORTED_DURING_CORE"));
                    this.syncAbortController?.signal.addEventListener('abort', coreAbortListener);
                });
                let chunkResults;
                try {
                    chunkResults = await Promise.race([
                        Promise.allSettled(chunkPromises),
                        coreAbortPromise
                    ]);
                    if (coreAbortListener) this.syncAbortController?.signal.removeEventListener('abort', coreAbortListener);
                } catch (coreRaceError) {
                    if (coreAbortListener) this.syncAbortController?.signal.removeEventListener('abort', coreAbortListener);
                    throw coreRaceError;
                }
                coreResults.push(...chunkResults);
                if (IsCFUD) {
                    chunkResults.forEach((res, index) => {
                        const url = coreChunk[index];
                        const isDownloaded = res.status === 'fulfilled' && res.value === "DOWNLOADED";
                        if (isDownloaded) {
                            console.info(`⚙️ SDK: asset core scaricato: ${url}`);
                        }
                    });
                }
                await this.waitTillIdle(200);
            }
            const core_Down_OK = coreResults.filter(r => r.status === 'fulfilled' && r.value === "DOWNLOADED").length;
            console.info(`✅⚙️ SDK: Core File Scaricati effettivi da rete: ${core_Down_OK}/${coreResults.length}`);

            console.info(`⚙️📜 SDK: Avvio Raccolta Lista File dal Manifest...`);
            const manifestList = [];
            if ((!await this.checkRealOnline('sync')) || isCriticalLow) {
                console.log("📡❌ SDK Stop: Rete persa durante il 🔄 sync.");
                if (this.syncAbortController) this.syncAbortController.abort();
                this.isSyncing = false;
                broadcast({ type: 'SYNC_RETRY' });
                return;
            }

            try {
                const manifestRes = await fetch(this.CONFIG.manifestPath, {
                    cache: 'no-cache',
                    signal: this.syncAbortController?.signal
                });
                if (!manifestRes || !manifestRes.ok || manifestRes.status !== 200) {
                    throw new Error(`MANIFEST_SERVER_ERROR_STATUS_${manifestRes?.status}`);
                }
                broadcast({ type: 'SYNC_PROGRESS' });
                let structured;
                try {
                    structured = await manifestRes.json();
                } catch (jsonErr) {
                    throw new Error("MANIFEST_JSON_CORRUPTED");
                }
                if (Array.isArray(structured)) {
                    structured.forEach(group => {
                        const directory = group.dir || "";
                        if (group.files && Array.isArray(group.files)) {
                            group.files.forEach(f => {
                                const fullPath = this.normalize(this.CONFIG.ROOT + directory + f);
                                manifestList.push(fullPath);
                            });
                        }
                    });
                }
                console.info(`✅📜 SDK: Lista completata. File raccolti dal manifest: ${manifestList.length}`);
            } catch (e) {
                console.error("🚫⚠️ SDK: Errore Critico durante l'elaborazione dell'Assets Manifest:", e.message);
                throw new Error("ASSETS_MANIFEST_CORRUPTED");
            }

            const db = eventDataSnapshot?.data;
            const scanSet = new Set();
            const knownDirs = new Set(Object.values(this.CONFIG.mappingLogic.contexts).map(c => c.path));

            /**
             * 🧠🧬 Universal Object Scanner Deep Validation.
             */
            const universalScanner = async (obj, currentCtx = 'base', parentKey = '', depth = 0) => {
                if (!obj || typeof obj !== 'object' || depth > 12) return;
                if (this.syncAbortController?.signal.aborted) return;
                for (const [key, val] of Object.entries(obj)) {
                    if (this.syncAbortController?.signal.aborted) return;

                    if (typeof val === 'object' && val !== null) {
                        let nextCtx = currentCtx;
                        if (parentKey === 'pdf' && (key === 'it' || key === 'en')) nextCtx = `docs_${key}`;
                        else if (this.CONFIG.mappingLogic.contexts[key]) nextCtx = key;
                        await universalScanner(val, nextCtx, key, depth + 1);
                        continue;
                    }
                    if (typeof val === 'string') {
                        const trimmed = val.trim();
                        if (trimmed.length > 150 || (trimmed.split(' ').length - 1) > 2) {
                            continue;
                        }
                    }
                    const valStr = String(val).trim();
                    if (valStr.length < 2) continue;

                    const logic = this.CONFIG.mappingLogic.parentSpecials[parentKey] ||
                                  this.CONFIG.mappingLogic.contexts[currentCtx] ||
                                  this.CONFIG.mappingLogic.contexts['base'];
                    const isExplicitFile = this.CONFIG.syncRegex.test(valStr);
                    const isIdKey = this.CONFIG.mappingLogic.idKeys.includes(key.toLowerCase()) || /^[0-9]+$/.test(valStr);
                    if (isExplicitFile || isIdKey) {
                        let fileToProbe = valStr;
                        if (isIdKey && !isExplicitFile) {
                            fileToProbe = (logic.prefix || "") + valStr + (logic.ext || this.CONFIG.defaultExt);
                        }
                        const cleanDir = logic.path.replace(/^(\.\.\/|\.\/)+/, '');
                        const primaryUrl = this.normalize(this.CONFIG.ROOT + cleanDir + fileToProbe);

                        const targets = [primaryUrl];

                        if (isExplicitFile) {
                            knownDirs.forEach(d => {
                                targets.push(this.normalize(this.CONFIG.ROOT + d.replace(/^(\.\.\/|\.\/)+/, '') + valStr));
                            });
                        }
                        await Promise.all([...new Set(targets)].map(async (url) => {
                            if (scanSet.has(url) || manifestList.includes(url)) return;

                            try {
                                const timeoutSignal = AbortSignal.timeout(2500);
                                const combinedSignal = this.syncAbortController ?
                                    AbortSignal.any([this.syncAbortController.signal, timeoutSignal]) :
                                    timeoutSignal;
                                const probe = await fetch(url, {
                                    method: 'HEAD',
                                    cache: 'no-cache',
                                    signal: combinedSignal
                                });
                                if (probe.ok && probe.status === 200) {
                                    scanSet.add(url);
                                    console.info(`🎯🕵️‍♂️ SDK Scanner: Asset Agganciato -> ${url}`);

                                    if (logic.isSequential && /\d+/.test(fileToProbe)) {
                                        const nextUrl = url.replace(/\d+/, n => parseInt(n) + 1);
                                        if (!scanSet.has(nextUrl) && !manifestList.includes(nextUrl)) {
                                            const nextProbe = await fetch(nextUrl, {
                                                method: 'HEAD',
                                                cache: 'no-cache',
                                                signal: combinedSignal
                                            });
                                            if (nextProbe.ok && nextProbe.status === 200) scanSet.add(nextUrl);
                                        }
                                    }
                                }
                            } catch (e) {
                                await this.injectTimingNoise(startNetworkTime, 45);
                            }
                        }));
                    }
                }
            };

            Object.freeze(universalScanner);

            console.info("🧠🧬 SDK: Avvio Universal Scanner...");
            await universalScanner(db);
            console.info(`🎯🏁 SDK: Analisi terminata. Asset extra trovati: ${scanSet.size}`);

            const fullWorkSet = new Set([...manifestList, ...Array.from(scanSet)]);
            const coreNormalized = this.CONFIG.coreAssets.map(a => this.normalize(a));
            console.info(`⛓️ SDK: Unificazione completata. Risorse totali da elaborare: ${fullWorkSet.size}`);
            uniqueList = Array.from(fullWorkSet).filter(url => {
                const norm = this.normalize(url);
                if (coreNormalized.includes(norm) || norm === '/' || norm === this.CONFIG.ROOT) {
                    return false;
                }
                const ext = url.split('.').pop().toLowerCase();
                const isAllowed = this.CONFIG.extensions.includes(ext);
                if (!isAllowed) {
                    console.log(`📄⚠️ SDK: Estensione .${ext} non autorizzata, risorsa esclusa: ${url}`);
                }
                return isAllowed;
            });
            console.info(`🚜 SDK: Rastrellamento terminato. ${uniqueList.length} risorse pronte per la stiva (esclusi Core Assets).`);

            let limit = this.getNetworkProfile(nav).limit;
            List_File_Download = uniqueList.length;
            for (let i = 0; i < List_File_Download; i += limit) {
                if (this.syncAbortController?.signal.aborted) return;
                if (!(await this.checkRealOnline('sync'))) { this.isSyncing = false; return; }
                if ((!await this.checkRealOnline('sync')) || (limit === this.CONFIG.networkResilient.profiles['Verylow'].limit)) {
                    console.log("📡❌ SDK Stop: Rete persa o Verylow, durante il 🔄 sync.");
                    if (this.syncAbortController) this.syncAbortController.abort();
                    this.isSyncing = false;
                    broadcast({ type: 'SYNC_RETRY' });
                    return;
                }
                limit = this.getNetworkProfile(nav).limit;
                const group = uniqueList.slice(i, i + limit);

                console.info(`🗃️🚀 SDK: Sync 🗂️ [ ${Math.floor(i/limit) + 1} / ${Math.ceil(List_File_Download/limit)} ] (${group.length} 📄)`);

                let abortListener;
                const abortPromise = new Promise((_, reject) => {
                    if (this.syncAbortController?.signal.aborted) {
                        reject(new Error("SYNC_ABORTED_DURING_CHUNK"));
                        return;
                    }
                    abortListener = () => reject(new Error("SYNC_ABORTED_DURING_CHUNK"));
                    this.syncAbortController?.signal.addEventListener('abort', abortListener);
                });
                let results;
                try {
                    results = await Promise.race([
                        Promise.allSettled(group.map(url => this.smartDownload(url, cache, false, realServerVersion))),
                        abortPromise
                    ]);
                    if (abortListener) this.syncAbortController?.signal.removeEventListener('abort', abortListener);
                    await this.waitTillIdle(200);
                } catch (raceError) {
                    if (abortListener) this.syncAbortController?.signal.removeEventListener('abort', abortListener);
                    throw raceError;
                }
                results.forEach((res, index) => {
                    const url = group[index];
                    if (res.status === 'fulfilled') {
                        const val = res.value;
                        if (val === "DOWNLOADED" || val === "variant_new") {
                            completed++;
                            if (val.includes("variant")) variantsFound++;
                        } else if (val === "ALREADY_OK" || val === "variant" || val === true) {
                            console.info(`📄✅ SDK: Già aggiornato: ${url}`);
                            completed_ok++;
                        } else if (val === false) {
                            console.info(`📄❌ SDK: Fallimento validazione/download su: ${url}`);
                            failed++;
                            completed++;
                        }
                    } else {
                        console.info(`📄⚠️ SDK: Errore critico nel processo per: ${url}`, res.reason);
                        if (res.reason && (res.reason.message.includes('VAULT'))) {
                            throw res.reason;
                        }
                        rfailed++;
                        completed++;
                    }
                });

                if (completed > 0) {
                    broadcast({
                        type: 'SYNC_PROGRESS',
                        details: {
                            percent: Math.floor((completed / List_File_Download) * 100),
                            current: completed,
                            total: uniqueList.length,
                            request_failed: rfailed,
                            failed_assets: failed
                        }
                    });
                }
            }

            if (this.syncAbortController?.signal.aborted) return;
            const expectedPaths = new Set([...coreNormalized, this.normalize(this.CONFIG.ROOT), ...uniqueList]);
            const allCachedRequests = await cache.keys();
            for (const request of allCachedRequests) {
                const cleanPathInCache = this.normalize(new URL(request.url).pathname);
                if (!expectedPaths.has(cleanPathInCache)) {
                    if (!cleanPathInCache.includes(this.CONFIG.manifestPath)) {
                        await cache.delete(request);
                    }
                }
            }
        } catch (err) {
            await this.injectTimingNoise(startNetworkTime, 50);
            if (this.syncAbortController) this.syncAbortController.abort();
            const errorMessage = err && typeof err === 'object' && 'message' in err ? String(err.message) : String(err);
            const isIntegritaError = errorMessage.includes('Integrità');

            const cleanError = {};
            Object.defineProperties(cleanError, {
                name: { value: "SyncError", enumerable: true },
                message: { value: isIntegritaError ? "Errore di Integrità rilevato su un asset" : "Errore operativo durante il Sync", enumerable: true },
                stack: { value: undefined, configurable: false, writable: false, enumerable: false }
            });
            Object.freeze(cleanError);

            if (isIntegritaError) {
                console.error("🚨 SDK: Errore di Integrità critico rilevato su un asset.", cleanError);
            } else {
                console.warn("🔄⚠️ SDK: Errore Sync", cleanError);
            }
        } finally {
            console.info(`✅ SDK: SYNC Completata. Total file Download: ${completed} - Exclud(IsBunker): ${completed_ok}`);
            this.isNewInstallation = false;
            this.isSyncing = false;
            if (this.syncAbortController?.signal.aborted) {
                this.syncAbortController = null;
                broadcast({ type: 'SYNC_RETRY' });
                return;
            }
            this.syncAbortController = null;
            await this.sleep(500);

            broadcast({
                type: 'SYNC_END',
                hasChanged: hasActuallyChanged,
                serverVersion: realServerVersion,
                details: {
                    total: (List_File_Download - completed_ok),
                    completed: completed,
                    failed: failed,
                    request_failed: rfailed,
                    FileVarExt: variantsFound
                }
            });
        }
    }

    /**
     * 🚦👮‍♂️ Regolatore di Flusso Polimorfo.
     */
    assegnaFlussoPolimorfo(hasCache, nav) {
        const navigatorObj = nav || (typeof navigator !== 'undefined' ? navigator : self.navigator);
        const netProfile = this.getNetworkProfile(navigatorObj);
        const profiles = this.CONFIG?.networkResilient?.profiles;
        const profileName = Object.keys(profiles).find(key =>
            profiles[key].limit === netProfile.limit &&
            profiles[key].timeout === netProfile.timeout
        ) || 'Medium';

        switch (profileName) {
            case 'Ultrafast':
            case 'Fast':
                return 'NetworkFirst';
            case 'Medium':
                return hasCache ? 'SWR' : 'NetworkFirst';
            case 'Low':
            case 'Verylow':
            default:
                if (hasCache) {
                    console.info(`🌐👮‍♂️ SDK: Rete Degradata, [ ${profileName} ].\n SWR(Sate-While-Revlidate), ON per continuità operativa...`);
                    return 'SWR';
                }
                return 'NetworkFirst';
        }
    }

    /**
     * 🚦 SMITIZZAZIONE E INTERCETTAZIONE: Fetch Handler SDK.
     */
    async handleFetch(request) {
        if (request.method !== 'GET' || !request.url.startsWith('http')) return fetch(request);
        const url = new URL(request.url);
        const origin = (typeof window !== 'undefined' && window.location.origin) ||
                       (typeof self !== 'undefined' && self.location && self.location.origin);

        if (origin && url.origin !== origin) return fetch(request);
        const cleanPath = this.normalize(url.pathname);
        const startFetchTime = performance.now();
        let finalPath = cleanPath;

        if (finalPath === this.normalize(this.CONFIG.ROOT) || finalPath.endsWith('/')) {
            const mainEntry = this.CONFIG.coreAssets.find(asset => asset.toLowerCase().includes('.html'));
            finalPath = this.normalize(mainEntry);
        }

        const mainCache = await caches.open(this.CONFIG.cacheName);
        const userCache = await caches.open(this.CONFIG.userCacheName);
        const existsInMain = await mainCache.match(finalPath, { ignoreSearch: true });
        const cached = existsInMain || await userCache.match(finalPath, { ignoreSearch: true });

        const isCoreAsset = this.CORE_ASSETS_SET.has(finalPath);
        const shouldBeEncrypted = isCoreAsset || existsInMain;
        const targetCache = shouldBeEncrypted ? "📦🛡️ (Bunker)" : "📦🔓 (Magazzino)";

        if (request.url.includes('favicon.ico')) {
            return new Response(null, { status: 204 });
        }

        const nav = (typeof navigator !== 'undefined') ? navigator : self.navigator;
        const finalStrategy = this.assegnaFlussoPolimorfo(cached, nav);
        const isOnline = await this.checkRealOnline('fetch');

        if (isOnline) {
            try {
                const currentProfile = this.getNetworkProfile(nav);
                const TIMEOUT_MS = currentProfile.timeout * 1000;
                const controller = new AbortController();
                const tId = setTimeout(() => controller.abort(), TIMEOUT_MS);
                const fetchSignal = this.globalAbortController
                    ? AbortSignal.any([this.globalAbortController?.signal, controller?.signal])
                    : controller?.signal;

                const networkResponse = await fetch(request, {
                    cache: 'no-cache',
                    signal: fetchSignal
                });
                clearTimeout(tId);

                if (networkResponse && networkResponse.ok && networkResponse.status === 200) {
                    if (!this.isLogicEnabled || this.isSyncing) {
                        return networkResponse;
                    }

                    const responseClone = networkResponse.clone();
                    (async () => {
                        try {
                            const isOk = await this.verifyVaultIntegrity();
                            if (!isOk || !this.encryptionKey) throw new Error("VAULT_LOCKED_NO_KEY");
                            if (!responseClone || !this.isLogicEnabled || this.isSyncing) return;

                            const contentType = responseClone.headers.get('Content-Type') || '';
                            const lastMod = responseClone.headers.get('Last-Modified');
                            const localLastMod = existsInMain ? existsInMain.headers.get('X-PWA-LastMod') : null;
                            const UserlocalLastMod = cached ? cached.headers.get('X-PWA-LastMod') : null;

                            if (lastMod && ((localLastMod && lastMod === localLastMod) || (UserlocalLastMod && lastMod === UserlocalLastMod))) {
                                return;
                            }

                            const check = await this.isValidBlob(responseClone, contentType, 0, false, controller.signal);
                            if (check.valid) {
                                let finalBlob = check.blob;
                                const updatedHeaders = new Headers(responseClone.headers);
                                updatedHeaders.set('X-PWA-Date', Date.now().toString());
                                if (lastMod) updatedHeaders.set('X-PWA-LastMod', lastMod);

                                console.info(`🔄💾 SDK: [ ${targetCache} ], ♻️ File: ${finalPath}`);

                                if (shouldBeEncrypted) {
                                    finalBlob = await this.encryptBlob(finalBlob);
                                    updatedHeaders.set('X-PWA-Encrypted', 'true');
                                }

                                const targetCacheObj = shouldBeEncrypted ? mainCache : userCache;
                                let bufferToClear = (finalBlob instanceof Uint8Array) ? finalBlob : null;

                                try {
                                    await targetCacheObj.put(finalPath, new Response(finalBlob, {
                                        status: responseClone.status,
                                        statusText: responseClone.statusText,
                                        headers: updatedHeaders
                                    }));
                                    console.info(`✅🔄💾 SDK: [ ${targetCache} ], Aggiornamento - File: ${finalPath}`);
                                } catch (cacheError) {
                                    const cleanCacheErr = {};
                                    Object.defineProperties(cleanCacheErr, {
                                        name: { value: "CacheWriteError", enumerable: true },
                                        message: { value: "Impossibile allocare la risorsa nel segmento isolato", enumerable: true },
                                        stack: { value: undefined, configurable: false, writable: false, enumerable: false }
                                    });
                                    Object.freeze(cleanCacheErr);
                                    console.error(`💥⚠️ SDK: Fallimento scrittura in ${targetCache} - File: ${finalPath}`, cleanCacheErr);
                                    if (await this.QuotaExceeded_User_Assets(cacheError) !== false) {
                                        try {
                                            await targetCacheObj.put(finalPath, new Response(finalBlob, {
                                                status: responseClone.status,
                                                statusText: responseClone.statusText,
                                                headers: updatedHeaders
                                            }));
                                            console.info(`✅🔄💾 SDK: [ ${targetCache} ], Salvataggio riuscito dopo pulizia: ${finalPath}`);
                                        } catch (retryError) {
                                            const cleanRetryErr = {};
                                            Object.defineProperties(cleanRetryErr, {
                                                name: { value: "FatalCacheStorageError", enumerable: true },
                                                message: { value: "Saturazione persistente o violazione del perimetro di archiviazione", enumerable: true },
                                                stack: { value: undefined, configurable: false, writable: false, enumerable: false }
                                            });
                                            Object.freeze(cleanRetryErr);
                                            console.error("🧹❌ SDK: Fallimento critico anche dopo pulizia:", cleanRetryErr);
                                            throw cleanRetryErr;
                                        }
                                    } else {
                                        console.warn("📦⚠️ SDK: Update cache fallito:", cleanCacheErr);
                                        throw cleanCacheErr;
                                    }
                                } finally {
                                    if (bufferToClear) {
                                        bufferToClear.fill(0);
                                        console.log(`🛡️🧹 SDK: Bonifica RAM eseguita per: ${finalPath}`);
                                    }
                                }
                            } else {
                                throw new Error(`Integrità/DNA Fallito per ${finalPath}`);
                            }
                        } catch (err) {
                            if (typeof this.injectTimingNoise === 'function') await this.injectTimingNoise(startFetchTime, 30);
                            const cleanErr = {};
                            Object.defineProperties(cleanErr, {
                                name: { value: "ForensicValidationError", enumerable: true },
                                message: { value: err && err.message ? String(err.message) : "Eccezione controllata nel modulo Fetch Vault", enumerable: true },
                                stack: { value: undefined, configurable: false, writable: false, enumerable: false }
                            });
                            Object.freeze(cleanErr);
                            console.error("💥💾 SDK: Errore fatale nel flusso di salvataggio in fetch: ", cleanErr);
                        }
                    })();

                    console.info(`⚡👮‍♂️ SDK: [ ${targetCache} ] | Strategia Esecutiva: [ ${finalStrategy} ] \n 🌐 Rete: status [ 200 OK ] | Azione: ${(finalStrategy === 'SWR' && cached) ? 'Erogazione da Cache 📦 + Update differito in Background ♻️🔄' : 'Erogazione da Rete WEB 🌐'}. Risorsa: ${finalPath}`);
                    if (!(finalStrategy === 'SWR' && cached)) {
                        return networkResponse;
                    }
                }
                if (networkResponse && networkResponse.status === 404) {
                    if (cached) {
                        console.info("📦♻️ SDK: 404 Online, Resilienza ON: ", finalPath);
                    } else {
                        return networkResponse;
                    }
                }
            } catch (e) {
                if (typeof this.injectTimingNoise === 'function') await this.injectTimingNoise(startFetchTime, 25);
            }
        }

        if (cached) {
            if (cached.headers.get('X-PWA-Encrypted') === 'true') {
                try {
                    const isOk = await this.verifyVaultIntegrity();
                    if (!isOk || !this.encryptionKey) throw new Error("VAULT_LOCKED_NO_KEY");
                    const buffer = await cached.arrayBuffer();
                    let decrypted = await this.decryptBuffer(buffer);

                    const detectedContentType = cached.headers.get('Content-Type') || '';
                    const dotIdx = finalPath.lastIndexOf('.');
                    const ext = dotIdx !== -1 ? finalPath.substring(dotIdx + 1).toLowerCase() : '';

                    const secureHeaders = new Headers({
                        'Content-Type': detectedContentType,
                        'X-PWA-Source': 'Bunker-Decrypted',
                        'Cache-Control': 'no-store, no-cache, must-revalidate, max-age=0',
                        'Pragma': 'no-cache',
                        'Expires': '0'
                    });

                    if (ext && this.CONFIG.extExlPHr.includes(ext)) {
                        secureHeaders.set('Content-Disposition', `inline; filename="secure_document.${ext}"`);
                    }

                    const outResponse = new Response(decrypted, { headers: secureHeaders });
                    console.log(`🛡️🧹 SDK: Bonifica RAM eseguita per: ${finalPath}`);
                    new Uint8Array(buffer).fill(0);
                    if (decrypted instanceof ArrayBuffer) new Uint8Array(decrypted).fill(0);
                    decrypted = null;
                    console.info(`💾🛡️ SDK: Risorsa estratta dal, ${targetCache}`);
                    return outResponse;
                } catch (err) {
                    if (typeof this.injectTimingNoise === 'function') await this.injectTimingNoise(startFetchTime, 40);
                    if (typeof buffer !== 'undefined' && buffer instanceof ArrayBuffer) {
                        new Uint8Array(buffer).fill(0);
                    }
                    if (typeof decrypted !== 'undefined' && decrypted instanceof ArrayBuffer) {
                        new Uint8Array(decrypted).fill(0);
                    }
                    decrypted = null;

                    const cleanDecryptErr = {};
                    const isVaultError = err && err.message && err.message.includes('VAULT');
                    Object.defineProperties(cleanDecryptErr, {
                        name: { value: "CryptoShieldError", enumerable: true },
                        message: { value: isVaultError ? "VAULT_LOCKED_NO_KEY" : "Decryption integrity violation", enumerable: true },
                        stack: { value: undefined, configurable: false, writable: false, enumerable: false }
                    });
                    Object.freeze(cleanDecryptErr);
                    console.error("❌🔑 SDK: Decrittazione fallita per:", finalPath);
                    if (isVaultError) {
                        return new Response("⚠️🛡️Security Violation: 🗄️🚫 Vault Error...", { status: 403 });
                    } else {
                        const deletedMain = await mainCache.delete(finalPath, { ignoreSearch: true });
                        if (deletedMain) {
                            console.log(`⚠️🧹 SDK: Risorsa Corrotta nel (🛡️ Bunker), ✅ eliminata correttamente: ${finalPath}`);
                            return new Response(null, { status: 404, statusText: "Resource Corrupted & Deleted" });
                        }
                    }
                    throw cleanDecryptErr;
                }
            } else {
                console.info(`💾🛡️ SDK: Risorsa estratta dal, ${targetCache}`);
                return cached;
            }
        } else {
            const dotIdx = finalPath.lastIndexOf('.');
            if (dotIdx !== -1) {
                const basePath = finalPath.substring(0, dotIdx);
                for (let variantExt of this.CONFIG.extensions) {
                    const altPath = basePath + '.' + variantExt;
                    if (altPath === finalPath) continue;
                    const altCached = await mainCache.match(altPath, { ignoreSearch: true }) ||
                                      await userCache.match(altPath, { ignoreSearch: true });
                    if (altCached) {
                        const contentTypeIMG = altCached.headers.get('Content-Type') || '';
                        if (contentTypeIMG.includes('image/')) {
                            console.info(`🛸🎯 SDK Recovery: Trovata variante -> ${altPath}`);
                            try {
                                if (altCached.headers.get('X-PWA-Encrypted') === 'true') {
                                    const buffer = await altCached.clone().arrayBuffer();
                                    let decrypted = await this.decryptBuffer(buffer);

                                    const variantExtLower = variantExt.toLowerCase();
                                    const secureHeaders = new Headers({
                                        'Content-Type': contentTypeIMG,
                                        'X-PWA-Source': 'Bunker-Recovered-Decrypted',
                                        'X-PWA-Original-Path': altPath,
                                        'Cache-Control': 'no-store, no-cache, must-revalidate, max-age=0',
                                        'Pragma': 'no-cache',
                                        'Expires': '0'
                                    });

                                    if (this.CONFIG.extExlPHr.includes(variantExtLower)) {
                                        secureHeaders.set('Content-Disposition', `inline; filename="secure_document.${variantExtLower}"`);
                                    }

                                    const outResponse = new Response(decrypted, { headers: secureHeaders });
                                    new Uint8Array(buffer).fill(0);
                                    if (decrypted instanceof ArrayBuffer) new Uint8Array(decrypted).fill(0);
                                    decrypted = null;
                                    return outResponse;
                                }
                                return altCached.clone();
                            } catch (decryptErr) {
                                console.error(`❌🔑 SDK Recovery: Variante ${altPath} corrotta o non decifrabile.`);
                                continue;
                            }
                        }
                    }
                }
            }
        }

        const contentsType = request.headers.get('Accept') || "";
        const isHTML = contentsType.includes('text/html');
        const isExcluded = this.CONFIG.extExlPHr.some(ext => finalPath.toLowerCase().endsWith('.' + ext));
        const imageExtensions = this.CONFIG.extensions.filter(ext => !this.CONFIG.extExlPHr.includes(ext));
        const imgRegex = new RegExp(`\\.(${imageExtensions.join('|')})$`, 'i');
        const isImageRequest = (contentsType.includes('image/') && !isHTML) || imgRegex.test(finalPath);

        if (isImageRequest || isHTML) {
            const placeholderPath = this.normalize(this.CONFIG.defPlaceHolderLogo);
            const placeholder = await caches.match(placeholderPath);
            if (placeholder) {
                try {
                    if (this.globalPlaceholderBlob === null) {
                        if (placeholder.headers.get('X-PWA-Encrypted') === 'true') {
                            const buffer = await placeholder.arrayBuffer();
                            let decrypted = await this.decryptBuffer(buffer);
                            this.globalPlaceholderBlob = new Blob([decrypted], { type: placeholder.headers.get('Content-Type') });
                            decrypted = null;
                        } else {
                            this.globalPlaceholderBlob = await placeholder.blob();
                        }
                    }
                    if (isImageRequest && !isHTML && !isExcluded) {
                        console.info(`🖼️🩹 SDK Placeholder: Emergenza -> ${finalPath}`);
                        return new Response(this.globalPlaceholderBlob, {
                            headers: {
                                'Content-Type': placeholder.headers.get('Content-Type') || 'image/png',
                                'X-PWA-Source': 'Bunker-Placeholder'
                            }
                        });
                    }
                } catch (err) {
                    console.error("❌ SDK: Errore decriptazione placeholder:", err);
                }
            } else {
                if (isImageRequest && !isHTML && !isExcluded) {
                    console.info(`🖼️🩹❌ SDK Placeholder Fallback: Emergenza -> ${finalPath}`);
                    return new Response(this.GLOBAL_BROKEN_BLOB, {
                        headers: {
                            'Content-Type': 'image/svg+xml',
                            'X-PWA-Source': 'SW-Emergency-SVG'
                        }
                    });
                }
            }
        }

        if (!isImageRequest && isExcluded) {
            console.info("📦❌ SDK: Recupero fallito per:", finalPath);
        }
        if (isCoreAsset && !this.isNewInstallation) {
            console.log(`📡❌ SDK CORE: Rete off-line per risorsa critica -> ${finalPath}`);
            await this.CoreAssets_Destroy_Caches();
        }
        if (isHTML) {
            return await this.generateErrorPage(this.globalPlaceholderBlob, url.pathname);
        }

        return new Response('📡🚫 Offline', {
            status: 503,
            statusText: 'Service Unavailable',
            headers: { 'Content-Type': 'text/plain' }
        });
    }

    /**
     * 📥🏛️ INSTALLAZIONE SDK: Inizializzazione Core e Pre-Cache.
     */
    async install() {
        this.isNewInstallation = true;
        console.info("🛠️ SDK: Installazione in corso...");
        const key = await this.getStoredKey();
        if (key) {
            console.info("🔑️ SDK: Vault inizializzato durante l'installazione.");
        } else {
            console.info("⚠️ SDK: Vault fallito, verrà ritentato all'attivazione.");
        }
        await caches.open(this.CONFIG.cacheName);
        await caches.open(this.CONFIG.userCacheName);
    }

    /**
     * ⚡⚙️ ATTIVAZIONE SDK: Bonifica Archivi.
     */
    async activate() {
        console.info("⚡ SDK: attivazione...");
        const keys = await caches.keys();
        await Promise.all(
            keys.map(k => {
                if (k !== this.CONFIG.cacheName && k !== this.CONFIG.userCacheName) {
                    console.info(`🧹📦 SDK: Remove Old cache version: ${k}`);
                    return caches.delete(k);
                }
            })
        );

        try {
            this.encryptionKey = await this.getStoredKey();
            console.info("🗄️✅ SDK: Vault Unlock Ok.");
            console.info("🛡️🔍 SDK: Check di Sicurezza...");
            await this.deepVaultValidation();
            console.info("🛡️✅ SDK: Integrità Bunker confermata.");
            await this.cleanUserCache();
        } catch (err) {
            console.error("⚡🚨 SDK: Erorre: ", err.message);
        }
    }

    /**
     * 🚨💾 GESTIONE EMERGENZA STORAGE: Risoluzione errore di quota superata.
     */
    async QuotaExceeded_User_Assets(e) {
        if (e.name === 'QuotaExceededError') {
            console.log("🚨 SDK: Storage Pieno!\n Emergency !\n🧹 cleanUserCache !");
            try {
                await this.cleanUserCache(true);
                await this.waitTillIdle(500);
                return true;
            } catch (err) {
                console.error("🧹❌ SDK: Errore critico durante la pulizia della cache: ", err);
                return err;
            }
        } else {
            return false;
        }
    }

    /**
     * 🗑️ EVACUAZIONE E AGGIORNAMENTO: Purga mirata dei file d'infrastruttura critica.
     */
    async CoreAssets_Destroy_Caches(serverV = null, broadcastCallback = null) {
        const now = Date.now();
        if (now - this.lastReloadCommandTime < 20000) { return; }
        this.lastReloadCommandTime = now;
        try {
            const keys = await caches.keys();
            await Promise.all(keys.map(async (k) => {
                const cacheX = await caches.open(k);
                await Promise.all(Array.from(this.CORE_ASSETS_SET).map(asset => cacheX.delete(asset)));
            }));
            console.log("🗑️ SDK: Asset core Distrutti con successo...");
            if (broadcastCallback) {
                broadcastCallback({
                    type: 'CORE_UPDATE_RELOAD',
                    sSV: serverV,
                    timestamp: now
                });
            }
        } catch (err) {
            const cleanErr = {};
            Object.defineProperties(cleanErr, {
                name: { value: "CacheEvacuationError", enumerable: true },
                message: { value: "Fallimento procedura di emergenza evacuazione", enumerable: true },
                stack: { value: undefined, configurable: false, writable: false, enumerable: false }
            });
            Object.freeze(cleanErr);
            console.error("🚫 SDK: Fallimento Distruzione dei file [ ⚙️ CORE ] dalla cache.", cleanErr);
        }
    }

    /**
     * 💣🔥 PROCEDURA DISTRUTTIVA D'URGENZA: Tabula Rasa dei DATI.
     */
    async Destroy_ALL_Caches(err = null, broadcastCallback = null) {
        this.globalAbortController.abort();
        this.globalAbortController = new AbortController();
        console.error("💣 SDK: Errore critico rilevato, Avvio Distruzione Totale!", err);
        const keys = await caches.keys();
        await Promise.all(keys.map(k => caches.delete(k)));
        if (broadcastCallback) {
            broadcastCallback({ type: 'CORE_UPDATE_RELOAD', msg: 'DESTROY_ALL_CACHE', msg_err: err });
        }
    }

    /**
     * 🗄🐺️🐤 WATCHDOG DI SICUREZZA: Ispezione Forense dell'Integrità Crittografica.
     */
    async deepVaultValidation() {
        let db = null;
        try {
            let realKey = null;
            let isIOStable = false;
            const randomTimeoutMs = Math.random() * (600 - 250) + 250;

            const thermalShieldRace = (async () => {
                await this.waitTillIdle(200, Math.ceil(randomTimeoutMs));
                throw new Error("THERMAL_SHIELD_TIMEOUT");
            })();

            try {
                realKey = await Promise.race([
                    (async () => {
                        db = await new Promise((resolve, reject) => {
                            const req = indexedDB.open("PWA_Vault", 1);
                            req.onsuccess = () => resolve(req.result);
                            req.onerror = () => reject(new Error("VAULT_DB_ACCESS_ERROR"));
                        });
                        const resKey = await new Promise((resolve, reject) => {
                            const tx = db.transaction("keys", "readonly");
                            const req = tx.objectStore("keys").get("master_key");
                            req.onsuccess = () => resolve(req.result);
                            req.onerror = () => reject(new Error("VAULT_KEY_READ_ERROR"));
                        });
                        db.close();
                        db = null;
                        return resKey;
                    })(),
                    thermalShieldRace
                ]);

                isIOStable = true;
            } catch (raceErr) {
                if (raceErr.message === "THERMAL_SHIELD_TIMEOUT") {
                    console.warn("🌡️🛡️ SDK: ️ THERMAL SHIELD\n L'Event Loop 🔁 o 1️⃣/0️⃣ sono saturi.\n 🚧 Sbarramento adattivo ✅.");
                    isIOStable = false;
                } else {
                    if (db) { try { db.close(); } catch(e){} db = null; }
                    throw raceErr;
                }
            }

            if (!realKey) {
                if (isIOStable) {
                    console.error("🗄️🚨 SDK: CANALE REATTIVO MA CHIAVE ASSENTE!\n Rilevata rimozione dolosa dal disco. 💾");
                    throw new Error("VAULT_SECURITY_BREACH_INTEGRITY");
                } else {
                    throw new Error("VAULT_EMPTY_TEMPORARY");
                }
            }

            const canaryText = this.CONFIG.vaultCanaryText;
            const testKey = realKey;
            try {
                this.encryptionKey = testKey;
                const testBlob = new Blob([canaryText], { type: "text/plain" });
                const encryptedBlob = await this.encryptBlob(testBlob);
                const decryptedBuffer = await this.decryptBuffer(await encryptedBlob.arrayBuffer());
                const decryptedText = new TextDecoder().decode(decryptedBuffer);
                if (decryptedText !== canaryText) {
                    throw new Error("VAULT_SECURITY_BREACH_INTEGRITY");
                }
                this.encryptionKey = testKey;
            } catch (cryptoErr) {
                this.encryptionKey = null;
                throw new Error("VAULT_SECURITY_BREACH_INTEGRITY");
            }

        } catch (err) {
            if (db) {
                try {
                    db.close();
                } catch(e){
                    if (typeof this.injectTimingNoise === 'function') await this.injectTimingNoise(performance.now(), 35);
                }
            }
            if (err.message === "VAULT_SECURITY_BREACH_INTEGRITY") {
                console.error("🗄️🚨 SDK: INTEGRITÀ CRITTOGRAFICA FALLITA! - Avvio distruzione Dati...");
                try {
                    await this.Destroy_ALL_Caches("VAULT_COMPROMISED");
                    await new Promise((resolve) => {
                        const req = indexedDB.deleteDatabase("PWA_Vault");
                        req.onsuccess = () => resolve();
                        req.onerror = () => resolve();
                    });
                    console.log("🗄️🔥 SDK: Tabula rasa completata con successo.");
                } catch (purgErr) {
                    console.error("🗄️⚠️ SDK: Errore durante la purga del sistema:", purgErr);
                }
                this.encryptionKey = null;
                throw new Error("VAULT_COMPROMISED_AND_CLEANED");
            }
            console.error("🗄️⚠️ SDK: Accesso Vault -> (Security Violation)");
            throw new Error("VAULT_TEMPORARILY_LOCKED");
        }
    }

    /**
     * 🗄️⏳ VERIFICA: Controllo Temporizzato del Caveau.
     */
    async verifyVaultIntegrity() {
        const now = Date.now();
        if (this.encryptionKey !== null && (now - this.lastVaultCheck < this.CHECK_INTERVAL)) return true;
        if (this.isCanaryLock) {
            if (this.encryptionKey !== null) return true;
            const inizioInseguimento = Date.now();
            const TIMEOUT_GUARDIA_MS = 8000;
            while (this.isCanaryLock) {
                if (Date.now() - inizioInseguimento > TIMEOUT_GUARDIA_MS) {
                    console.log("🗄🐺️🚨 SDK: Timeout di guardia superato in coda di attesa!");
                    break;
                }
                await this.waitTillIdle(200, 2000);
            }
            return this.encryptionKey !== null;
        }
        this.isCanaryLock = true;
        try {
            await this.deepVaultValidation();
            this.lastVaultCheck = Date.now();
            this.isCanaryLock = false;
            return true;
        } catch (err) {
            this.isCanaryLock = false;
            console.warn("🗄🐺️⚠️ SDK: Validazione temporaneamente fallita: ", err.message);
            return false;
        }
    }

    /**
     * 🔑 GESTIONE STORAGE CHIAVI: Estrazione e Clonazione Strutturata.
     */
    async getStoredKey() {
        if (this.encryptionKey !== null) return this.encryptionKey;
        return new Promise(async (resolve) => {
            try {
                const dbs = indexedDB.databases ? await indexedDB.databases() : [];
                const vaultExists = dbs.some(db => db.name === "PWA_Vault");
                const request = indexedDB.open("PWA_Vault", 1);
                request.onupgradeneeded = (e) => {
                    const db = e.target.result;
                    if (!db.objectStoreNames.contains("keys")) {
                        db.createObjectStore("keys");
                    }
                };
                request.onsuccess = (e) => {
                    const db = e.target.result;
                    const transaction = db.transaction("keys", "readwrite");
                    const store = transaction.objectStore("keys");
                    const getReq = store.get("master_key");
                    getReq.onsuccess = async () => {
                        let key = getReq.result;
                        if (!key) {
                            if (vaultExists) {
                                console.error("⚠️💣 ANOMALIA CRITICA: Vault compromesso, chiave sparita!");
                                this.encryptionKey = null;
                                db.close();
                                resolve(null);
                                return;
                            }
                            console.info("🔑 SDK: Primo avvio, inizializzazione chiave...");
                            key = await crypto.subtle.generateKey(
                                { name: "AES-GCM", length: 256 },
                                false,
                                ["encrypt", "decrypt"]
                            );
                            store.put(key, "master_key");
                        }
                        this.encryptionKey = key;
                        transaction.oncomplete = () => db.close();
                        resolve(key);
                    };
                    getReq.onerror = async () => {
                        if (typeof this.injectTimingNoise === 'function') await this.injectTimingNoise(performance.now(), 40);
                        console.info("❌ SDK: Errore lettura store chiavi");
                        db.close();
                        resolve(null);
                    };
                };
                request.onerror = async (err) => {
                    if (typeof this.injectTimingNoise === 'function') await this.injectTimingNoise(performance.now(), 40);
                    console.info("❌ SDK: Errore apertura IndexedDB Vault");
                    resolve(null);
                };
            } catch (criticalErr) {
                if (typeof this.injectTimingNoise === 'function') await this.injectTimingNoise(performance.now(), 40);
                const cleanErr = {};
                Object.defineProperties(cleanErr, {
                    name: { value: "Vault-Critical-Error", enumerable: true },
                    message: { value: "Fallimento Critico Apertura del Vault", enumerable: true },
                    stack: { value: undefined, configurable: false, writable: false, enumerable: false }
                });
                Object.freeze(cleanErr);
                console.error("❌ SDK: Fallimento critico sistema Vault", cleanErr);
                this.encryptionKey = null;
                resolve(null);
            }
        });
    }

    /**
     * 🔐 ARCHITETTURA BUNKER: Cifratura asincrona dei flussi di memoria.
     */
    async encryptBlob(blob) {
        if (!this.encryptionKey) {
            throw new Error("CRYPTO_KEY_UNAVAILABLE_IN_RAM");
        }
        const iv = crypto.getRandomValues(new Uint8Array(12));
        let buffer = await blob.arrayBuffer();
        let ciphertext = null;
        let combined = null;
        try {
            ciphertext = await crypto.subtle.encrypt(
                { name: "AES-GCM", iv: iv },
                this.encryptionKey,
                buffer
            );
            new Uint8Array(buffer).fill(0);
            buffer = null;

            combined = new Uint8Array(iv.length + ciphertext.byteLength);
            combined.set(iv);
            combined.set(new Uint8Array(ciphertext), iv.length);

            const outBlob = new Blob([combined], { type: blob.type });

            combined.fill(0);
            combined = null;
            ciphertext = null;

            return outBlob;
        } catch (err) {
            console.error("❌🛡️ SDK: Errore durante la cifratura del file.");
            if (buffer instanceof ArrayBuffer) new Uint8Array(buffer).fill(0);
            if (combined instanceof Uint8Array) combined.fill(0);
            throw err;
        }
    }

    /**
     * 🔓 DISPOSITIVO DECRITTAZIONE: Ripristino Flussi protetti.
     */
    async decryptBuffer(buffer) {
        if (!this.encryptionKey) {
            throw new Error("CRYPTO_KEY_UNAVAILABLE_IN_RAM");
        }
        let data = new Uint8Array(buffer);
        try {
            const iv = data.subarray(0, 12);
            const ciphertext = data.subarray(12);

            const decrypted = await crypto.subtle.decrypt(
                { name: "AES-GCM", iv: iv },
                this.encryptionKey,
                ciphertext
            );
            data.fill(0);
            data = null;

            return decrypted;
        } catch (err) {
            console.error("❌🛡️ SDK: Fallimento decrittazione.\nDati non integri o chiave errata.");
            if (data) data.fill(0);
            throw new Error("VAULT_LOCKED_DECRYPTION", { cause: err });
        }
    }

    /**
     * 🧬 INTEGRITÀ FORENSE: Calcolo dell'Impronta Digitale (Checksum).
     */
    async getHash(blob, algo = 'SHA-256') {
        let buffer = null;
        let hashBuffer = null;
        try {
            buffer = await blob.arrayBuffer();
            hashBuffer = await crypto.subtle.digest(algo, buffer);

            new Uint8Array(buffer).fill(0);
            buffer = null;

            const hashArray = new Uint8Array(hashBuffer);
            const hashHex = Array.from(hashArray)
                .map(b => b.toString(16).padStart(2, '0'))
                .join('');

            return hashHex;
        } catch (err) {
            if (typeof this.injectTimingNoise === 'function') await this.injectTimingNoise(performance.now(), 35);
            const cleanHashErr = {};
            Object.defineProperties(cleanHashErr, {
                name: { value: "HashCalculationError", enumerable: true },
                message: { value: "Impossibile processare impronta digitale", enumerable: true },
                stack: { value: undefined, configurable: false, writable: false, enumerable: false }
            });
            Object.freeze(cleanHashErr);
            console.error("🧬❌ SDK: Errore calcolo Hash:", cleanHashErr);
            if (buffer instanceof ArrayBuffer) new Uint8Array(buffer).fill(0);
            return null;
        }
    }

    /**
     * 🧹 MANUTENZIONE ORDINARIA: Purga selettiva e monitoraggio dello spazio di archiviazione (TTL).
     */
    async cleanUserCache(forceAll = false) {
        const cache = await caches.open(this.CONFIG.userCacheName);
        const requests = await cache.keys();
        const now = Date.now();
        const maxAge = (this.CONFIG.userCacheTTL * 24 * 60 * 60 * 1000);
        for (const request of requests) {
            if (forceAll) {
                await cache.delete(request);
                continue;
            }

            const response = await cache.match(request);
            const date = response?.headers.get('X-PWA-Date');
            if (date && (now - parseInt(date, 10)) > maxAge) {
                console.info(`📜📦 SDK: TTL Scaduto, Del: ${request.url}`);
                await cache.delete(request);
            }
        }
        if (forceAll) {
            console.info("🧹 SDK: UserCache svuotata, recupera spazio critico.");
        }
    }

    /**
     * 🖥️🚨 INTERFACCIA DI CORTESIA: Generatore Statico Fallback Digitale (503).
     */
    async generateErrorPage(logoBlob, failedPath) {
        const svgNewLogo = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTAwIiBoZWlnaHQ9IjEwMCIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJub25lIiBzdHJva2U9IiNjYzAwMDAiIHN0cm9rZS13aWR0aD0iMiI+PHBhdGggZD0iTTEyIDJMMiAyMmgyMEwxMiAyeiIvPjxsaW5lIHgxPSIxMiIgeTE9IjEwIiB4Mj0iMTIiIHkyPSIxNiIvPjxjaXJjbGUgY3g9IjEyIiBjeT0iMTkiIHI9IjEiLz48L3N2Zz4=";
        const html = `<!DOCTYPE html><html lang="it"><head><meta charset="UTF-8"><title>503 Service Unavailable</title><style>body{font-family:sans-serif;text-align:center;padding:50px;background:#121212;color:#fff;}img{max-width:120px;margin-bottom:20px;}</style></head><body><img src="${svgNewLogo}" alt="Alert"/><h1>503 - Servizio Non Disponibile</h1><p>Risorsa non accessibile al momento: <code>${failedPath}</code></p></body></html>`;
        return new Response(html, {
            status: 503,
            headers: { 'Content-Type': 'text/html; charset=utf-8' }
        });
    }
}