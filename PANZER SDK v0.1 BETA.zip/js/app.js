/**
 * 💻 FRONTEND PORTALE COMUNALE (`app.js`)
 * 
 * ============================================================================
 * 🛡️ PANZER SDK v0.1 - BETA
 * ============================================================================
 * @file       app.js
 * @description Gestore principale del ciclo di vita dell'applicazione, integrazione
 *              dell'SDK Panzer, gestione della telemetria, reattività PWA e UI.
 * @author     Valentino Aglianò
 * @license    EUPL-1.2
 * ============================================================================
 */

import { PanzerSDK } from './panzer-sdk.js';

(() => {
    'use strict';

    /* ========================================================================
     * 1. ⚙️ CONFIGURAZIONE LOCALE & STATO INTERNO
     * ======================================================================== */
    const CONFIG = Object.freeze({
        SDK_CHANNEL_NAME: 'PANZER_TELEMETRY_BUS',
        PROGRESS_UPDATE_THROTTLE_MS: 50,
        DOM_IDS: {
            STATUS_BADGE: 'panzer-status-badge',
            PROGRESS_BAR: 'panzer-progress-bar',
            PROGRESS_TEXT: 'panzer-progress-text',
            METRICS_CONTAINER: 'panzer-metrics-container',
            CONSOLE_LOG: 'panzer-terminal-output',
            SYNC_BTN: 'panzer-btn-sync'
        }
    });

    /**
     * @type {Object} State Management per la telemetria e la sincronizzazione
     */
    const state = {
        sdkInstance: null,
        isSyncing: false,
        lastProgressPct: 0,
        metrics: {
            completed: 0,
            total: 0,
            failed: 0,
            networkFailures: 0
        }
    };

    /**
     * Cache dei riferimenti DOM per prestazioni ad altissima velocità (Zero Layout Thrashing)
     */
    const dom = {};

    /* ========================================================================
     * 2. 🧰 UTILITIES DI LOGGING & UI (UNICODE CONSOLE & DOM)
     * ======================================================================== */
    
    /**
     * Formatta e stampa un messaggio di diagnostica nel terminale UI e in Console
     * @param {string} level - 'INFO' | 'WARN' | 'ERROR' | 'SUCCESS' | 'SYNC'
     * @param {string} message - Testo del messaggio
     * @param {Object|null} payload - Eventuali dati extra da allegare
     */
    function uiLog(level, message, payload = null) {
        const timestamp = new Date().toLocaleTimeString('it-IT', { hour12: false });
        let icon = 'ℹ️';
        let cssClass = 'log-info';

        switch (level) {
            case 'SUCCESS': icon = '✅'; cssClass = 'log-success'; break;
            case 'WARN':    icon = '⚠️'; cssClass = 'log-warn'; break;
            case 'ERROR':   icon = '🚨'; cssClass = 'log-error'; break;
            case 'SYNC':    icon = '🔄'; cssClass = 'log-sync'; break;
            case 'INIT':    icon = '⚡'; cssClass = 'log-init'; break;
            case 'CORE':    icon = '📦'; cssClass = 'log-core'; break;
        }

        const formattedText = `[${timestamp}] ${icon} [${level}] ${message}`;

        // Output nella console sviluppatore
        if (level === 'ERROR') console.error(formattedText, payload || '');
        else if (level === 'WARN') console.warn(formattedText, payload || '');
        else console.log(formattedText, payload || '');

        // Rendering dinamico sul terminale visivo UI (se presente nel DOM)
        if (dom.CONSOLE_LOG) {
            const entry = document.createElement('div');
            entry.className = `terminal-line ${cssClass}`;
            entry.textContent = formattedText + (payload ? ` -> ${JSON.stringify(payload)}` : '');
            dom.CONSOLE_LOG.appendChild(entry);
            
            // Auto-scroll all'ultimo evento di telemetria
            dom.CONSOLE_LOG.scrollTop = dom.CONSOLE_LOG.scrollHeight;
        }
    }

    /**
     * Inizializza e memorizza i puntatori DOM per ottimizzare il throughput di rendering
     */
    function cacheDOMReferences() {
        Object.keys(CONFIG.DOM_IDS).forEach(key => {
            const id = CONFIG.DOM_IDS[key];
            dom[key] = document.getElementById(id);
        });
    }

    /* ========================================================================
     * 3. 📊 GESTORE DELLA TELEMETRIA & BROADCAST SDK (`initDB` Callback)
     * ======================================================================== */

    /**
     * Callback di Broadcast inviata dall'SDK Panzer durante le fasi di `initDB`
     * @param {Object} event - Payload dell'evento emesso dall'SDK
     */
    function handleTelemetryBroadcast(event) {
        if (!event || !event.type) return;

        switch (event.type) {
            case 'SYNC_START':
                state.isSyncing = true;
                updateStatusBadge('📡 Sincronizzazione avviata...', 'status-active');
                uiLog('SYNC', 'Inizio verifica integrità e download della stiva dati...');
                resetMetricsUI();
                break;

            case 'SYNC_PROGRESS':
                state.metrics.completed = event.current || 0;
                state.metrics.total = event.total || 0;
                state.metrics.failed = event.failed_assets || 0;
                state.metrics.networkFailures = event.request_failed || 0;
                
                renderProgressUI(event.percent || 0);
                break;

            case 'SYNC_RETRY':
                updateStatusBadge('⚠️ Rete degradata: Tentativo di riconnessione...', 'status-warning');
                uiLog('WARN', 'Segnale di rete debole o assente. Attivazione fallback di riprova.', event);
                break;

            case 'SYNC_END':
                state.isSyncing = false;
                renderProgressUI(100);
                updateStatusBadge('🟢 Database & Risorse Sincronizzati', 'status-ready');
                uiLog('SUCCESS', `Sincronizzazione completata con successo. (Rilevati cambiamenti: ${event.hasChanged ? 'SÌ 🔄' : 'NO 🔒'})`, {
                    serverVersion: event.serverVersion,
                    totalAssets: state.metrics.total,
                    failedAssets: state.metrics.failed
                });
                break;

            case 'CORE_UPDATE_RELOAD':
                updateStatusBadge('🚨 Aggiornamento critico Core - Riavvio...', 'status-critical');
                uiLog('CORE', 'Rilevato aggiornamento primario dell\'Engine o purga. Esecuzione del ricaricamento controllato...');
                setTimeout(() => {
                    window.location.reload();
                }, 1500);
                break;

            default:
                uiLog('INFO', `Evento di sistema non tracciato: ${event.type}`, event);
                break;
        }
    }

    /**
     * Aggiorna graficamente la ProgressBar e i contatori visivi di metrica
     * @param {number} percent - Percentuale di avanzamento [0-100]
     */
    function renderProgressUI(percent) {
        const clampedPct = Math.min(100, Math.max(0, Math.floor(percent)));
        state.lastProgressPct = clampedPct;

        if (dom.PROGRESS_BAR) {
            dom.PROGRESS_BAR.value = clampedPct;
        }

        if (dom.PROGRESS_TEXT) {
            dom.PROGRESS_TEXT.textContent = `${clampedPct}% (${state.metrics.completed}/${state.metrics.total})`;
        }

        if (dom.METRICS_CONTAINER) {
            dom.METRICS_CONTAINER.innerHTML = `
                <div class="metric-box">
                    <div class="card-title">Completati</div>
                    <div class="metric-val">${state.metrics.completed} / ${state.metrics.total}</div>
                </div>
                <div class="metric-box">
                    <div class="card-title">Falliti</div>
                    <div class="metric-val" style="color: var(--accent-danger);">${state.metrics.failed}</div>
                </div>
                <div class="metric-box">
                    <div class="card-title">Err. Rete</div>
                    <div class="metric-val" style="color: var(--accent-warning);">${state.metrics.networkFailures}</div>
                </div>
            `;
        }
    }

    /**
     * Ripristina gli indicatori della UI prima di avviare un nuovo ciclo
     */
    function resetMetricsUI() {
        state.lastProgressPct = 0;
        state.metrics = { completed: 0, total: 0, failed: 0, networkFailures: 0 };
        renderProgressUI(0);
    }

    /**
     * Aggiorna lo stato visivo del Badge principale nell'interfaccia
     * @param {string} text - Testo da visualizzare
     * @param {string} cssClass - Classe di stile applicata
     */
    function updateStatusBadge(text, cssClass) {
        if (!dom.STATUS_BADGE) return;
        dom.STATUS_BADGE.textContent = text;
        
        // Mappatura dinamica delle classi CSS per la UI
        let statusClass = 'badge';
        if (cssClass.includes('ready') || cssClass.includes('online')) statusClass += ' online';
        else if (cssClass.includes('offline') || cssClass.includes('critical')) statusClass += ' offline';
        
        dom.STATUS_BADGE.className = statusClass;
    }

    /* ========================================================================
     * 4. 🚀 BOOTSTRAP & INIZIALIZZAZIONE SDK PANZER
     * ======================================================================== */

    /**
     * Inizializza l'SDK Panzer, esegue il binding degli eventi e lancia initDB
     */
    async function initPanzerApp() {
        cacheDOMReferences();
        uiLog('INIT', '⚡ Inizializzazione Core Application Controller (`app.js`)...');

        if (!PanzerSDK) {
            uiLog('ERROR', '🚨 PanzerSDK non caricato correttamente! Verificare l\'import del modulo.');
            updateStatusBadge('🚨 Errore SDK Mancante', 'status-critical');
            return;
        }

        try {
            // Istanziazione del client SDK
            state.sdkInstance = new PanzerSDK({
                channelName: CONFIG.SDK_CHANNEL_NAME,
                debug: true
            });

            uiLog('SUCCESS', '🛠️ Istanza PanzerSDK creata con successo.');

            // Event Listener sul pulsante manuale di sincronizzazione
            if (dom.SYNC_BTN) {
                dom.SYNC_BTN.addEventListener('click', () => {
                    if (state.isSyncing) {
                        uiLog('WARN', '⏳ Sincronizzazione già in corso. Attesa completamento...');
                        return;
                    }
                    triggerManualDatabaseSync();
                });
            }

            // Primo avvio automatico dell'Engine
            await triggerManualDatabaseSync();

        } catch (error) {
            uiLog('ERROR', '💥 Eccezione critica durante l\'inizializzazione dell\'applicazione:', error);
            updateStatusBadge('🚨 Errore Inizializzazione', 'status-critical');
        }
    }

    /**
     * Innesca la sincronizzazione dell'infrastruttura dati tramite `sdk.initDB()`
     */
    async function triggerManualDatabaseSync() {
        uiLog('SYNC', '🔍 Invio richiesta di inizializzazione/sincronizzazione DB all\'SDK...');
        
        const eventDataSnapshot = {
            timestamp: Date.now(),
            clientVersion: '7.6.0-pwa'
        };

        try {
            await state.sdkInstance.initDB(eventDataSnapshot, handleTelemetryBroadcast);
        } catch (err) {
            uiLog('ERROR', '❌ Fallimento durante l\'esecuzione di initDB:', err);
            updateStatusBadge('🚨 Sincronizzazione Fallita', 'status-critical');
        }
    }

    /* ========================================================================
     * 5. 🌐 EVENTI DI RETE E CICLO DI VITA DOM
     * ======================================================================== */

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initPanzerApp);
    } else {
        initPanzerApp();
    }

    window.addEventListener('online', () => {
        uiLog('SUCCESS', '🌐 Connessione di rete ripristinata (Online).');
        updateStatusBadge('🟢 Online - Pronto', 'status-ready');
    });

    window.addEventListener('offline', () => {
        uiLog('WARN', '📡 Dispositivo disconnesso dalla rete (Offline). Operatività locale attiva.');
        updateStatusBadge('🟠 Offline Mode', 'status-offline');
    });

})();