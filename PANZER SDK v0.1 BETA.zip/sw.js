/**
 * ============================================================================
 * 🛡️ PANZER SDK v0.1 - BETA
 * 
 * SERVICE WORKER CORE ENGINE
 * ============================================================================
 * @file       sw.js
 * @description Service Worker per l'Ente Comunale. Gestisce il caching elastico,
 *              l'intercettazione offline, la verifica di integrità e il
 *              dispatch di telemetria verso app.js via BroadcastChannel.
 * @author     Valentino Aglianò
 * @license    EUPL-1.2
 * ============================================================================
 */

'use strict';

/* ============================================================================
 * 1. ⚙️ CONFIGURAZIONE DI STATO & STIVA CACHE
 * ============================================================================ */
const PANZER_SW_CONFIG = Object.freeze({
    ENGINE_VERSION: '0.1-BETA_ENTE-MUNICIPAL',
    CACHE_KEYS: {
        CORE: 'panzer-core-v7+',
        DATA: 'panzer-data-v7+',
        DYNAMIC: 'panzer-dynamic-v7+'
    },
    TELEMETRY_CHANNEL: 'PANZER_TELEMETRY_BUS',
    // Assets primari indispensabili per l'operatività minima (App Shell)
    CORE_APP_SHELL: [
        './',
        './index.html',
        './css/style.css', // ??
        './js/app.js',
        './js/panzer-sdk.js',
        './PWA.webmanifest',
        './favicon.ico' // ??
    ]
});

// Istanziazione del canale di telemetria condiviso con app.js
const telemetryBus = new BroadcastChannel(PANZER_SW_CONFIG.TELEMETRY_CHANNEL);

/* ============================================================================
 * 2. 🧰 UTILITIES DI TELEMETRIA & LOGGING UNICODE
 * ============================================================================ */

/**
 * Trasmette un pacchetto di telemetria sul BroadcastChannel condiviso
 * @param {string} type - Identificativo evento (es. 'SYNC_PROGRESS', 'CORE_UPDATE_RELOAD')
 * @param {Object} payload - Dati di dettaglio associati all'evento
 */
function sendSWTelemetry(type, payload = {}) {
    const message = {
        type: type,
        timestamp: Date.now(),
        source: 'SW_ENGINE',
        ...payload
    };
    
    telemetryBus.postMessage(message);
    
    // Log interno del Service Worker
    console.log(`⚙️ [SW ${PANZER_SW_CONFIG.ENGINE_VERSION}] 📡 Broadcast [${type}]:`, payload);
}

/* ============================================================================
 * 3. 🔄 CICLO DI VITA: INSTALLAZIONE (`install`)
 * ============================================================================ */
self.addEventListener('install', (event) => {
    console.log(`⚡ [SW] Inizializzazione installazione Service Worker Ente Comunale (v${PANZER_SW_CONFIG.ENGINE_VERSION})...`);
    
    // Forzatura dell'attivazione immediata senza attesa del riavvio dei client
    self.skipWaiting();

    event.waitUntil(
        (async () => {
            try {
                sendSWTelemetry('SYNC_START', { detail: 'Inizio pre-caching App Shell Core' });

                const cache = await caches.open(PANZER_SW_CONFIG.CACHE_KEYS.CORE);
                let loaded = 0;
                const total = PANZER_SW_CONFIG.CORE_APP_SHELL.length;

                // Download ed elaborazione granulare dei file dell'App Shell per telemetria
                for (const url of PANZER_SW_CONFIG.CORE_APP_SHELL) {
                    try {
                        await cache.add(url);
                        loaded++;
                        
                        sendSWTelemetry('SYNC_PROGRESS', {
                            current: loaded,
                            total: total,
                            percent: Math.floor((loaded / total) * 100),
                            failed_assets: 0,
                            request_failed: 0
                        });
                    } catch (assetErr) {
                        console.error(`🚨 [SW] Impossibile memorizzare la risorsa Core: ${url}`, assetErr);
                    }
                }

                sendSWTelemetry('SYNC_END', {
                    hasChanged: true,
                    serverVersion: PANZER_SW_CONFIG.ENGINE_VERSION
                });

                console.log('✅ [SW] App Shell memorizzata con successo nella stiva Core.');
            } catch (err) {
                console.error('💥 [SW] Errore critico durante la fase di installazione:', err);
                sendSWTelemetry('SYNC_RETRY', { error: err.message });
            }
        })()
    );
});

/* ============================================================================
 * 4. 🧹 CICLO DI VITA: ATTIVAZIONE & PURGA (`activate`)
 * ============================================================================ */
self.addEventListener('activate', (event) => {
    console.log('📦 [SW] Attivazione Service Worker Engine e bonifica vecchie stive...');

    event.waitUntil(
        (async () => {
            // Reclamazione immediata del controllo su tutti i client aperti
            await self.clients.claim();

            // Pulizia delle vecchie stive di cache obsolete
            const cacheNames = await caches.keys();
            const validCacheSet = new Set(Object.values(PANZER_SW_CONFIG.CACHE_KEYS));

            const purgePromises = cacheNames.map(async (cacheName) => {
                if (!validCacheSet.has(cacheName)) {
                    console.log(`🗑️ [SW] Purga stiva obsoleta o non riconosciuta: ${cacheName}`);
                    return caches.delete(cacheName);
                }
            });

            await Promise.all(purgePromises);
            
            sendSWTelemetry('CORE_UPDATE_RELOAD', { 
                status: 'ACTIVATED',
                version: PANZER_SW_CONFIG.ENGINE_VERSION 
            });

            console.log('✅ [SW] Bonifica stiva completata. Service Worker operativo al 100%.');
        })()
    );
});

/* ============================================================================
 * 5. 🌐 INTERCETTAZIONE RETE & CACHING ELASTICO (`fetch`)
 * ============================================================================ */
self.addEventListener('fetch', (event) => {
    const request = event.request;

    // Ignora richieste non-GET o protocolli non supportati (es. estensioni, chrome-extension)
    if (request.method !== 'GET' || !request.url.startsWith('http')) {
        return;
    }

    event.respondWith(
        (async () => {
            // STRATEGIA: Cache First con Network Fallback per l'App Shell e risorse statiche
            const cachedResponse = await caches.match(request);
            if (cachedResponse) {
                return cachedResponse;
            }

            // Se la risorsa non è in Cache, prova la rete e aggiorna la stiva dinamica
            try {
                const networkResponse = await fetch(request);

                // Memorizza solo risposte valide (HTTP 200 OK e tipo basic)
                if (networkResponse && networkResponse.status === 200 && networkResponse.type === 'basic') {
                    const responseToCache = networkResponse.clone();
                    const dynamicCache = await caches.open(PANZER_SW_CONFIG.CACHE_KEYS.DYNAMIC);
                    dynamicCache.put(request, responseToCache);
                }

                return networkResponse;
            } catch (error) {
                console.warn(`📡 [SW] Dispositivo Offline o rete non disponibile per: ${request.url}`);

                // Fallback offline predefinito se la risorsa è una navigazione HTML
                if (request.headers.get('accept')?.includes('text/html')) {
                    const fallbackResponse = await caches.match('./index.html');
                    if (fallbackResponse) {
                        return fallbackResponse;
                    }
                }

                // Restituisce risposta di errore di rete controllata
                return new Response(
                    JSON.stringify({ 
                        error: 'OFFLINE_MODE', 
                        message: '⚠️ Dispositivo attualmente offline. Risorsa non disponibile in locale.' 
                    }), 
                    { 
                        status: 503, 
                        headers: { 'Content-Type': 'application/json' } 
                    }
                );
            }
        })()
    );
});

/* ============================================================================
 * 6. ✉️ MESSAGGI DI COMANDO DIRETTO DA CLIENT (`message`)
 * ============================================================================ */
self.addEventListener('message', (event) => {
    if (!event.data || !event.data.action) return;

    console.log(`📩 [SW] Ricevuto comando diretto da app.js: ${event.data.action}`);

    switch (event.data.action) {
        case 'FORCE_PURGE_CACHE':
            event.waitUntil(
                (async () => {
                    const keys = await caches.keys();
                    await Promise.all(keys.map(k => caches.delete(k)));
                    console.log('🗑️ [SW] Purga totale delle stive eseguita su comando client.');
                    sendSWTelemetry('CORE_UPDATE_RELOAD', { reason: 'MANUAL_PURGE' });
                })()
            );
            break;

        case 'GET_VERSION':
            if (event.ports && event.ports[0]) {
                event.ports[0].postMessage({ version: PANZER_SW_CONFIG.ENGINE_VERSION });
            }
            break;

        default:
            console.warn(`⚠️ [SW] Azione non riconosciuta: ${event.data.action}`);
            break;
    }
});